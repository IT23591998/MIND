print("1. Importing basic OS/SYS...")
import os
import sys

print("2. Importing Speech Recognition...")
import speech_recognition as sr

print("3. Importing Faster Whisper (This is the likely crash point)...")
try:
    from faster_whisper import WhisperModel
    print("   -> Import successful.")
except Exception as e:
    print(f"   -> Import FAILED: {e}")

print("4. Attempting to load Whisper Model to CPU...")
try:
    # We use very specific CPU settings here
    model = WhisperModel("tiny.en", device="cpu", compute_type="int8", cpu_threads=1)
    print("   -> Model loaded successfully.")
except Exception as e:
    print(f"   -> Model load FAILED: {e}")

print("5. Testing Microphone Initialization...")
try:
    r = sr.Recognizer()
    mic = sr.Microphone(device_index=2)
    print("   -> Mic object created.")
except Exception as e:
    print(f"   -> Mic init FAILED: {e}")

print("6. Testing Pygame Mixer...")
try:
    import pygame
    pygame.mixer.init()
    print("   -> Pygame Mixer ready.")
except Exception as e:
    print(f"   -> Pygame FAILED: {e}")

print("\n--- DEBUG COMPLETE ---")
print("If you see this, the issue is likely a conflict between these parts when combined.")