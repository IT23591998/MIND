import os
import json
import time
from colorama import Fore, init
from mind_brain import MindBrain  # Uses your existing Brain

# Initialize Colorama
init(autoreset=True)

class GenesisEngine:
    def __init__(self):
        self.brain = MindBrain()
        self.project_root = "D:/MyProjects/" # Change this to your preferred path

    def create_project(self, user_prompt):
        print(f"{Fore.CYAN}🏗️ [GENESIS] Phase 1: Designing Structure for '{user_prompt}'...")

        # --- STEP 1: GET THE STRUCTURE (JSON ONLY) ---
        structure_prompt = f"""
        You are a Senior Software Architect.
        The user wants: "{user_prompt}".
        
        TASK:
        Create the full file/folder structure for this project.
        
        RULES:
        1. Output strictly valid JSON.
        2. Format: {{"project_name": "Name", "structure": [{{"type": "file", "name": "main.py"}}, {{"type": "folder", "name": "utils", "children": [...]}}]}}
        3. Do NOT write any code inside the files yet. Just names.
        4. Include all necessary files (e.g., requirements.txt, main.py, modules).
        """

        # Ask the AI
        response = self.brain.think(structure_prompt, temperature=0.1)
        
        try:
            # Clean Markdown if present
            clean_json = response.replace("```json", "").replace("```", "").strip()
            project_data = json.loads(clean_json)
        except json.JSONDecodeError:
            print(f"{Fore.RED}❌ [ERROR] AI failed to design the structure. Raw output:\n{response}")
            return

        # --- STEP 2: BUILD THE SKELETON ---
        project_name = project_data.get("project_name", "NewProject").replace(" ", "")
        full_path = os.path.join(self.project_root, project_name)
        
        print(f"{Fore.YELLOW}🔨 [GENESIS] Building Skeleton at: {full_path}")
        os.makedirs(full_path, exist_ok=True)
        
        # Recursive function to build files/folders
        files_to_code = [] # We keep a list of files we need to fill later

        def build_tree(current_path, items):
            for item in items:
                name = item.get("name")
                type_ = item.get("type")
                
                path = os.path.join(current_path, name)
                
                if type_ == "folder":
                    os.makedirs(path, exist_ok=True)
                    # Recurse into children
                    if "children" in item:
                        build_tree(path, item["children"])
                        
                elif type_ == "file":
                    # Create empty file
                    with open(path, "w") as f:
                        f.write("# Pending generation...")
                    files_to_code.append(path)
                    print(f"   └── 📄 Created: {name}")

        build_tree(full_path, project_data.get("structure", []))

        # --- STEP 3: FILL THE FILES (THE CODING LOOP) ---
        print(f"\n{Fore.MAGENTA}⚡ [GENESIS] Phase 2: Writing Code ({len(files_to_code)} files)...")
        
        for file_path in files_to_code:
            filename = os.path.basename(file_path)
            print(f"{Fore.CYAN}   Writing code for: {filename}...")
            
            # Read context (optional: read other files to understand context)
            
            code_prompt = f"""
            You are an Expert Developer.
            Project: {user_prompt}
            Current File: {filename}
            
            TASK:
            Write the COMPLETE, working code for this specific file.
            
            RULES:
            1. Output ONLY the code. No explanations.
            2. Do not use markdown blocks (```).
            3. Ensure imports match the project structure.
            """
            
            # Ask the AI for the code
            code_content = self.brain.think(code_prompt, temperature=0.2)
            
            # Clean the output
            clean_code = code_content.replace("```python", "").replace("```", "").strip()
            
            # Write to file
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(clean_code)
                
            time.sleep(1) # Prevent rate limits

        print(f"\n{Fore.GREEN}✅ [DONE] Project '{project_name}' is ready!")
        print(f"📂 Location: {full_path}")

# --- RUN IT ---
if __name__ == "__main__":
    engine = GenesisEngine()
    
    user_request = input("ENTER PROJECT IDEA: ") 
    # Example: "A snake game in Python with a score menu"
    
    engine.create_project(user_request)