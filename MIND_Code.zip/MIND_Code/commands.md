# MIND Voice Command Reference

Here are the voice commands currently programmed into MIND, categorized by their function.

## 1. System & Identity
| Command | Action |
| :--- | :--- |
| **"MIND introduce yourself"** | Triggers the system introduction sequence. |
| **"Who are you?"** | Alternative identity trigger. |
| **"System status"** | Checks system hardware (CPU, RAM, GPU) and reports health. |
| **"MIND sleep"** / **"Go to sleep"** | Puts the voice loop into standby mode. |

## 2. Development & Coding
| Command | Action |
| :--- | :--- |
| **"Create app [Name]"** | Starts the Android app generation protocol (e.g., *"Create app ToDoList"*). |
| **"Create app [Name] Flutter"** | Triggers the cross-platform Flutter agent. |
| **"Create script for [mechanic] in [engine]"** | Generates game scripts (e.g., *"Create script for movement in Unity"*). |

## 3. Data & Finance
| Command | Action |
| :--- | :--- |
| **"Analyze data [filename]"** | Loads and analyzes a specific CSV/Excel file. |
| **"Analyze data"** | Analyzes currently loaded data. |
| **"Plot"** / **"Graph"** | Generates a visualization for the data. |
| **"Price of [Symbol]"** | Fetches stock prices (e.g., *"Price of JKH"*). |
| **"Spent [Amount] on [Item]"** | Logs an expense (e.g., *"Spent 50 dollars on lunch"*). |
| **"Earned [Amount]"** | Logs an income source. |
| **"Balance"** | Reports current financial balance. |
| **"Sync finance"** | Syncs local data to the cloud (Google Sheets). |

## 4. Productivity & Knowledge
| Command | Action |
| :--- | :--- |
| **"Remind me to [Task] in [Time]"** | Sets a timed reminder (e.g., *"Remind me to check logs in 10 minutes"*). |
| **"Add task [Task]"** | Adds an item to the To-Do list. |
| **"List tasks"** | Reads out current pending tasks. |
| **"Read [filename]"** | Reads a document (PDF/DOCX) aloud using TTS. |
| **"Explain [filename]"** | Summarizes the content of a document. |
| **"Organize"** | Sorts files in the Downloads folder into categories. |

## 5. Security & Vision
> **Note:** Some security commands may require a voice password authentication step.

| Command | Action |
| :--- | :--- |
| **"Security status"** | Runs a system integrity check. |
| **"Delete file [filename]"** | Securely deletes a file (Requires Auth). |
| **"Crack password [hash]"** | Runs John the Ripper on a hash (Requires Auth). |
| **"What do you see?"** | Captures an image from the camera and analyzes it. |
| **"Audit 3D"** | Analyzes 3D geometry visible to the camera. |

## 6. 3D & Smart Home
| Command | Action |
| :--- | :--- |
| **"Design [description]"** | Generates a 3D asset description or model. |
| **"Spawn [shape]"** | Spawns a primitive in the hologram projector (e.g., *"Spawn Cube"*). |
| **"Show 3D model of [file]"** | Displays a specific 3D model file. |
| **"Turn on/off [device]"** | Controls smart home devices via IoT. |
| **"Shop for [item]"** | Searches for products online. |