import os
import torch
import warnings

# --- THE "STARK" OVERRIDE (FIXED) ---
# We force torchaudio to stop looking for torchcodec/FFmpeg
import torchaudio
try:
    torchaudio.set_audio_backend("soundfile")
except Exception:
    pass

# This manually overrides the function that is causing the crash
import TTS.tts.models.xtts as xtts_module
import librosa # We will use librosa instead of torchaudio for loading

def manual_load_audio(audiopath, sr):
    # librosa.load returns (numpy_array, sample_rate)
    audio, _ = librosa.load(audiopath, sr=sr)
    # Convert to tensor and add channel dimension (1, length)
    # FIX: We only return the AUDIO tensor, not the tuple
    return torch.from_numpy(audio).unsqueeze(0)

# Force the XTTS model to use our manual reader
xtts_module.load_audio = manual_load_audio
# -----------------------------

# --- SECURITY ALLOWLIST ---
from TTS.tts.configs.xtts_config import XttsConfig
from TTS.config.shared_configs import BaseDatasetConfig
from TTS.tts.models.xtts import XttsAudioConfig, XttsArgs

torch.serialization.add_safe_globals([XttsConfig, BaseDatasetConfig, XttsAudioConfig, XttsArgs])
warnings.filterwarnings("ignore")

from TTS.api import TTS
import pygame
import time

# --- HARDWARE SETUP ---
device = "cuda" if torch.cuda.is_available() else "cpu"

print("[MIND] Initializing System Core Vocal Modules...")
tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(device)

def mind_speak(text):
    core_sample = "D:/MIND_Project/assets/system_core.wav"
    output_wav = "D:/MIND_Project/assets/mind_response.wav"
    
    print(f"[MIND] Synthesizing Voice: {text}")
    
    tts.tts_to_file(
        text=text,
        speaker_wav=core_sample,
        language="en",
        file_path=output_wav
    )
    
    play_audio(output_wav)

def play_audio(path):
    pygame.mixer.init()
    pygame.mixer.music.load(path)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        time.sleep(0.1)
    pygame.mixer.music.unload()

if __name__ == "__main__":
    mind_speak("Mageepan, systems are green. The audio patch is successful. I am now fully operational on your local server.")