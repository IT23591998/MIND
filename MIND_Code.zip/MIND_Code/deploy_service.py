import winreg
import os
import sys

def install_mind_service():
    key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
    app_name = "MIND Orchestrator Service"
    script_path = os.path.abspath("start_mind_hidden.vbs")
    
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(key, app_name, 0, winreg.REG_SZ, script_path)
        winreg.CloseKey(key)
        print(f"[SUCCESS] {app_name} added to Registry.")
        print(f"Target: {script_path}")
        print("MIND will now auto-start on login (after 60s delay).")
    except Exception as e:
        print(f"[ERROR] Failed to modify registry: {e}")

if __name__ == "__main__":
    install_mind_service()
