import hashlib
import os
import winsound

class MINDFirewall:
    def __init__(self, monitored_file):
        self.monitored_file = monitored_file
        self.restricted_commands = ["rmdir", "del /s", "format", "reg delete", "net user", "shutdown"]
        # Set the "Golden Fingerprint"
        self.original_hash = self._calculate_hash()

    def _calculate_hash(self):
        hasher = hashlib.sha256()
        with open(self.monitored_file, 'rb') as f:
            hasher.update(f.read())
        return hasher.hexdigest()

    def verify_integrity(self):
        """Returns True if the file matches its golden fingerprint."""
        current_hash = self._calculate_hash()
        return current_hash == self.original_hash

    def validate_request(self, command):
        command = command.lower()
        for restricted in self.restricted_commands:
            if restricted in command:
                return False, f"BREACH ATTEMPT: Restricted keyword '{restricted}'"
        return True, "SAFE"

    def validate_code(self, code_str):
        """Standard Sandbox Check (Asimov Lock)"""
        # Rule 1: No touching Core Files
        if "mind_core_loop.py" in code_str or "shield.py" in code_str or "mind_brain.py" in code_str:
            return False, "DENIED: Code attempts to modify CORE SYSTEM FILES."
        
        # Rule 2: No Infinite Loops (Basic heuristic)
        if "while True" in code_str and "sleep" not in code_str and "break" not in code_str:
            return False, "DENIED: Potential Infinite Loop without sleep/break."

        # Rule 3: No Networking implementation without explicit import
        if "socket" in code_str or "requests" in code_str:
            # Check if this agent is authorized for net (Simplified: Warning)
            pass

        # Rule 4: Critical deletions
        if "shutil.rmtree" in code_str or "os.remove" in code_str:
             return False, "DENIED: Unsafe Deletion Logic."

        return True, "SAFE"

def network_kill_switch():
    print("\n[!!!] EMERGENCY: DISCONNECTING NETWORK...")
    # Physical isolation commands
    os.system('netsh interface set interface "Wi-Fi" admin=disable')
    os.system('ipconfig /release')
    winsound.Beep(2000, 1000)