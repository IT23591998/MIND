import os

def setup_telegram():
    print("📱 MIND Remote Setup (Telegram)")
    print("-------------------------------")
    print("1. Open Telegram and search for @BotFather")
    print("2. Send /newbot and follow instructions")
    print("3. Copy the HTTP API TOKEN provided")
    print("-------------------------------")
    
    token = input("Paste your Bot Token here: ").strip()
    
    if len(token) < 10:
        print("❌ That doesn't look like a valid token.")
        return

    env_path = ".env"
    
    # Read existing
    lines = []
    if os.path.exists(env_path):
        with open(env_path, "r") as f:
            lines = f.readlines()
            
    # Remove existing token line
    lines = [l for l in lines if "TELEGRAM_BOT_TOKEN" not in l]
    
    # Add new
    lines.append(f"\nTELEGRAM_BOT_TOKEN={token}\n")
    
    with open(env_path, "w") as f:
        f.writelines(lines)
        
    print(f"✅ Token saved to {env_path}.")
    print("Restart MIND to enable Remote Access.")

if __name__ == "__main__":
    setup_telegram()
