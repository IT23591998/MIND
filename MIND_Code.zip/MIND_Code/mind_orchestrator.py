import os
import sys
# --- FAILSAFE: Handle Detached console (pythonw) ---
if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
import time
import traceback
import subprocess

# --- EARLY STARTUP LOG ---
if "--startup" in sys.argv:
    try:
        # 1. Create Status File
        MIND_PATH = r"D:\MIND_Project" # Hardcode or derive if config not loaded
        welcome_path = os.path.join(MIND_PATH, "welcome_status.txt")
        
        with open(welcome_path, "w") as f:
            f.write(f"MIND INITIALIZING...\nTimestamp: {time.ctime()}\n\n")
            f.write("Please wait while AI Core Models are loaded (Approx 4 mins)...\n")
            f.write("You will hear a chime when the system is online.")

        # 2. Speak Status (PowerShell - Offline & Fast)
        # subprocess.Popen([r"C:\Windows\notepad.exe", welcome_path]) # Disabled per user request
        
        startup_msg = "MIND Initializing. Please wait while AI Core Models are loaded."
        cmd = f'PowerShell -Command "Add-Type –AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak(\'{startup_msg}\');"'
        subprocess.run(cmd, shell=True)
        
    except Exception as e:
        # Fallback log
        try:
             with open("startup_crash.log", "w") as f: f.write(str(e))
        except: pass

# --- SAFE IMPORT BLOCK ---
HAS_AUDIO = False
try:

    import numpy as np
    import sounddevice as sd
    import psutil
    from colorama import Fore
    import config
    
    # Audio Backend
    try:
        import pygame
        pygame.mixer.init()
        HAS_AUDIO = True
    except ImportError:
        HAS_AUDIO = False


    # Import Core
    import mind_core_loop as core

    # Import OpenWakeWord
    try:
        from openwakeword.model import Model
        HAS_WAKE = True
    except ImportError:
        HAS_WAKE = False
        try:
            print(Fore.RED + "⚠️ openwakeword not found. Wake functionality limited.")
        except:
            print("⚠️ openwakeword not found. Wake functionality limited.")

except BaseException as e:
    # CRITICAL FALLBACK FOR STARTUP VISIBILITY
    if "--startup" in sys.argv:
        # Use hardcoded path as fallback if config failed
        MIND_PATH = r"D:\MIND_Project"
        welcome_path = os.path.join(MIND_PATH, "welcome_status.txt")
        
        with open(welcome_path, "w") as f:
            f.write(f"MIND SYSTEM FAILURE\nTimestamp: {time.ctime()}\n\n")
            f.write(f"Error during module loading:\n{str(e)}\n\n")
            f.write(traceback.format_exc())
            f.write("\nPlease check dependencies or run manually to debug.")
        
        subprocess.Popen([r"C:\Windows\notepad.exe", welcome_path])
        sys.exit(1)
    else:
        # Re-raise if running manually so we see output in console
        raise e

# CONFIG
WAKE_WORD = "mind_wake_up" # We'll need to download/train this, or use a default like "hey_jarvis" for now and map it.
# For this implementation, I'll use the pre-trained 'alexa' or similar if custom isn't built, or assume 'mind_wake_up.tflite' exists.
# User asked for "MIND wake up". If custom model not present, we can't use it.
# Strategy: Use a stock model (like 'hey jarvis') as a placeholder or try to simulate trigger if no model.
# I will initialize with standard OpenWakeWord defaults which often include 'alexa', 'hey_mycroft', etc.
# Ideally we would train 'mind_wake_up'.
TARGET_MODEL = "hey_jarvis" # Closest proxy for now
CHUNK_SIZE = 1280
MIC_CHANNELS = 1

def set_efficiency_mode():
    """Pins process to E-Cores (Higher Logic Cores)"""
    try:
        p = psutil.Process()
        count = psutil.cpu_count()
        # Assume last 30% are efficiency cores
        e_cores = list(range(int(count * 0.7), count))
        p.cpu_affinity(e_cores)
        # Set Priority to IDLE (Windows specific class)
        p.nice(psutil.IDLE_PRIORITY_CLASS)
        print(f"{Fore.GREEN}💤 MIND Orchestrator pinned to E-Cores (IDLE Priority): {e_cores}")
    except Exception as e:
        print(Fore.YELLOW + f"Could not pin/prioritize: {e}")

def play_chime():
    """Plays wake chime."""
    # os.system("start assets/wake_chime.wav") # Windows specific
    # Or use core media agent
    print("🔔 *CHIME*")
    
    if HAS_AUDIO:
        try:
            # Play 'listening.mp3' or 'sys_wakeup.mp3'
            chime_path = r"D:\MIND_Project\assets\listening.mp3"
            if os.path.exists(chime_path):
                pygame.mixer.music.load(chime_path)
                pygame.mixer.music.play()
        except Exception as e:
            print(f"Audio Chime Error: {e}")


def is_mic_muted_hardware():
    # Simple check if we can read stream
    try:
        with sd.InputStream(channels=1, samplerate=16000) as s:
            pass
        return False
    except:
        return True

def wake_loop():
    # --- BOOT DELAY ---
    # WAITING BLOCK (ALWAYS RUN FOR NOW)
    if True: # was if "--startup" in sys.argv:
        print("⏳ Waiting 2s for UI...")
        time.sleep(2)
        
        # VISUAL CONFIRMATION - LOG ONLY
        try:
            welcome_path = os.path.join(config.MIND_PATH, "welcome_status.txt")
            with open(welcome_path, "w") as f:
                f.write("Welcome Sir.\nMIND System Online.\nAll Systems Nominal.")
            
            # REMOVED: Notepad Popup
            # import subprocess
            # subprocess.Popen([r"C:\Windows\notepad.exe", welcome_path])
            
            print(f"Log written to {welcome_path}")
            
        except Exception as e:
            try:
                with open("startup_error.log", "a") as err_f:
                    err_f.write(f"Welcome Error: {e}\n")
            except: pass

        print("⏳ Waiting additional 5s for Audio Drivers...")
        # time.sleep(5)  <-- REMOVED fixed wait
        
        # DYNAMIC WAIT for Neural Voice
        try:
            print("⏳ waiting for Neural Voice...")
            core.voice_bot.wait_until_loaded(timeout=60)
            if core.voice_bot.is_loaded:
                print(f"{Fore.GREEN}✅ Visual & Vocal Cores Synced.")
            else:
                print(f"{Fore.RED}⚠️ Voice Trace Failed. Using System Voice.")
        except:
            time.sleep(5) # Fallback if something weird happens

    print(f"{Fore.CYAN}--- MIND ORCHESTRATOR ONLINE (PAL-30) ---")
    
    # Custom Wake Word Configuration
    CUSTOM_WAKE_WORD = "mind wake up"
    USE_CUSTOM_WAKE = True
    
    # 2. Update Status to ONLINE
    try:
        MIND_PATH = r"D:\MIND_Project"
        welcome_path = os.path.join(MIND_PATH, "welcome_status.txt")
        with open(welcome_path, "w") as f:
            f.write(f"MIND ONLINE\nTimestamp: {time.ctime()}\n\n")
            f.write(f"Listening for: '{CUSTOM_WAKE_WORD}'\n\n")
            f.write("System Ready.")
    except: pass

    set_efficiency_mode()
    
    core.update_hud_status(face_detected=False, threat_level="SLEEP")

    # Audio Buffer
    # We increase blocksize for better analysis chunks
    mic_stream = sd.InputStream(samplerate=16000, blocksize=4000, channels=1)
    
    print(f"👂 Listening for '{CUSTOM_WAKE_WORD}'...")
    
    # VAD Variables
    vad_threshold = 0.015  # RMS Amplitude Threshold (Adjust based on mic)
    buffer = []
    buffer_duration = 30 # ~2 seconds at 16k/4000 blocksize (actually 30 blocks is too much, 4000/16000 = 0.25s per block. 8 blocks = 2s)
    
    with mic_stream:
        while True:
            # 0. Kill Switch
            if os.path.exists("STOP_MIND.tmp"):
                print(f"{Fore.RED}🛑 Kill Switch Detected (STOP_MIND.tmp). Terminating.")
                sys.exit(0)

            # 1. Read Audio
            chunk, overflow = mic_stream.read(4000)
            chunk = chunk.flatten().astype(np.float32)
            
            # 2. Calculate Energy (RMS)
            rms = np.sqrt(np.mean(chunk**2))
            
            # 3. Check for Speech
            if rms > vad_threshold:
                # Speech detected, capture next 2-3 seconds
                print(f"{Fore.YELLOW}Sound detected (RMS: {rms:.4f}). Verifying...")
                
                # Capture ~2.5 seconds (10 chunks of 0.25s)
                speech_buffer = [chunk]
                for _ in range(10): 
                    c, _ = mic_stream.read(4000)
                    speech_buffer.append(c.flatten().astype(np.float32))
                
                # Concatenate
                full_audio = np.concatenate(speech_buffer)
                
                # Convert to int16 for Whisper
                wav_int16 = (full_audio * 32767).astype(np.int16)
                
                # Transcribe with Core Whisper Model
                try:
                    # Save temp for Whisper (faster_whisper usually takes path or array? check core impl)
                    # core.stt_model is FasterWhisper. It accepts np array float32 usually!
                    # But lets stick to core usage if uncertain. core loop writes to debug_audio.wav.
                    import scipy.io.wavfile as wavfile
                    wavfile.write("wake_temp.wav", 16000, wav_int16)
                    
                    segments, _ = core.stt_model.transcribe("wake_temp.wav", beam_size=2) # efficient beam
                    text = " ".join([s.text for s in segments]).strip().lower()
                    print(f"Heard: '{text}'")
                    
                    # 4. Verify Wake Word
                    # Loose matching
                    if "mind" in text and ("wake" in text or "up" in text):
                         print(f"{Fore.GREEN}⚡ CUSTOM WAKE WORD DETECTED!")
                         
                         play_chime()
                         core.update_hud_status(face_detected=False, threat_level="HANDSHAKE")
                         
                         # Face ID
                         print("🔒 Verifying Identity...")
                         verified = core.bio_auth_bot.scan_face() # Use new name
                         
                         if verified:
                             print(f"{Fore.GREEN}🔓 Identity Confirmed.")
                             core.update_hud_status(face_detected=True, threat_level="ACTIVE")
                             core.active_session_loop()
                             # Returning...
                             print(f"{Fore.CYAN}💤 Returning to Slumber...")
                             core.update_hud_status(face_detected=False, threat_level="SLEEP")
                             set_efficiency_mode()
                         else:
                             print(f"{Fore.RED}🔒 Access Denied.")
                             core.speak("Identity verification failed.")
                             core.update_hud_status(face_detected=False, threat_level="SLEEP")
                    
                except Exception as e:
                    print(f"Wake Error: {e}")

            time.sleep(0.01)

if __name__ == "__main__":
    try:
        wake_loop()
    except Exception as e:
        import traceback
        import os
        log_path = os.path.join(os.path.dirname(__file__), "crash.log")
        with open(log_path, "w") as f:
            f.write(traceback.format_exc())
