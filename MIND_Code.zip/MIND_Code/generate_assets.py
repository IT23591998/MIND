from elevenlabs import generate, save, set_api_key
import os

set_api_key("sk_3f286ba942f35b756b35f7592376fb955837caa16174e5f5")
VOICE_ID = "4lVqhowfM2uWri1ZQ5eI"
ASSETS_DIR = "D:/MIND_Project/assets"

if not os.path.exists(ASSETS_DIR):
    os.makedirs(ASSETS_DIR)

# Define the phrases you want for your social media video
sound_bank = {

    # ======================================================
    # SYSTEM & CORE
    # ======================================================
    "sys_online": "System online. All core modules initialized. Welcome, Sir.",
    "sys_offline": "System shutting down. All processes safely terminated.",
    "sys_restart": "Restarting system. Estimated downtime: 10 seconds.",
    "sys_error": "Apologies, Sir. A system error has occurred. Diagnostics running.",
    "sys_warning": "Warning: An unexpected condition detected. Proceed with caution.",
    "sys_critical": "Critical alert. Immediate attention required!",
    "sys_update": "System update in progress. Do not power off.",
    "sys_ready": "System ready and fully operational. Awaiting instructions.",
    "sys_sleep": "Entering low-power sleep mode. Monitoring continues in background.",
    "sys_wakeup": "Waking up. Core functions restored. All systems nominal.",
    "sys_idle": "System idle. Monitoring for commands.",
    "sys_monitoring": "Monitoring environment. No anomalies detected.",

    # ======================================================
    # GREETINGS & PERSONAL
    # ======================================================
    "greet_default": "Greetings, Sir. How may I assist you today?",
    "greet_name": "Hello Ma-kee-pan. Your presence is acknowledged.",
    "welcome_back": "Welcome back, Sir. All systems are optimized and ready.",
    "good_morning": "Good morning, Sir. I trust you rested well.",
    "good_afternoon": "Good afternoon, Sir. Shall we review today’s agenda?",
    "good_evening": "Good evening, Sir. Evening protocols are active.",
    "good_night": "Good night, Sir. Sleep mode prepared for optimal recovery.",
    "personal_compliment": "You look focused today, Sir.",
    "personal_encourage": "You can accomplish this task, Sir.",

    # ======================================================
    # CONFIRMATIONS & RESPONSES
    # ======================================================
    "conf_yes": "Affirmative, Sir.",
    "conf_no": "Negative, Sir.",
    "conf_done": "Task completed successfully.",
    "conf_working": "Processing your request. Stand by.",
    "conf_cancel": "Operation cancelled as requested.",
    "conf_saved": "Changes have been saved to the system.",
    "conf_failed": "Operation failed. Attempting diagnostics.",
    "conf_acknowledge": "Acknowledged, Sir. Proceeding now.",
    "conf_ready": "Ready for the next command, Sir.",
    "conf_retry": "Retrying operation, Sir.",

    # ======================================================
    # QUESTIONS & CLARIFICATIONS
    # ======================================================
    "ask_repeat": "Could you please repeat that, Sir?",
    "ask_confirm": "Do you wish me to proceed with this action?",
    "ask_clarify": "Please clarify your request for optimal execution.",
    "ask_permission": "Permission required to continue.",
    "ask_more": "Would you like to provide additional input?",
    "ask_retry": "Shall I attempt that again, Sir?",
    "ask_prioritize": "Would you like this task prioritized?",

    # ======================================================
    # SCHEDULING & TASK MANAGEMENT
    # ======================================================
    "plan_ask": "Would you like me to plan this schedule for you?",
    "task_added": "Task successfully added to your timeline.",
    "task_updated": "Task updated and synchronized with your calendar.",
    "task_deleted": "Task has been removed from your schedule.",
    "task_done": "Task marked as completed. Well done, Sir.",
    "schedule_conflict": "Alert: Schedule conflict detected. Recommend resolution.",
    "reminder": "Reminder: Upcoming scheduled task approaching.",
    "no_tasks": "No pending tasks at the moment, Sir.",
    "agenda_summary": "Here is your agenda summary for today.",
    "deadline_warning": "Warning: Upcoming deadline approaching.",

    # ======================================================
    # TIME & DATE
    # ======================================================
    "time_now": "Current time displayed: {time}.",
    "date_today": "Today’s date is {date}.",
    "alarm_set": "Alarm successfully set for {time}.",
    "alarm_cancel": "Alarm cancelled.",
    "timer_started": "Timer started for {duration}.",
    "timer_complete": "Timer completed, Sir.",

    # ======================================================
    # HARDWARE & PERFORMANCE
    # ======================================================
    "gpu_check": "RTX 2050 detected. Temperature and load are optimal.",
    "cpu_check": "CPU running within safe parameters. No anomalies detected.",
    "ram_check": "Memory usage nominal. No optimization needed.",
    "storage_check": "Storage verified. Capacity sufficient.",
    "battery_full": "Battery fully charged. Power supply optimal.",
    "battery_low": "Warning: Battery level low. Consider recharging soon.",
    "overheat": "Caution: System temperature rising. Cooling protocols active.",
    "performance_optimize": "Optimizing system performance for maximum efficiency.",
    "hardware_failure": "Hardware anomaly detected. Maintenance recommended.",

    # ======================================================
    # NETWORK & INTERNET
    # ======================================================
    "net_connected": "Connection established. Network stable.",
    "net_disconnected": "Network disconnected. Attempting reconnection.",
    "net_slow": "Network speed below optimal levels. Reducing bandwidth usage.",
    "net_secure": "Connection is secure. All protocols verified.",
    "net_error": "Network error detected. Diagnostics in progress.",
    "net_latency_high": "High latency detected. Performance may degrade.",

    # ======================================================
    # MEDIA & AUDIO
    # ======================================================
    "media_play": "Playing media as requested.",
    "media_pause": "Playback paused.",
    "media_resume": "Resuming media playback.",
    "media_stop": "Playback stopped.",
    "volume_up": "Increasing volume.",
    "volume_down": "Decreasing volume.",
    "volume_mute": "Audio muted.",
    "volume_max": "Volume set to maximum level.",
    "media_error": "Media file could not be played.",

    # ======================================================
    # FILES & DATA
    # ======================================================
    "file_open": "Opening requested file.",
    "file_close": "Closing file.",
    "file_saved": "File saved successfully.",
    "file_deleted": "File deleted from system.",
    "file_not_found": "Requested file not found. Please check path.",
    "file_error": "File operation failed. Check permissions.",

    # ======================================================
    # SECURITY
    # ======================================================
    "auth_success": "Authentication successful. Access granted.",
    "auth_failed": "Authentication failed. Access denied.",
    "access_granted": "Access granted to requested resource.",
    "access_denied": "Access denied. Security protocols active.",
    "security_alert": "Security alert: Suspicious activity detected.",
    "security_breach": "Critical security breach detected. Immediate action required.",

    # ======================================================
    # AI & THINKING STATES
    # ======================================================
    "ai_thinking": "Analyzing data. This may take a moment.",
    "ai_learning": "Learning from previous inputs.",
    "ai_prediction": "Prediction complete. Results ready for review.",
    "ai_processing": "Processing request. Optimizing output.",
    "ai_idle": "AI idle. Standing by for commands.",
    "ai_debug": "Running diagnostics on AI core.",

    # ======================================================
    # USER INTERACTION FEEDBACK
    # ======================================================
    "listening": "Listening, Sir.",
    "mic_on": "Microphone enabled.",
    "mic_off": "Microphone disabled.",
    "voice_not_recognized": "Voice input not recognized. Please repeat.",
    "input_error": "Invalid input detected. Please rephrase.",

    # ======================================================
    # EXIT & FAREWELL
    # ======================================================
    "farewell": "Goodbye, Sir. Session terminated.",
    "see_you": "See you next time, Sir.",
    "session_end": "Ending current session. All systems idle.",
    "standby": "Entering standby mode. Awaiting next command.",

    # ======================================================
    # BACKGROUND / AMBIENT LINES
    # ======================================================
    "ambient_idle": "System monitoring quietly in the background.",
    "ambient_thinking": "Running background analysis tasks.",
    "ambient_ready": "All systems optimal. Standing by.",
    # ======================================================
    # PROJECT & CODING MODE
    # ======================================================
    "code_start": "Development environment ready. Initializing coding protocols.",
    "code_save": "Code changes pushed to local repository.",
    "code_error": "Syntax error detected in your logic, Sir. Shall I analyze the traceback?",
    "milestone_met": "Congratulations, Sir. Milestone successfully reached.",
    "project_summary": "I have compiled the project progress report. Would you like to hear it?",

    # ======================================================
    # ADVANCED SCHEDULING (The "Planning" Suite)
    # ======================================================
    "plan_check": "Checking your availability for the requested time slot.",
    "plan_busy": "Sir, you already have a commitment at that time. Should I suggest an alternative?",
    "plan_confirm": "The schedule has been locked into the system.",
    "plan_reschedule": "Rescheduling complete. Your timeline has been updated.",
    "task_priority": "High priority task detected. I recommend focusing on this immediately.",
    "break_suggest": "Sir, you have been working for three hours. I suggest a five-minute break.",

    # ======================================================
    # WEB & INFORMATION GATHERING
    # ======================================================
    "search_start": "Searching the global network for the requested information.",
    "search_found": "Search complete. I have found several relevant results.",
    "search_none": "I am sorry, my search yielded no results in the public domain.",
    "news_update": "Retrieving the latest headlines from your preferred sources.",
    "weather_alert": "External sensors report a change in weather conditions.",

    # ======================================================
    # SOCIAL MEDIA & CREATOR TOOLS
    # ======================================================
    "record_start": "Screen recording initiated. Capture in progress.",
    "record_stop": "Recording finalized and saved to the D drive.",
    "upload_ready": "The video is rendered and ready for upload to social media.",
    "post_success": "Content has been successfully shared to your network.",

    # ======================================================
    # SMART HOME & AMBIENCE (Future Proofing)
    # ======================================================
    "light_on": "Illumination active.",
    "light_off": "Damping lights. Entering dark mode.",
    "temp_set": "Climate control adjusted to your preference.",
    "music_start": "Accessing your playlist. Audio playback initiated.",

    # ======================================================
    # CONVERSATIONAL "BRIDGES" (Use these to connect sounds)
    # ======================================================
    "bridge_and": "Additionally,",
    "bridge_but": "However,",
    "bridge_then": "Followed by,",
    "bridge_so": "Therefore,",
    "bridge_please": "Please,",
    "bridge_sir": "Sir,",
    "bridge_now": "Starting now.",

    # ======================================================
    # ERROR & PROBLEM SOLVING
    # ======================================================
    "fix_attempt": "Attempting to resolve the conflict automatically.",
    "fix_success": "Repair successful. System stability restored.",
    "fix_fail": "Automatic repair failed. Manual intervention required.",
    "waiting_input": "Standing by for your input, Sir.",
    # ======================================================
    # DATA & ANALYSIS (For when you use LLMs later)
    # ======================================================
    "analysis_deep": "Running deep heuristic analysis on the provided data set.",
    "analysis_patterns": "I have identified several recurring patterns in your activity logs.",
    "analysis_insight": "Sir, I have a new insight regarding your current project.",
    "data_corrupted": "Warning: Data packets appear corrupted. Attempting recovery.",
    "data_sync": "Synchronizing local data with cloud storage. Please wait.",

    # ======================================================
    # PERSONALITY & "SASS" (For a real Jarvis feel)
    # ======================================================
    "humor_ironic": "Intriguing choice, Sir. Highly unconventional.",
    "praise_brilliant": "That is a brilliant logic flow, Sir. Well played.",
    "gentle_reminder": "I hate to interrupt, but your current trajectory seems suboptimal.",
    "sarcasm_low_battery": "I'm running on fumes here, Sir. A power source would be appreciated.",
    "logic_flaw": "Sir, my calculations suggest that logic may be flawed. Shall I double-check?",

    # ======================================================
    # EMERGENCY & HIGH ALERT
    # ======================================================
    "emergency_protocol": "Initiating emergency protocol Alpha-One. All non-essential systems cut.",
    "threat_detected": "Unauthorized access attempt detected on the network firewall.",
    "lockdown": "System lockdown engaged. Input blocked until biometric verification.",
    "thermal_critical": "Thermal runaway detected! Shutdown imminent to protect the R T X 20 50.",

    # ======================================================
    # NUMBERS & UNITS (The "Building Blocks")
    # ======================================================
    # These allow MIND to say "10 percent" or "Level 5" by combining sounds
    "num_percent": "percent.",
    "num_degrees": "degrees.",
    "num_level": "level.",
    "num_completed": "completed.",
    "num_remaining": "remaining.",

    # ======================================================
    # BRIDGES (Enhanced)
    # ======================================================
    "bridge_furthermore": "Furthermore,",
    "bridge_nonetheless": "Nonetheless,",
    "bridge_as_requested": "As you requested,",
    "bridge_in_conclusion": "In conclusion, Sir,",
    # ======================================================
    # INTRODUCTION & IDENTITY
    # ======================================================
    "intro_short": "I am MIND. The Ma-kee-pan Intelligence Network Device.",
    "intro_full": "I am MIND. An advanced intelligence network device, engineered by Ma-kee-pan. My core is powered by local neural networks, and I am designed to optimize your digital environment and manage your complex scheduling needs.",
    "intro_purpose": "My purpose is to serve as your primary interface for system management, scheduling, and tactical data analysis.",
    "intro_hardware": "My consciousness currently resides on this hardware, utilizing an R T X 20 50 for all high-speed heuristic processing.",
    "intro_creator": "I was initialized and refined by Ma-kee-pan. I am the first of my kind.",
}


print("--- GENERATING PERMANENT VOICE ASSETS ---")

for name, text in sound_bank.items():
    file_path = f"{ASSETS_DIR}/{name}.mp3"
    
    # THE SAFETY CHECK:
    if os.path.exists(file_path):
        print(f"Skipping {name}.mp3 - Already exists (Credits Saved!)")
        continue
        
    print(f"Creating {name}.mp3...")
    audio = generate(text=text, voice=VOICE_ID, model="eleven_multilingual_v2")
    save(audio, file_path)

print("\nSUCCESS! All sounds are saved on your D: drive. You never need credits for these again.")