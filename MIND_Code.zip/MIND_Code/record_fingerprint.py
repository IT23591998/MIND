import sounddevice as sd
import numpy as np
from scipy.io.wavfile import write

# Settings
fs = 44100  
duration = 30  
filename = "D:/MIND_Project/assets/my_voice_sample.wav"
device_id = 2  # Forced to your Realtek Microphone Array

print("--- INITIALIZING CALIBRATED MEMORY ---")

try:
    # Pre-allocate memory
    my_recording = np.zeros((duration * fs, 1), dtype='int16')

    print(f"Using Device: {device_id}")
    print("Speak naturally. Starting in 3... 2... 1...")
    
    # Record using the specific device index
    sd.rec(duration * fs, samplerate=fs, channels=1, dtype='int16', out=my_recording, device=device_id)
    sd.wait()  # Wait until recording is finished

    # Save the file
    write(filename, fs, my_recording)
    print(f"SUCCESS! Fingerprint saved to: {filename}")
    print("Go to the folder and play the file to verify you can hear your voice.")

except Exception as e:
    print(f"Hardware Error: {e}")
    print("TIP: Ensure Windows Privacy settings allow microphone access.")