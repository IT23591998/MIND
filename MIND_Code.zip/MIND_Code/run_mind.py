import torch
from TTS.api import TTS
import os
import sys
import gc

# --- CONFIGURATION ---
# The Folder where your brain lives
MODEL_DIR = r"D:\MIND_Project\tts_models\tts\tts_models--multilingual--multi-dataset--xtts_v2"

# We still define these to check if they exist, but we won't pass them to the AI loader directly
MODEL_PATH = os.path.join(MODEL_DIR, "model.pth")
CONFIG_PATH = os.path.join(MODEL_DIR, "config.json")

REF_AUDIO = "assets/system_core.wav"
OUTPUT_FILE = "voice_test.wav"
TEXT = "Systems initialized. I am running in Safe Mode on the CPU."

# Low RAM Settings
torch.set_num_threads(1)
os.environ["OMP_NUM_THREADS"] = "1"
# ---------------------

print("   [1/5] Checking environment...")

# Verify files exist before loading
if not os.path.exists(MODEL_PATH):
    print(f"   [CRITICAL] Missing file: {MODEL_PATH}")
    sys.exit(1)

print("   [2/5] Loading AI Model... (This will take 30-60 seconds)")

try:
    # --- THE FIX IS HERE ---
    # We pass 'MODEL_DIR' (the folder) instead of the file.
    # The library will auto-complete it to ".../model.pth"
    tts = TTS(model_path=MODEL_DIR, config_path=CONFIG_PATH, progress_bar=False).to("cpu")
    print("   [3/5] Model Loaded Successfully!")
except Exception as e:
    print(f"   [FAIL] Crash Details: {e}")
    sys.exit(1)

print("   [4/5] Generating Audio...")
try:
    tts.tts_to_file(text=TEXT, speaker_wav=REF_AUDIO, language="en", file_path=OUTPUT_FILE)
    print("   [5/5] Success! Opening audio...")
    os.system(f"start {OUTPUT_FILE}")
except Exception as e:
    print(f"   [FAIL] Generation Error: {e}")