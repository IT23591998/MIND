
import sys
import os
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init
init(autoreset=True)

def test_matter_db():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    print("\n--- Testing Element Lookup ---")
    
    # 1. Test 'Gold'
    print("Query: Gold")
    res1 = agent.get_element_info("Gold")
    if res1 and "196.97" in res1:
        print("✅ Gold Lookup PASSED")
    else:
        print(f"❌ Gold Lookup FAILED: {res1}")

    # 2. Test 'H'
    print("Query: H")
    res2 = agent.get_element_info("H")
    if res2 and "1.008" in res2:
        print("✅ Hydrogen Lookup PASSED")
    else:
        print(f"❌ Hydrogen Lookup FAILED: {res2}")
        
    # 3. Test Invalid
    print("Query: Vibranium")
    res3 = agent.get_element_info("Vibranium")
    if "not found" in res3:
        print("✅ Negative Test PASSED")
    else:
        print(f"❌ Negative Test FAILED: {res3}")

if __name__ == "__main__":
    test_matter_db()
