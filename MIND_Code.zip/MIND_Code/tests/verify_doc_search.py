
import sys
import os
import json
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init
init(autoreset=True)

def test_doc_retrieval():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    # 1. Create Dummy File
    dummy_path = "d:/test_presentation_slide.pptx"
    with open(dummy_path, "w") as f:
        f.write("dummy content")
    
    # 2. Inject into Index (Simulate Scan)
    print("Injecting dummy file into memory index...")
    agent.file_index.append(dummy_path)
    
    # 3. Test Search
    print("\n--- Testing Search Logic ---")
    query = "presentation slide"
    print(f"Query: '{query}'")
    
    result = agent.search_file(query)
    
    status = "FAIL"
    if result and "test_presentation_slide.pptx" in result:
        print(f"✅ Found match: {result}")
        status = "PASS"
    else:
        print(f"❌ Failed. Result: {result}")

    # 4. Clean up
    if os.path.exists(dummy_path):
        os.remove(dummy_path)
        
    return status

if __name__ == "__main__":
    test_doc_retrieval()
