
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from modules.security_agent import SecurityAgent
from colorama import init, Fore

init(autoreset=True)

def verify_phase2():
    print(Fore.WHITE + "========================================")
    print(Fore.WHITE + "   VERIFYING MIND V2.6 OSINT PHASE 2")
    print(Fore.WHITE + "========================================")
    
    agent = SecurityAgent()
    
    # 1. Test SSL Check
    print(Fore.YELLOW + "\n[TEST 1] SSL Certificate (google.com)")
    ssl_res = agent.run_ssl_check("www.google.com")
    print(f"Result: {ssl_res}")

    # 2. Test Headers
    print(Fore.YELLOW + "\n[TEST 2] HTTP Headers (google.com)")
    header_res = agent.analyze_headers("https://www.google.com")
    print(f"Result: {header_res}")

    # 3. Test Dorks
    print(Fore.YELLOW + "\n[TEST 3] Google Dorks (example.com)")
    dorks = agent.generate_dorks("example.com")
    for d in dorks:
        print(f"   > {d}")

    # 4. Test MAC Vendor
    print(Fore.YELLOW + "\n[TEST 4] MAC Vendor (00:11:22... - Cisco)")
    mac_res = agent.lookup_mac("00:11:22:33:44:55")
    print(f"Result: {mac_res}")

    print(Fore.GREEN + "\n✅ Phase 2 Verification Completed")

if __name__ == "__main__":
    verify_phase2()
