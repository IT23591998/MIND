import unittest
from modules.SecurityAgent import SecurityAgent

class TestJohnTheRipper(unittest.TestCase):
    def setUp(self):
        self.agent = SecurityAgent()

    def test_find_john(self):
        # We expect it might fail if user hasn't installed it, but method should run without error
        path = self.agent.find_john()
        print(f"\nJtR Path found: {path}")
        # Not asserting IsNotNone because user might not have it yet.
        # Just verifying the logic doesn't crash.

    def test_crack_hash_simulation(self):
        # We can't easily test actual cracking without binary.
        # Check if it gracefully handles missing binary.
        if not self.agent.john_path:
            res = self.agent.crack_hash("5f4dcc3b5aa765d61d8327deb882cf99")
            self.assertIn("not installed", res)
        else:
            # If installed, simple test (5f4... is 'password')
            res = self.agent.crack_hash("5f4dcc3b5aa765d61d8327deb882cf99")
            print(f"Crack Result: {res}")

if __name__ == '__main__':
    unittest.main()
