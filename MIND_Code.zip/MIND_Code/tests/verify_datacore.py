
import sys
import os
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
import pandas as pd

def test_datacore():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    # Create dummy data
    data = {
        'A': [1, 2, 3, 4, 5, None],
        'B': ['x', 'y', 'x', 'y', 'x', None],
        'Target': [10, 20, 30, 40, 50, 60]
    }
    df = pd.DataFrame(data)
    csv_path = "d:/MIND_Project/temp_test_data.csv"
    df.to_csv(csv_path, index=False)
    
    print("\n--- Testing Diagnostic ---")
    report = agent.analyze_diagnostic(csv_path)
    if "Stat Summary" in report or "Stats Summary" in report:
        print("Diagnostic Test PASSED")
    else:
        print("Diagnostic Test FAILED")
        
    print("\n--- Testing Predictive ---")
    result = agent.analyze_predictive(csv_path, "Target")
    if "Model Selected" in result:
        print("Predictive Test PASSED")
    else:
        print("Predictive Test FAILED")

    # Clean up
    if os.path.exists(csv_path):
        os.remove(csv_path)

if __name__ == "__main__":
    test_datacore()
