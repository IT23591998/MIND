import unittest
import os
import hashlib
from modules.sentinel import Sentinel

class TestSentinel(unittest.TestCase):
    def setUp(self):
        self.sentinel = Sentinel()
        self.sentinel.hashes_file = "D:/MIND_Project/test_hashes.json"
        if os.path.exists(self.sentinel.hashes_file):
            os.remove(self.sentinel.hashes_file)

    def tearDown(self):
        if os.path.exists(self.sentinel.hashes_file):
            os.remove(self.sentinel.hashes_file)

    def test_startup_baseline(self):
        # 1. First run: Should establish baseline
        res = self.sentinel.integrity_check()
        self.assertIn("Baseline established", res)
        self.assertTrue(os.path.exists(self.sentinel.hashes_file))

        # 2. Second run: Should be verified
        res2 = self.sentinel.integrity_check()
        self.assertIn("Verified", res2)

    def test_password_auth(self):
        # Correct (1234)
        print(f"Test Debug: '1234' -> {self.sentinel.verify_password('1234')}")
        self.assertTrue(self.sentinel.verify_password("1234"))
        
        # Incorrect
        self.assertFalse(self.sentinel.verify_password("beta2"))
        self.assertFalse(self.sentinel.verify_password("admin"))

    def test_sanitization(self):
        bad = "rm -rf /; echo hack"
        clean = self.sentinel.sanitize_input(bad)
        self.assertNotIn(";", clean)
        self.assertIn("rm -rf /", clean) # Still text, but chaining broken

if __name__ == '__main__':
    unittest.main()
