import sounddevice as sd
from scipy.io.wavfile import write
from faster_whisper import WhisperModel
import os

# 1. TELL THE AI WHERE TO SAVE & LOOK FOR MODELS (D: DRIVE)
# This folder will store the model so it never downloads again.
model_dir = "D:/MIND_Project/models"
if not os.path.exists(model_dir):
    os.makedirs(model_dir)

print("--- INITIALIZING MIND EARS (RTX 2050) ---")

# We use 'download_root' to force it to stay on the D: drive
model = WhisperModel("tiny", device="cuda", compute_type="float16", download_root=model_dir)

print("Success: Ears are ready and localized on D: drive.")

# 2. RECORDING
fs = 16000
duration = 8 
print(f"\n[LISTENING] Recording for {duration} seconds... Speak now!")

recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
sd.wait()
write("test_audio.wav", fs, recording)

# 3. TRANSCRIBING
print("\n[THINKING] RTX 2050 is processing...")
segments, _ = model.transcribe("test_audio.wav")

print("\n--- RESULT ---")
for segment in segments:
    print(f"MIND heard: {segment.text}")