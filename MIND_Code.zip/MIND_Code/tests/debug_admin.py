from modules.admin_agent import AdminAgent
import os

print("--- DEBUG START ---")
if os.path.exists("D:/MIND_Project/test_tasks_debug.json"):
    os.remove("D:/MIND_Project/test_tasks_debug.json")

agent = AdminAgent()
agent.tasks_file = "D:/MIND_Project/test_tasks_debug.json"
agent._load_tasks()

print(f"Initial Tasks: {agent.tasks}")

# 1. ADD
print("Adding task...")
res = agent.add_task("Test Task")
print(f"Add Result: {res}")
print(f"Tasks after add: {agent.tasks}")

# 2. LIST
print("Listing tasks...")
lst = agent.list_tasks()
print(f"List Output:\n{lst}")

if "Test Task" not in lst:
    print("FAIL: Task not in list")

# 3. COMPLETE
print("Completing task 1...")
res = agent.complete_task("1")
print(f"Complete Result: {res}")

if "marked as complete" not in res:
    print("FAIL: Could not complete task")

# 4. LIST AGAIN
print("Listing after complete...")
lst_final = agent.list_tasks()
print(f"Final List:\n{lst_final}")

if "No pending tasks" not in lst_final:
    print("FAIL: List should be empty of pending tasks")

print("--- DEBUG END ---")
