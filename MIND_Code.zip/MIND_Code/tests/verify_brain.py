import unittest
from unittest.mock import MagicMock
from mind_brain import MindBrain

class TestBrainRouting(unittest.TestCase):
    def setUp(self):
        self.brain = MindBrain()
        # Mock completion to avoid API calls
        self.brain.brains['THEORIST']['api_key'] = "test"
        self.brain.brains['CODER']['api_key'] = "test"
        self.brain.brains['SECURITY']['api_key'] = "test"

    def test_routing_theorist(self):
        key = self.brain._determine_brain("Explain the theory of relativity")
        self.assertEqual(key, "THEORIST")

    def test_routing_coder(self):
        key = self.brain._determine_brain("Write a python script to sort a list")
        self.assertEqual(key, "CODER")

    def test_routing_security(self):
        key = self.brain._determine_brain("Perform an osint scan on this user")
        self.assertEqual(key, "SECURITY")

    def test_routing_analyst(self):
        key = self.brain._determine_brain("Analyze this data and plot a graph")
        self.assertEqual(key, "ANALYST")

    def test_routing_default(self):
        key = self.brain._determine_brain("Hello mind, how are you?")
        self.assertEqual(key, "MANAGER")

if __name__ == '__main__':
    unittest.main()
