import torch
import os
import sys

# Path to your model folder
MODEL_DIR = r"D:\MIND_Project\tts_models\tts\tts_models--multilingual--multi-dataset--xtts_v2"

files_to_check = [
    "model.pth", 
    "dvae.pth", 
    "speakers_xtts.pth"
]

print(f"--- STARTING MRI SCAN OF BRAIN AT: {MODEL_DIR} ---\n")

for filename in files_to_check:
    filepath = os.path.join(MODEL_DIR, filename)
    print(f"👉 Checking {filename}...")
    
    if not os.path.exists(filepath):
        print(f"   [CRITICAL] File missing: {filename}")
        continue
        
    try:
        # We try to map the file to CPU memory
        # This will fail with a clear error if the file is truncated or corrupt
        checkpoint = torch.load(filepath, map_location="cpu", weights_only=False)
        print(f"   [OK] {filename} is healthy.")
        
        # Clear memory immediately to prevent RAM overflow
        del checkpoint
        
    except Exception as e:
        print(f"   [FAIL] {filename} is CORRUPT/BROKEN!")
        print(f"   Error details: {str(e)[:100]}...") # Print first 100 chars of error
        
print("\n--- SCAN COMPLETE ---")