
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from modules.security_agent import SecurityAgent
from colorama import init, Fore

init(autoreset=True)

def verify_argus():
    print(Fore.WHITE + "========================================")
    print(Fore.WHITE + "   VERIFYING ARGUS PROTOCOL (Social Recon)")
    print(Fore.WHITE + "========================================")
    
    agent = SecurityAgent()
    
    target = "microsoft" # Known public handle
    print(Fore.YELLOW + f"\n[TEST] Launching Argus Scan for target: '{target}'")
    
    results = agent.run_argus_scan(target)
    
    print("-" * 30)
    if "GitHub" in results and "Twitter" in results:
        print(Fore.GREEN + "✅ Argus Scan Successful (Major platforms detected)")
    else:
        print(Fore.YELLOW + "⚠️  Argus Scan Completed (Check coverage manually)")
    
    print(f"Total Profiles Found: {len(results)}")

if __name__ == "__main__":
    verify_argus()
