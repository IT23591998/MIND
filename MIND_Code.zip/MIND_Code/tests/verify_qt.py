import unittest
from unittest.mock import MagicMock, patch, mock_open
import os
import shutil

from modules.qt_agent import QtAgent

class TestQtAgent(unittest.TestCase):
    def setUp(self):
        # Patch config queues
        self.speech_patcher = patch('config.speech_queue')
        self.mock_speech = self.speech_patcher.start()
        self.addCleanup(self.speech_patcher.stop)
        
        self.hud_patcher = patch('config.hud_queue')
        self.mock_hud = self.hud_patcher.start()
        self.addCleanup(self.hud_patcher.stop)
        
        self.agent = QtAgent()
        self.agent.projects_root = "TestQtProjects"
        if not os.path.exists("TestQtProjects"):
            os.makedirs("TestQtProjects")
            
    def tearDown(self):
        if os.path.exists("TestQtProjects"):
            shutil.rmtree("TestQtProjects")

    @patch('subprocess.Popen')
    def test_create_project(self, mock_popen):
        res = self.agent.create_project("TestApp")
        print(f"Qt Result: {res}")
        self.assertIn("Created TestApp", res)
        
        # Verify files
        base = os.path.join("TestQtProjects", "TestApp")
        self.assertTrue(os.path.exists(os.path.join(base, "TestApp.pro")))
        self.assertTrue(os.path.exists(os.path.join(base, "main.cpp")))
        self.assertTrue(os.path.exists(os.path.join(base, "mainwindow.cpp")))
        
        # Verify Launch
        mock_popen.assert_called()

if __name__ == '__main__':
    unittest.main()
