import unittest
from unittest.mock import MagicMock, patch
import os
import sys

# Mocks
sys.modules['pyperclip'] = MagicMock()
sys.modules['deepface'] = MagicMock()
sys.modules['ollama'] = MagicMock()
sys.modules['cv2'] = MagicMock()
sys.modules['mind_brain'] = MagicMock()
sys.modules['langchain'] = MagicMock()
sys.modules['langchain.document_loaders'] = MagicMock()
sys.modules['langchain.vectorstores'] = MagicMock()
sys.modules['langchain.embeddings'] = MagicMock()
sys.modules['langchain.text_splitter'] = MagicMock()

from modules.boost_agent import BoostAgent
from modules.grant_agent import GrantAgent
from modules.emotion_agent import EmotionAgent
from modules.xr_agent import XRAgent
from modules.knowledge_agent import KnowledgeAgent

class TestLevel6(unittest.TestCase):
    def test_boost(self):
        agent = BoostAgent()
        sys.modules['pyperclip'].paste.return_value = "def foo(): pass"
        
        # Mock brain think
        agent.brain = MagicMock()
        agent.brain.think.return_value = "def foo(): return True"
        
        res = agent.optimize_code()
        print(f"Boost: {res}")
        self.assertIn("Optimized", res)

    def test_grant(self):
        agent = GrantAgent()
        res = agent.scan_grants("AI")
        print(f"Grant: {res}")
        self.assertIn("Found", res)

    def test_emotion(self):
        agent = EmotionAgent() # Will assume deepface import worked due to sys.modules mock? 
        # Actually our module does try/except ImportError.
        # Since we mocked sys.modules['deepface'], import should succeed.
        
        # Mock DeepFace.analyze
        sys.modules['deepface'].DeepFace.analyze.return_value = [{'dominant_emotion': 'happy'}]
        # Mock CV2
        sys.modules['cv2'].VideoCapture.return_value.read.return_value = (True, MagicMock())
        
        res = agent.detect_mood()
        print(f"Emotion: {res}")
        self.assertEqual(res, "happy")

    def test_xr(self):
        agent = XRAgent()
        agent.xr_root = "TestXR"
        res = agent.create_ar_project("TestApp")
        print(f"XR: {res}")
        self.assertIn("created", res)
        # Cleanup
        import shutil
        if os.path.exists("TestXR"):
            shutil.rmtree("TestXR")

    def test_rag_v2(self):
        agent = KnowledgeAgent()
        # Mock vector db
        agent.vector_db = MagicMock()
        mock_doc = MagicMock()
        mock_doc.page_content = "Context"
        agent.vector_db.similarity_search.return_value = [mock_doc]
        
        # Mock Ollama
        sys.modules['ollama'].generate.return_value = {'response': 'Ollama Answer'}
        
        res = agent.query_knowledge("Question")
        print(f"RAG V2: {res}")
        self.assertEqual(res, "Ollama Answer")

if __name__ == '__main__':
    unittest.main()
