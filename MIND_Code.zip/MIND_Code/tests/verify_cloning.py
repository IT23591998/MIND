import sys
import os
import shutil
from colorama import init, Fore

sys.path.append(os.getcwd())

from modules.cloning import MindClone
from mind_brain import MindBrain

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + "🚀 Starting Cloning Verification...")
    
    # 1. Setup Project Name
    project = "Test_Project_Alpha"
    print(Fore.CYAN + f"   Creating Clone for: {project}")
    
    # Clean up old test data
    clone_path = f"d:/MIND_Project/memory/clones/{project.lower()}.json"
    if os.path.exists(clone_path):
        os.remove(clone_path)
        
    clone = MindClone(project)
    brain = MindBrain() # Main brain instance for processing
    
    # 2. Interact
    response = clone.interact("What is the primary goal of this project?", brain)
    print(Fore.YELLOW + f"   Clone Response: {response[:100]}...")
    
    # 3. Verify Persistence
    print(Fore.CYAN + "   Verifying File Persistence...")
    if os.path.exists(clone_path):
        print(Fore.GREEN + f"✅ Memory File Created: {clone_path}")
        
        # Check size
        size = os.path.getsize(clone_path)
        if size > 10:
            print(Fore.GREEN + f"✅ Memory File has content ({size} bytes).")
        else:
            print(Fore.RED + "❌ Memory File empty.")
    else:
        print(Fore.RED + "❌ Memory File NOT created.")

if __name__ == "__main__":
    run_verification()
