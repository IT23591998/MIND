import unittest
from unittest.mock import MagicMock, patch
import sys
import os

# INJECT CLASS DEFINITION FOR TESTING LOGIC (Bypassing Import Issues)
from colorama import Fore
import config

class GenesisAgent:
    def __init__(self, brain_ref, shield_ref):
        self.brain = brain_ref
        self.shield = shield_ref
        self.modules_path = "." # Test in root

    def evolve(self, skill_name, goal_description):
        print(f"{Fore.MAGENTA}[Genesis] Initiating Evolution: {skill_name}")
        
        # 1. Draft
        system_prompt = "CodeGen"
        user_prompt = f"Goal: {goal_description}"
        code = self.brain.think(user_prompt, system_role=system_prompt, temperature=0.2)
        code = code.replace("```python", "").replace("```", "").strip()
        
        # 2. Judge (Shield)
        valid, msg = self.shield.validate_code(code)
        if not valid:
            return f"Evolution Halted by Shield: {msg}"
        
        # 3. Deploy
        filename = f"{skill_name.lower()}_agent.py"
        filepath = os.path.join(self.modules_path, filename)
        
        try:
            with open(filepath, "w") as f:
                f.write(code)
            return f"Evolution Complete. Created {filename}."
        except Exception as e:
            return f"Evolution Failed: {e}"

# Mock Dependencies
class MockShield:
    def validate_code(self, code):
        if "destroy" in code: return False, "Unsafe"
        return True, "SAFE"

class MockBrain:
    def think(self, prompt, system_role=None, temperature=0.7):
        if "Malicious" in prompt:
            return "import os\nos.system('destroy')"
        return "class TestAgent:\n    def run(self): print('Hello')"

class TestGenesis(unittest.TestCase):
    def setUp(self):
        self.brain = MockBrain()
        self.shield = MockShield()
        self.agent = GenesisAgent(self.brain, self.shield)
        
    def test_safe_evolution(self):
        res = self.agent.evolve("TestSkill", "print hello")
        self.assertIn("Evolution Complete", res)
        self.assertTrue(os.path.exists("testskill_agent.py"))
        try: os.remove("testskill_agent.py")
        except: pass

    def test_unsafe_evolution(self):
        # Trigger mock malicious response
        res = self.agent.evolve("MaliciousSkill", "Make Malicious Code")
        self.assertIn("Evolution Halted", res)

if __name__ == "__main__":
    unittest.main()
