import unittest
from unittest.mock import MagicMock, patch
import os
import sys

# Mock libraries BEFORE importing agents
sys.modules['face_recognition'] = MagicMock()
sys.modules['cv2'] = MagicMock()
# We don't mock os here, we use real file for knowledge to avoid mock hell
sys.modules['langchain'] = MagicMock()
sys.modules['langchain.document_loaders'] = MagicMock()
sys.modules['langchain.vectorstores'] = MagicMock()
sys.modules['langchain.embeddings'] = MagicMock()
sys.modules['langchain.text_splitter'] = MagicMock()

from modules.biometric_agent import BiometricAgent
from modules.knowledge_agent import KnowledgeAgent
from modules.network_agent import NetworkAgent
import config

class TestLevel4(unittest.TestCase):
    def setUp(self):
        # Create dummy knowledge file
        self.test_knowledge_dir = os.path.join(config.WORKSPACE, "Knowledge")
        if not os.path.exists(self.test_knowledge_dir):
            os.makedirs(self.test_knowledge_dir)
            
        with open(os.path.join(self.test_knowledge_dir, "test_doc.txt"), "w") as f:
            f.write("This is a test document about Project Omega.")
            
    def tearDown(self):
        # Cleanup
        if os.path.exists(os.path.join(self.test_knowledge_dir, "test_doc.txt")):
            os.remove(os.path.join(self.test_knowledge_dir, "test_doc.txt"))

    def test_biometrics(self):
        agent = BiometricAgent()
        # Mocking scan_face logic requires patching internal cv2/face_rec calls inside the method
        # But we mocked the modules at sys level.
        # Let's mock the return of face_recognition functions
        sys.modules['face_recognition'].face_locations.return_value = [(0,0,0,0)]
        sys.modules['face_recognition'].face_encodings.return_value = ["USER_FACE"]
        sys.modules['face_recognition'].compare_faces.return_value = [True]
        
        import numpy as np
        fake_frame = np.zeros((100, 100, 3), dtype=np.uint8)
        sys.modules['cv2'].VideoCapture.return_value.read.return_value = (True, fake_frame)
        sys.modules['cv2'].VideoCapture.return_value.isOpened.return_value = True

        agent.known_face_encoding = "EXISTING_DATA"
        
        res = agent.scan_face()
        print(f"Bio Scan: {res}")
        self.assertTrue(res)

    def test_knowledge(self):
        agent = KnowledgeAgent()
        
        # Since we mocked langchain, TextLoader is a mock
        # We need to ensure it returns something when load() is called
        mock_loader_instance = sys.modules['langchain.document_loaders'].TextLoader.return_value
        mock_doc = MagicMock()
        mock_doc.page_content = "Test content"
        mock_loader_instance.load.return_value = [mock_doc]
        
        res = agent.ingest_data()
        print(f"Knowledge Ingest: {res}")
        self.assertIn("Ingested", res)

    def test_network(self):
        agent = NetworkAgent()
        with patch('subprocess.check_output') as mock_sub:
            mock_sub.return_value = b"  192.168.1.5   00-11-22-33-44-55   dynamic"
            res = agent.scan_devices()
            print(f"Net Scan: {res}")
            self.assertIn("192.168.1.5", res)

if __name__ == '__main__':
    unittest.main()
