import unittest
import os
import shutil
import json
from modules.admin_agent import AdminAgent

class TestAdminAgent(unittest.TestCase):
    def setUp(self):
        self.agent = AdminAgent()
        self.original_tasks = self.agent.tasks_file
        self.test_tasks = "D:/MIND_Project/test_tasks.json"
        
        # Point to test file
        self.agent.tasks_file = self.test_tasks
        if os.path.exists(self.test_tasks):
            os.remove(self.test_tasks)
        self.agent._load_tasks()

    def tearDown(self):
        if os.path.exists(self.test_tasks):
            os.remove(self.test_tasks)
        self.agent.tasks_file = self.original_tasks

    def test_add_list_complete(self):
        # 1. Add
        res = self.agent.add_task("Buy milk")
        self.assertIn("added", res)
        self.assertEqual(len(self.agent.tasks), 1)

        # 2. List
        lst = self.agent.list_tasks()
        self.assertIn("Buy milk", lst)

        # 3. Complete
        res = self.agent.complete_task("1")
        self.assertIn("complete", res)
        
        # 4. Verify list is empty(ish)
        lst_final = self.agent.list_tasks()
        self.assertIn("No pending tasks", lst_final)

if __name__ == '__main__':
    unittest.main()
