import hashlib
import os

FILE_PATH = r"D:\MIND_Project\tts_models\tts\tts_models--multilingual--multi-dataset--xtts_v2\model.pth"
EXPECTED_HASH = "c7ea20001c6a0a841c77e252d8409f6a74fb423e79b3206a0771ba5989776187"

print(f"--- CHECKING BRAIN INTEGRITY ---")
print(f"File: {FILE_PATH}")

if not os.path.exists(FILE_PATH):
    print("[ERROR] File does not exist!")
    exit()

print("Calculating Hash... (Please wait 1-2 minutes)...")

# Calculate hash in small chunks to avoid memory crash
sha256_hash = hashlib.sha256()
try:
    with open(FILE_PATH, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
            
    your_hash = sha256_hash.hexdigest()
    
    print(f"\nExpected: {EXPECTED_HASH}")
    print(f"Actual:   {your_hash}")

    if your_hash == EXPECTED_HASH:
        print("\n[PASS] The file is PERFECT. Your download is good.")
        print("Diagnosis: The crash is likely caused by LOW RAM.")
    else:
        print("\n[FAIL] The file is CORRUPT.")
        print("Diagnosis: The download was damaged. You need to re-download.")

except Exception as e:
    print(f"\n[CRITICAL] Could not read file: {e}")