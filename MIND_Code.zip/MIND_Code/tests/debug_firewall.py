import sys
from unittest.mock import MagicMock
import traceback

# MOCK EVERYTHING
sys.modules['psutil'] = MagicMock()
sys.modules['biometric_agent'] = MagicMock()
sys.modules['modules.biometric_agent'] = MagicMock()
sys.modules['threading'] = MagicMock()
sys.modules['hashlib'] = MagicMock()
sys.modules['config'] = MagicMock()
sys.modules['config'].ROOT_DIR = "."

try:
    print("Importing FirewallAgent...")
    from modules.firewall_agent import FirewallAgent
    print("Instantiating...")
    agent = FirewallAgent()
    print("Success!")
except Exception:
    traceback.print_exc()
