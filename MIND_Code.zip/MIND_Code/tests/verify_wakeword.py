import unittest
from unittest.mock import MagicMock, patch
import sys
import numpy as np

# Mock Dependencies BEFORE import
sys.modules['openwakeword'] = MagicMock()
sys.modules['openwakeword.model'] = MagicMock()
sys.modules['sounddevice'] = MagicMock()
sys.modules['psutil'] = MagicMock()
sys.modules['mind_core_loop'] = MagicMock()

# Import
import mind_orchestrator as orch

class TestOrchestrator(unittest.TestCase):
    def test_wake_logic(self):
        # Force HAS_WAKE to True
        orch.HAS_WAKE = True
        
        # Setup Mock Model
        mock_model = MagicMock()
        # Simulation: 
        # 1. Predict -> 0.0
        # 2. Predict -> 0.9 (Trigger) -> Handshake -> Active Session
        # 3. Predict -> Stop Loop
        mock_model.predict.side_effect = [
            {'hey_jarvis': 0.0},
            {'hey_jarvis': 0.9},
            StopIteration # Break the while True loop
        ]
        
        # Mock Audio Stream
        mock_stream = MagicMock()
        mock_stream.read.return_value = (np.zeros(1280), False)
        sys.modules['sounddevice'].InputStream.return_value.__enter__.return_value = mock_stream
        
        # Mock Bio/Core
        sys.modules['mind_core_loop'].bio_bot.scan_face.return_value = True
        
        with patch('mind_orchestrator.Model', return_value=mock_model):
            try:
                orch.wake_loop()
            except StopIteration:
                pass
            except Exception as e:
                print(f"Loop Error: {e}")
                
        # Assertions
        # 1. Did we scan face?
        sys.modules['mind_core_loop'].bio_bot.scan_face.assert_called()
        
        # 2. Did we enter active session?
        sys.modules['mind_core_loop'].active_session_loop.assert_called()
        
        print("Wake Word & Handshake Logic Verified.")

if __name__ == '__main__':
    unittest.main()
