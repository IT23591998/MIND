import speech_recognition as sr
from faster_whisper import WhisperModel
import os

print("\n--- STAGE 1: Testing Whisper Load ---")
try:
    # We use 'int8' and 'cpu' for maximum compatibility
    model = WhisperModel("tiny.en", device="cpu", compute_type="int8")
    print("[SUCCESS] Whisper model loaded onto CPU.")
except Exception as e:
    print(f"[FAIL] Whisper could not load: {e}")
    exit()

print("\n--- STAGE 2: Testing Microphone Access ---")
r = sr.Recognizer()
try:
    # Using Index 2 as we identified earlier
    with sr.Microphone(device_index=2) as source:
        print("[SUCCESS] Microphone index 2 opened.")
        print(">>> SAY SOMETHING NOW...")
        audio = r.listen(source, timeout=5, phrase_time_limit=5)
        print("[SUCCESS] Audio captured.")
except Exception as e:
    print(f"[FAIL] Microphone error: {e}")
    exit()

print("\n--- STAGE 3: Testing Local Transcription ---")
try:
    with open("debug_test.wav", "wb") as f:
        f.write(audio.get_wav_data())
    
    segments, _ = model.transcribe("debug_test.wav", beam_size=1)
    text = "".join([s.text for s in segments])
    
    print(f"\n[RESULT] Whisper heard: '{text}'")
    print("\n--- DEBUG COMPLETE: ALL SYSTEMS FUNCTIONAL ---")
except Exception as e:
    print(f"[FAIL] Transcription crash: {e}")