import unittest
from unittest.mock import MagicMock
from modules.accountant_agent import AccountantAgent

class TestSheetsSync(unittest.TestCase):
    def setUp(self):
        self.agent = AccountantAgent()

    def test_sync_no_creds(self):
        # We expect a friendly error message since we don't have the JSON file locally on the agent's env
        res = self.agent.sync_to_sheets()
        print(f"Sync Result (No Creds): {res}")
        self.assertIn("Creation failed", res)

if __name__ == '__main__':
    unittest.main()
