
import sys
import os
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init
init(autoreset=True)

def test_drive_scan():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    print("\n--- Testing Storage Intelligence (Drive Scan) ---")
    # This might take a moment, so we print before
    summary = agent.scan_system_drives()
    
    if "Drives Scanned" in summary:
        print("\n✅ Drive Scan Verified!")
        print(summary)
    else:
        print("\n❌ Drive Scan Failed (No summary returned)")

if __name__ == "__main__":
    test_drive_scan()
