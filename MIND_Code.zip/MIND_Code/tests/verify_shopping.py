
import sys
import os
sys.path.append("d:/MIND_Project")
from modules.geo_agent import GeoAgent
from colorama import init
init(autoreset=True)

def test_shopping():
    print("Initializing CommerceAgent (Geo)...")
    agent = GeoAgent()
    
    print("\n--- Testing Online Deal Hunter ---")
    item = "LiPo Battery 3S"
    print(f"Hunting for: {item}")
    
    # This should open 4 tabs
    res = agent.find_online_products(item)
    print(f"Result: {res}")
    
    if "opened" in res and "Daraz" in res:
        print("✅ CommerceAgent Verified")
    else:
        print("❌ CommerceAgent Failed")

if __name__ == "__main__":
    test_shopping()
