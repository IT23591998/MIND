import sys
import os
from colorama import Fore, init

# Add root to path
sys.path.append(os.getcwd())
init(autoreset=True)

print(f"{Fore.CYAN}--- VERIFYING GLM-4.7 INTEGRATION ---")

try:
    from mind_brain import MindBrain
    brain = MindBrain()
    
    # Check if GLM is in brains
    if "GLM" in brain.brains:
        print(f"{Fore.GREEN}✅ GLM Brain Key Found.")
        glm_brain = brain.brains["GLM"]
        print(f"   Model: {glm_brain['model']}")
        print(f"   API Base: {glm_brain.get('api_base')}")
        
        if glm_brain['api_key']:
             print(f"{Fore.GREEN}✅ API Key Detected (Length: {len(glm_brain['api_key'])})")
        else:
             print(f"{Fore.RED}❌ API Key Missing.")
             
        # Test Routing
        print("\nTesting Routing Logic...")
        res = brain._determine_brain("MIND, switch to GLM brain")
        if res == "GLM":
             print(f"{Fore.GREEN}✅ Routing 'switch to GLM' -> GLM")
        else:
             print(f"{Fore.RED}❌ Routing Failed (Got {res})")

    else:
        print(f"{Fore.RED}❌ GLM Not found in brain registry.")

except Exception as e:
    print(f"{Fore.RED}CRITICAL FAILURE: {e}")
    import traceback
    traceback.print_exc()
