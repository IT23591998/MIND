import sys
import os
import json
from colorama import init, Fore, Style

sys.path.append(os.getcwd())

from modules.simulation.controller import SimulationController
from modules.mcp import MasterControlProgram

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + Style.BRIGHT + "🚀 Starting Engineering Simulation Verification...")
    
    # 1. Direct Engine Test (Stress)
    print(Fore.YELLOW + "\n🧪 Test 1: Direct Beam Stress Calculation")
    controller = SimulationController()
    payload = {
        "simulation_type": "engineering",
        "sub_type": "stress",
        "parameters": {
            "load_n": 2000,
            "length_m": 3.0,
            "material": "steel"
        }
    }
    result = controller.run_simulation(payload)
    print(Fore.CYAN + json.dumps(result, indent=2))
    
    if result.get('confidence', 0) > 0.8 and 'max_stress_pa' in result['results']:
        print(Fore.GREEN + "✅ Direct Engineering Test Passed.")
    else:
        print(Fore.RED + "❌ Direct Engineering Test Failed.")

    # 2. MCP Routing Test (Gear Ratio)
    print(Fore.YELLOW + "\n🧪 Test 2: MCP Routing for 'Simulate gear ratio'")
    mcp = MasterControlProgram()
    # "simulate gear ratio" should trigger the routing logic we added
    mcp_result = mcp.submit_task("Simulate gear ratio for 20 teeth driver and 80 teeth driven", domain="Simulation")
    
    print(Fore.CYAN + f"   Task ID: {mcp_result.task_id}")
    print(Fore.CYAN + f"   Output: {mcp_result.output[:150]}...")
    
    if "gear_ratio" in mcp_result.output or "4.0:1" in mcp_result.output:
        print(Fore.GREEN + "✅ MCP Routing to Engineering Engine Passed.")
    else:
        print(Fore.RED + "❌ MCP Routing Failed.")

if __name__ == "__main__":
    run_verification()
