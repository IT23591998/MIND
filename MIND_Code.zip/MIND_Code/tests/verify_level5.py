import unittest
from unittest.mock import MagicMock, patch
import os
import sys

# MOCK EVERYTHING BEFORE IMPORTS
sys.modules['nmap'] = MagicMock()
sys.modules['pyautogui'] = MagicMock()
sys.modules['cv2'] = MagicMock()
# Mock constants
sys.modules['cv2'].COLOR_RGB2BGR = 1
sys.modules['cv2'].VideoWriter = MagicMock()
sys.modules['cv2'].VideoWriter_fourcc = MagicMock()
sys.modules['cv2'].cvtColor = MagicMock()

sys.modules['requests'] = MagicMock()
sys.modules['bs4'] = MagicMock()
sys.modules['modules.telegram_agent'] = MagicMock()

from modules.social_agent import SocialAgent
import config

class TestSocialDebug(unittest.TestCase):
    def test_social(self):
        print("Starting Social Test...")
        agent = SocialAgent()
        agent.out_path = "test_clip.avi"
        
        # Mock pyautogui
        mock_size = MagicMock()
        mock_size.width = 100
        mock_size.height = 100
        sys.modules['pyautogui'].size.return_value = mock_size
        
        from PIL import Image
        fake_img = Image.new('RGB', (100, 100))
        sys.modules['pyautogui'].screenshot.return_value = fake_img
        
        try:
            print("Calling record_session...")
            res = agent.record_session(duration_sec=1)
            print(f"Result: {res}")
            self.assertIn("recording", res.lower())
        except Exception as e:
            print(f"CRITICAL ERROR: {e}")
            import traceback
            traceback.print_exc()
            raise e

if __name__ == '__main__':
    unittest.main()
