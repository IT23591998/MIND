import unittest
from unittest.mock import MagicMock
import os
import shutil

from modules.gamedev_agent import GameDevAgent

class TestGameDevAgent(unittest.TestCase):
    def setUp(self):
        # Patch os.startfile
        self.startfile_patcher = unittest.mock.patch('os.startfile')
        self.mock_startfile = self.startfile_patcher.start()
        self.addCleanup(self.startfile_patcher.stop)
        
        # Patch config queues to avoid side effects
        self.speech_patcher = unittest.mock.patch('config.speech_queue')
        self.mock_speech = self.speech_patcher.start()
        self.addCleanup(self.speech_patcher.stop)
        
        self.hud_patcher = unittest.mock.patch('config.hud_queue')
        self.mock_hud = self.hud_patcher.start()
        self.addCleanup(self.hud_patcher.stop)

        # Mock File I/O
        self.open_patcher = unittest.mock.patch('builtins.open', unittest.mock.mock_open())
        self.mock_open = self.open_patcher.start()
        self.addCleanup(self.open_patcher.stop)

        self.agent = GameDevAgent()
        self.agent.brain = MagicMock()
        self.agent.brain.think.return_value = "using UnityEngine;\npublic class Test : MonoBehaviour {}"

    def tearDown(self):
        pass # No cleanup needed as we mock I/O
            
    def test_unity_generation(self):
        res = self.agent.generate_script("Jump Mechanic", "unity")
        print(f"Unity Result: {res}")
        self.assertIn("Generated", res)
        # Verify write
        self.mock_open.assert_called_with(os.path.join(self.agent.assets_dir, "JumpMechanicController.cs"), "w")

    def test_unreal_generation(self):
        self.agent.brain.think.return_value = "#include \"GameFramework/Actor.h\""
        res = self.agent.generate_script("Shoot Mechanic", "unreal")
        print(f"Unreal Result: {res}")
        self.assertIn("Generated", res)
        self.mock_open.assert_called_with(os.path.join(self.agent.assets_dir, "ShootMechanicController.cpp"), "w")

if __name__ == '__main__':
    unittest.main()
