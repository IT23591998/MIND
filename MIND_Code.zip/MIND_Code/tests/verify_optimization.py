import unittest
from unittest.mock import MagicMock, patch
import sys

# MOCK Dependencies
sys.modules['psutil'] = MagicMock()
sys.modules['config'] = MagicMock()
sys.modules['ollama'] = MagicMock()
sys.modules['langchain'] = MagicMock()
sys.modules['langchain.document_loaders'] = MagicMock()
sys.modules['langchain.vectorstores'] = MagicMock()
sys.modules['langchain.embeddings'] = MagicMock()
sys.modules['langchain.text_splitter'] = MagicMock()

from modules.knowledge_agent import KnowledgeAgent
from modules.monitor_agent import MonitorAgent

class TestOptimization(unittest.TestCase):
    def test_lru_cache(self):
        agent = KnowledgeAgent()
        # Mock vector db
        agent.vector_db = MagicMock()
        mock_doc = MagicMock()
        mock_doc.page_content = "Context"
        agent.vector_db.similarity_search.return_value = [mock_doc]
        sys.modules['ollama'].generate.return_value = {'response': 'Cache Miss'}
        
        # 1. First Call (Miss)
        res1 = agent.query_knowledge("Test Query")
        self.assertEqual(res1, "Cache Miss")
        self.assertTrue(agent.vector_db.similarity_search.called)
        
        # 2. Second Call (Hit)
        agent.vector_db.similarity_search.reset_mock()
        res2 = agent.query_knowledge("Test Query")
        self.assertEqual(res2, "Cache Miss") # Should return cached value
        self.assertFalse(agent.vector_db.similarity_search.called) # Should NOT call DB
        
    def test_thermal_throttling(self):
        agent = MonitorAgent()
        
        # Mock High Temp
        mock_temp = MagicMock()
        mock_temp.current = 90
        sys.modules['psutil'].sensors_temperatures.return_value = {"CPU": [mock_temp]}
        
        msg, is_throttled = agent.check_thermals()
        self.assertTrue(is_throttled)
        self.assertIn("CRITICAL", msg)
        
        # Mock Low Temp
        mock_temp.current = 40
        msg, is_throttled = agent.check_thermals()
        self.assertFalse(is_throttled)

if __name__ == '__main__':
    unittest.main()
