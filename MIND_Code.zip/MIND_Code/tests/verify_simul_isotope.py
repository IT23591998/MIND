
import sys
import os
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init
init(autoreset=True)

def test_simulation():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    print("\n--- Testing Nuclear Physics Engine ---")
    
    # 1. Xenon-135 (Poison, Unstable)
    # Z=54, N=81, Ratio=1.5. Ideal ~ 1.25. Deviation ~0.25 -> Unstable
    print("Query: Xenon-135")
    res1 = agent.get_element_info("Xenon-135")
    if res1 and "Unstable" in res1 or "Radioactive" in res1:
        print("✅ Xenon-135 Simulation PASSED (Detected Instability)")
    else:
        print(f"❌ Xenon-135 Failed: {res1}")

    # 2. Oxygen-16 (Stable)
    # Z=8, N=8, Ratio=1.0. Ideal ~ 1.05. Deviation < 0.1 -> Stable
    print("\nQuery: Oxygen-16") 
    # Note: O-16 is likely not isotopes list in standard DB, so it hits simulation
    res2 = agent.get_element_info("Oxygen-16")
    if res2 and "Stable" in res2:
        print("✅ Oxygen-16 Simulation PASSED (Detected Stability)")
    else:
         print(f"❌ Oxygen-16 Failed: {res2}")
         
    # 3. Gold-300 (Impossible/Extreme)
    # Z=79, N=221. Ratio ~2.8. Ideal ~1.4. Deviation Huge.
    print("\nQuery: Gold-300")
    res3 = agent.get_element_info("Gold-300")
    if res3 and "Highly Unstable" in res3:
        print("✅ Gold-300 Simulation PASSED (Detected Extreme Instability)")
    else:
        print(f"❌ Gold-300 Failed: {res3}")

if __name__ == "__main__":
    test_simulation()
