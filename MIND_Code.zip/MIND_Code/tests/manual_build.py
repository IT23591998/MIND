import subprocess
import os
import sys

# Force UTF-8
sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

project_path = r"D:\MyProjects\ADo-DoList"
cmd = "gradlew.bat assembleDebug"

print(f"Running {cmd} in {project_path}...")
try:
    # Use call instead of run to stream output directly
    res = subprocess.call(
        cmd, 
        cwd=project_path, 
        shell=True,
        # stdout/stderr default to None -> inherit from parent
    )
    print(f"Build Exit Code: {res}")
except Exception as e:
    print(f"Error: {e}")
