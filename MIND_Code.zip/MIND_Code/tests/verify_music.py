
import sys
import os
import time
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from modules.music_agent import MusicAgent
from colorama import init, Fore

init(autoreset=True)

def verify_music():
    print(Fore.WHITE + "========================================")
    print(Fore.WHITE + "   VERIFYING MIND MUSIC (VLC + YT-DLP)")
    print(Fore.WHITE + "========================================")
    
    agent = MusicAgent()
    
    query = "NCS No Copyright Sounds"
    print(Fore.YELLOW + f"\n[TEST 1] Playing '{query}' for 10 seconds...")
    
    # Needs a real network connection and VLC
    try:
        res = agent.play(query)
        if "error" in res:
             print(Fore.RED + f"Playback Failed: {res['error']}")
        else:
             print(Fore.GREEN + f"Playing: {res.get('title')}")
             time.sleep(10)
             agent.stop()
             print(Fore.GREEN + "✅ Stoppped Successfully.")
             
    except Exception as e:
        print(Fore.RED + f"Critical Error: {e}")

if __name__ == "__main__":
    verify_music()
