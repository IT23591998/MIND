import sys
import os
from colorama import init, Fore

sys.path.append(os.getcwd())

from modules.innovation_engine import InnovationEngine

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + "🚀 Starting Innovation Engine Verification...")
    
    engine = InnovationEngine() # Will use default brain (or mocked if needed)
    
    topic = "Edible Water Bottles"
    print(Fore.CYAN + f"   Brainstorming Topic: {topic}")
    
    result = engine.brainstorm(topic)
    
    print(Fore.YELLOW + "   Result Sample:")
    print(Fore.WHITE + result[:200] + "...")
    
    if len(result) > 50 and ("Substitute" in result or "Combine" in result or "Idea" in result):
        print(Fore.GREEN + "✅ Innovation SCAMPER Output Verified.")
    else:
        print(Fore.RED + "❌ Innovation Engine failed or output empty.")

if __name__ == "__main__":
    run_verification()
