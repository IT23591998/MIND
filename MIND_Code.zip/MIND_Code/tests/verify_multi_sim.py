import sys
import os
import json
from colorama import init, Fore

sys.path.append(os.getcwd())

from modules.simulation.controller import SimulationController

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + "🚀 Starting Multi-Domain Simulation Verification...")
    
    controller = SimulationController()
    
    # Test Chain: 
    # 1. Calculate Solar Yield for 50m2 array
    # 2. Calculate Stress on a steel beam supporting that array (50m2 * 12kg/m2 = 600kg load)
    
    chain_request = {
        "chain_name": "Solar Array Structural Safety",
        "steps": [
            {
                "type": "energy", 
                "sub_type": "solar", 
                "params": {"area_m2": 50, "efficiency": 0.20}
            },
            {
                "type": "engineering", 
                "sub_type": "stress", 
                "map_input": "load_n = weight_kg * 9.8", # Triggering the hardcoded mapping logic
                "params": {"length_m": 10, "material": "steel"}
            }
        ]
    }
    
    print(Fore.CYAN + f"   Executing Chain: {chain_request['chain_name']}")
    result = controller.run_chained_simulation(chain_request)
    
    # Validate
    steps = result.get('full_trace', [])
    print(Fore.YELLOW + f"   Steps Executed: {len(steps)}")
    
    if len(steps) == 2:
        step1 = steps[0]['results']
        step2 = steps[1]['results']
        
        print(Fore.MAGENTA + f"   [Step 1] Solar Energy: {step1.get('daily_energy_kwh')} kWh")
        print(Fore.MAGENTA + f"   [Step 2] Beam Stress: {step2.get('max_stress_mpa')} MPa (Safety: {step2.get('safety_factor')})")
        
        if step2.get('safety_factor', 0) > 0:
             print(Fore.GREEN + "✅ Data flowed from Step 1 -> Step 2 (Weight Calc).")
        else:
             print(Fore.RED + "❌ Step 2 did not receive mapped weight.")
    else:
        print(Fore.RED + "❌ Simulation Chain failed.")

if __name__ == "__main__":
    run_verification()
