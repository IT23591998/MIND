import unittest
from unittest.mock import MagicMock, patch
import os
import shutil
import config

# Mock dependencies
try:
    import googlesearch
    import bs4
    DEPS_OK = True
except:
    DEPS_OK = False

from modules.research_agent import ResearchAgent

class TestResearchAgent(unittest.TestCase):
    def setUp(self):
        if not DEPS_OK:
            self.skipTest("Deps missing")
            
        self.agent = ResearchAgent()
        # Mock Brain
        self.agent.brain = MagicMock()
        self.agent.brain.think.return_value = "# Report\nTest Content"

    @patch('modules.research_agent.search')
    @patch('modules.research_agent.requests.get')
    def test_research_flow(self, mock_get, mock_search):
        # Mock Search
        mock_search.return_value = ["http://test.com/1"]
        
        # Mock Scrape
        mock_response = MagicMock()
        mock_response.text = "<html><p>Test paragraph content.</p></html>"
        mock_get.return_value = mock_response
        
        # Run
        res = self.agent.research_topic("Test Topic")
        
        # Validate
        print(f"Research Result: {res}")
        self.assertIn("Report saved", res)
        
        # Check file
        filename = "test_topic_report.md"
        filepath = os.path.join(self.agent.reports_dir, filename)
        self.assertTrue(os.path.exists(filepath))
        
        # Cleanup
        if os.path.exists(filepath):
            os.remove(filepath)

if __name__ == '__main__':
    unittest.main()
