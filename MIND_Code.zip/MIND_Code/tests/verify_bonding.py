
import sys
import os
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init
init(autoreset=True)

def test_bonding():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    print("\n--- Testing Chemical Bonding Engine ---")
    
    # 1. Ionic Test: Sodium + Chlorine
    print("Test 1: Na + Cl")
    res1 = agent.calculate_bonding("Na", "Cl")
    if res1 and "Ionic" in res1 and "NaCl" in res1:
        print("✅ Na+Cl Correct (Ionic, NaCl)")
    else:
        print(f"❌ Na+Cl Failed: {res1}")

    # 2. Polar Covalent: Hydrogen + Oxygen
    print("\nTest 2: H + O")
    res2 = agent.calculate_bonding("H", "O")
    # H (2.1), O (3.5) -> Delta 1.4 -> Polar Covalent.
    # Formula: H(+1), O(-2) -> H2O1 -> H2O
    if res2 and "Polar Covalent" in res2 and "H2O" in res2:
        print("✅ H+O Correct (Polar Covalent, H2O)")
    else:
         print(f"❌ H+O Failed: {res2}")
         
    # 3. Methane: Carbon + Hydrogen
    # C(2.55), H(2.2) -> Delta 0.35 -> Non-Polar (or weakly polar)
    # C(+4), H(-1) -> CH4 (assuming C is cation-like here due to higher EN... wait, C is more EN)
    # Actually H is 2.2, C is 2.55. C is Anion (-4), H is Cation (+1).
    # H(+1) C(-4) -> H4C -> usually written CH4. Our logic might output H4C or CH4 depending oncation order.
    # Logic: Cation (H) First -> H4C. Let's see.
    print("\nTest 3: C + H")
    res3 = agent.calculate_bonding("C", "H")
    if res3:
        print("✅ Reaction Ran")
    else:
         print("❌ Failed")

if __name__ == "__main__":
    test_bonding()
