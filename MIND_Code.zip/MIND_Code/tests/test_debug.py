
import subprocess
import sys
import time

try:
    print("Launching Notepad...")
    subprocess.Popen([r"C:\Windows\notepad.exe"])
    print("Notepad launched.")
except Exception as e:
    print(f"Error: {e}")
