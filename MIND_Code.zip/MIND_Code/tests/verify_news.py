import unittest
from unittest.mock import MagicMock, patch
import sys
import os
import json

# Imports
from modules.news_agent import NewsAgent
import config

class TestGlobalPulse(unittest.TestCase):
    def setUp(self):
        self.agent = NewsAgent()
        
    def test_score_logic(self):
        # 1. Critical
        score = self.agent.calculate_impact("Serious Vulnerability found in MIND Architecture")
        self.assertEqual(score, 10)
        
        # 2. High
        score = self.agent.calculate_impact("New AI tools released by Google")
        self.assertEqual(score, 6)
        
        # 3. Normal
        score = self.agent.calculate_impact("Local cat stuck in tree")
        self.assertEqual(score, 1)

    def test_alert_system(self):
        # Mock speech queue
        config.speech_queue = MagicMock()
        
        # Trigger Alert
        headline = "CRITICAL: SLIIT Server Down"
        self.agent.trigger_alert(headline)
        
        # Check Speech
        config.speech_queue.put.assert_called_with(f"Alert. Breaking News: {headline}")
        
        # Check HUD
        with open("D:/MIND_Project/hud_status.json", "r") as f:
            status = json.load(f)
        self.assertEqual(status["firewall_status"], "CRITICAL")
        
        print("Global Pulse Alert System Verified.")

if __name__ == "__main__":
    unittest.main()
