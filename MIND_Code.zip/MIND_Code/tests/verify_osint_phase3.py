
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from modules.security_agent import SecurityAgent
from colorama import init, Fore

init(autoreset=True)

def verify_phase3():
    print(Fore.WHITE + "========================================")
    print(Fore.WHITE + "   VERIFYING MIND V2.7 OSINT PHASE 3")
    print(Fore.WHITE + "========================================")
    
    agent = SecurityAgent()
    
    # 1. Test Subdomain Enumeration
    print(Fore.YELLOW + "\n[TEST 1] Subdomain Search (google.com)")
    subs = agent.find_subdomains("google.com")
    print(f"Result (Top 5): {subs[:5] if subs else 'None'}")

    # 2. Test Tech Stack
    print(Fore.YELLOW + "\n[TEST 2] Tech Stack (python.org)")
    stack = agent.detect_tech_stack("https://www.python.org")
    print(f"Result: {stack}")

    # 3. Test Robots.txt
    print(Fore.YELLOW + "\n[TEST 3] Robots.txt (wikipedia.org)")
    robots = agent.analyze_robots_txt("https://www.wikipedia.org")
    # Truncate output
    print(f"Result (First 3): {robots[:3] if isinstance(robots, list) else robots}")

    # 4. Test PDF Metadata (Mock check if no online PDF available or pypdf missing)
    print(Fore.YELLOW + "\n[TEST 4] PDF Metadata (Dummy URL)")
    # Using a known small PDF or just handling the request error gracefully
    pdf_res = agent.analyze_pdf_metadata("https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf")
    print(f"Result: {pdf_res}")

    print(Fore.GREEN + "\n✅ Phase 3 Verification Completed")

if __name__ == "__main__":
    verify_phase3()
