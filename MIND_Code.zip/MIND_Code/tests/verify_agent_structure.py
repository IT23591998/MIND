
import unittest
import os
import shutil
from unittest.mock import MagicMock
from modules.android_agent import AndroidAutomator

class TestAndroidAgent(unittest.TestCase):
    def setUp(self):
        self.agent = AndroidAutomator()
        # Mock the brain to avoid API calls and ensuring consistent "extra" files
        self.agent.brain = MagicMock()
        self.agent.brain.think.return_value = '{"files": [{"path": "app/src/main/java/com/example/testapp/ui/screens/TestScreen.kt", "type": "kotlin"}]}'
        
        # Use a temp directory for projects
        self.agent.projects_root = "D:/MIND_Project/temp_verify_builds"
        if os.path.exists(self.agent.projects_root):
            shutil.rmtree(self.agent.projects_root)
        os.makedirs(self.agent.projects_root)

    def test_golden_path_structure(self):
        app_name = "Test App"
        project_path, files_list = self.agent.step_2_create_project_wizard(app_name)
        
        file_paths = [f['path'] for f in files_list]
        
        # Check Essential Files
        self.assertIn("build.gradle.kts", file_paths)
        self.assertIn("settings.gradle.kts", file_paths)
        self.assertIn("app/src/main/AndroidManifest.xml", file_paths)
        
        # Check Core Code
        expected_pkg = "com/example/testapp"
        self.assertTrue(any(f"app/src/main/java/{expected_pkg}/MainActivity.kt" in p for p in file_paths))
        self.assertTrue(any(f"app/src/main/java/{expected_pkg}/ui/theme/Theme.kt" in p for p in file_paths))
        
        # Check AI Extra Files
        self.assertTrue(any("TestScreen.kt" in p for p in file_paths))
        
        print(f"\n[PASSED] Verified {len(file_paths)} files in structure.")

if __name__ == '__main__':
    unittest.main()
