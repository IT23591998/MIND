import sounddevice as sd
import numpy as np
from scipy.io.wavfile import write
import os

# Device 2: Your Realtek Mic
sd.default.device = 2 
fs = 16000
duration = 5 

print("--- FINAL VERIFICATION ---")
print(f"Current Folder: {os.getcwd()}") # This tells us exactly where the file will go
print("Recording 5 seconds... Speak now!")

recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
sd.wait()

# Save the file
filename = "MIND_test_voice.wav"
write(filename, fs, recording)

print("\n--- DONE ---")
if os.path.exists(filename):
    file_path = os.path.abspath(filename)
    print(f"SUCCESS! The file is saved at:\n{file_path}")
    print("\nGo to that folder and double-click the file to listen.")
else:
    print("Something went wrong with the save.")