
import sys
import os
sys.path.append("d:/MIND_Project")
from modules.geo_agent import GeoAgent
from colorama import init
init(autoreset=True)

def test_geo():
    print("Initializing GeoAgent...")
    agent = GeoAgent()
    
    print("\n--- Testing Store Locator ---")
    item = "Arduino"
    print(f"Searching for: {item}")
    
    # This should open a browser window
    res = agent.find_nearby_stores(item)
    print(f"Result: {res}")
    
    if "opened a satellite map" in res:
        print("✅ GeoAgent Verified")
    else:
        print("❌ GeoAgent Failed")

if __name__ == "__main__":
    test_geo()
