
import sys
import os
import json
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init
init(autoreset=True)

def test_synthesis():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    # 1. Synthesize New Element
    print("\n--- Testing Element Synthesis ---")
    el_name = "Starkium"
    el_num = 119
    
    # Clean up previous runs if any
    agent.matter_db = [e for e in agent.matter_db if e['name'] != el_name]
    
    msg = agent.synthesize_element(el_name, "St", el_num, 310.5, "Solid")
    print(f"Result: {msg}")
    
    if "SYNTHESIS COMPLETE" in msg:
        print("✅ Synthesis Function Executed")
    else:
        print("❌ Synthesis Failed")
        return

    # 2. Verify Retrieval
    print("\n--- Verifying Retrieval ---")
    info = agent.get_element_info(el_name)
    if info and "310.5" in info:
         print("✅ Starkium Retrieval PASSED")
    else:
         print("❌ Starkium Retrieval FAILED")
         
    # 3. Clean up (Optional, maybe user wants to keep it? For test script we remove it to keep db clean)
    # Actually, let's keep it to prove persistence! 
    # But for repeatable tests, we should probably remove it.
    # Let's remove it manually from the file for now.
    
    print("\nCleaning up test artifact...")
    with open(agent.matter_db_path, 'r') as f:
        data = json.load(f)
    
    data = [e for e in data if e['name'] != el_name]
    
    with open(agent.matter_db_path, 'w') as f:
        json.dump(data, f, indent=4)
        
    print("Test Complete.")

if __name__ == "__main__":
    test_synthesis()
