import unittest
from unittest.mock import MagicMock, patch
from modules.BlenderAutomator import BlenderAutomator

class TestBlenderAutomator(unittest.TestCase):
    def setUp(self):
        # We need to mock MindBrain so we don't make real API calls or need config
        self.automator = BlenderAutomator()
        self.automator.brain = MagicMock()
        self.automator.brain.think.return_value = "import bpy\nprint('code')"
        
        # Mock execute_in_blender so we don't try to find windows
        self.automator.execute_in_blender = MagicMock()

    def test_simple_mode(self):
        self.automator.generate_asset("cube", complexity="simple")
        # Check if brain was called with default prompt
        args, _ = self.automator.brain.think.call_args
        prompt = args[0]
        # "LEGO STYLE" is a comment, not in string. Check for "USE ONLY PRIMITIVES"
        self.assertIn("USE ONLY PRIMITIVES", prompt)
        self.assertIn("NO BMESH", prompt)

    def test_high_poly_mode(self):
        self.automator.generate_asset("dragon", complexity="high_poly")
        # Check if brain was called with advanced prompt
        args, _ = self.automator.brain.think.call_args
        prompt = args[0]
        print(f"\n[DEBUG] High Poly Prompt: {prompt[:50]}...")
        self.assertIn("REALISTIC HIGH-POLY", prompt)
        self.assertIn("USE MODIFIERS", prompt)
        self.assertIn("bmesh", prompt)

if __name__ == '__main__':
    unittest.main()
