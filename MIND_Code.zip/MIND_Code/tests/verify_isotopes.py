
import sys
import os
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init
init(autoreset=True)

def test_isotopes():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    print("\n--- Testing Isotope Awareness ---")
    
    # 1. Carbon-14 (Radioactive)
    print("Query: Carbon-14")
    res1 = agent.get_element_info("Carbon-14")
    if res1 and "5730 years" in res1:
        print("✅ Carbon-14 Lookup PASSED")
    else:
        print(f"❌ Carbon-14 Failed: {res1}")

    # 2. Deuterium (Named Isotope)
    print("\nQuery: Deuterium")
    res2 = agent.get_element_info("Deuterium")
    if res2 and "2.014" in res2:
        print("✅ Deuterium Lookup PASSED")
    else:
         print(f"❌ Deuterium Failed: {res2}")
         
    # 3. Uranium (Parent Lookup)
    print("\nQuery: Uranium")
    res3 = agent.get_element_info("Uranium")
    if res3 and "Uranium-235" in res3:
        print("✅ Uranium Parent Lookup PASSED")
    else:
        print(f"❌ Uranium Parent Failed: {res3}")

if __name__ == "__main__":
    test_isotopes()
