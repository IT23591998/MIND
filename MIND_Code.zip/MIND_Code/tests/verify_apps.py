import unittest
from unittest.mock import MagicMock, patch
import time
import threading

# Import agents
from modules.monitor_agent import MonitorAgent
from modules.media_agent import MediaAgent
from modules.scheduler_agent import SchedulerAgent

class TestAppAgents(unittest.TestCase):
    @patch('modules.monitor_agent.psutil')
    def test_monitor(self, mock_psutil):
        agent = MonitorAgent()
        
        # Setup Mocks
        mock_psutil.cpu_percent.return_value = 15.5
        mock_psutil.virtual_memory.return_value.percent = 40.0
        mock_psutil.sensors_battery.return_value.percent = 80
        mock_psutil.sensors_battery.return_value.power_plugged = True
        
        report = agent.get_system_report()
        print(f"Monitor Report: {report}")
        self.assertIn("15.5%", report)
        self.assertIn("charging", report)

    @patch('modules.media_agent.pyautogui')
    def test_media(self, mock_gui):
        agent = MediaAgent()
        
        res = agent.play_pause()
        self.assertEqual(res, "Toggled playback.")
        mock_gui.press.assert_called_with("playpause")
        
        res = agent.volume_up()
        self.assertEqual(mock_gui.press.call_count, 3) # 1 for play, 2 for vol up

    @patch('config.speech_queue')
    @patch('config.hud_queue')
    def test_scheduler(self, mock_hud, mock_speech):
        # We need to run scheduler for a split second
        agent = SchedulerAgent()
        
        # Set quick reminder
        agent.set_reminder(1, "Test Reminder")
        
        # Wait for trigger
        time.sleep(1.5)
        
        # Check queues
        # mock_speech.put.assert_called() # Logic might be race-conditiony in test
        # Just ensure logic ran
        self.assertEqual(len(agent.reminders), 0) # Should remain 0 if processed
        
        agent.stop()

if __name__ == '__main__':
    unittest.main()
