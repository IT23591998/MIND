import sys
import os
from colorama import init, Fore

sys.path.append(os.getcwd())

from modules.knowledge_agent import KnowledgeAgent

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + "🚀 Verify Conflict Resolution...")
    
    agent = KnowledgeAgent()
    
    # NASA (Whitelisted) vs Random Blog
    data_a = {"value": "X", "source": "nasa.gov", "confidence": 0.5}
    data_b = {"value": "Y", "source": "bob_blog.com", "confidence": 0.6}
    
    res = agent.resolve_conflict(data_a, data_b)
    
    print(Fore.YELLOW + f"   Score A (NASA): {res['score_a']}")
    print(Fore.YELLOW + f"   Score B (Blog): {res['score_b']}")
    
    if res['winner']['source'] == 'nasa.gov':
        print(Fore.GREEN + "✅ Logic favored Trusted Source.")
    else:
        print(Fore.RED + "❌ Logic Failed.")

if __name__ == "__main__":
    run_verification()
