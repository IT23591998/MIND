import sys
import os
import json
from colorama import init, Fore, Style

sys.path.append(os.getcwd())

from modules.mcp import MasterControlProgram

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + Style.BRIGHT + "🚀 Starting Consensus Protocol Verification...")
    
    mcp = MasterControlProgram()
    
    # Test Consensus
    # We ask a subjective or complex question
    question = "Propose a theoretical energy source for a Mars colony."
    print(Fore.YELLOW + f"\n⚖️  Submitting Consensus Task: '{question}'")
    
    result = mcp.submit_consensus_task(question, brains=["THEORIST", "ANALYST"])
    
    print(Fore.CYAN + f"\n   Task ID: {result.task_id}")
    print(Fore.WHITE + f"   Final Synthesis: {result.output[:200]}...") # Truncate
    print(Fore.CYAN + f"   Overall Confidence: {result.overall_confidence}")
    
    # Check Meta-Log
    meta = result.meta_log
    contributors = meta.get('contributors', [])
    print(Fore.MAGENTA + f"   Contributors: {len(contributors)}")
    for c in contributors:
        print(Fore.MAGENTA + f"   - {c['brain']} (Conf: {c['confidence']})")
        
    if len(contributors) == 2 and result.overall_confidence > 0:
        print(Fore.GREEN + "✅ Consensus Protocol Passed (3-Step Execution).")
    else:
        print(Fore.RED + "❌ Consensus Protocol Failed.")

if __name__ == "__main__":
    run_verification()
