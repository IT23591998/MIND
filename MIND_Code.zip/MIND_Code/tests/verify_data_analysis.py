import unittest
import pandas as pd
import os
import shutil
from modules.data_agent import DataAgent

class TestDataAgent(unittest.TestCase):
    def setUp(self):
        self.agent = DataAgent()
        # Create a dummy CSV
        self.test_csv = "test_data.csv"
        df = pd.DataFrame({
            'A': [1, 2, 3, 4, 5],
            'B': [10, 20, 30, 40, 50],
            'Category': ['X', 'Y', 'X', 'Y', 'X']
        })
        df.to_csv(self.test_csv, index=False)

    def tearDown(self):
        if os.path.exists(self.test_csv):
            os.remove(self.test_csv)
        # cleanup plots
        if os.path.exists(self.agent.plot_dir):
            for f in os.listdir(self.agent.plot_dir):
                if f.startswith("plot_"):
                    try:
                        os.remove(os.path.join(self.agent.plot_dir, f))
                    except: pass

    def test_load_data(self):
        res = self.agent.load_data(self.test_csv)
        print(f"Load Result: {res}")
        self.assertIsNotNone(self.agent.df)
        self.assertEqual(len(self.agent.df), 5)
        self.assertIn("Successfully loaded", res)

    def test_basic_summary(self):
        self.agent.load_data(self.test_csv)
        summary = self.agent.basic_summary()
        print(f"Summary: {summary}")
        self.assertIn("Rows: 5", summary)
        self.assertIn("Columns: 3", summary)

    def test_analyze_query_no_data(self):
        res = self.agent.analyze_query("Analyze this")
        self.assertEqual(res, "Please load a dataset first.")

if __name__ == '__main__':
    unittest.main()
