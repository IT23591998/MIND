import threading
import queue
import time
import os

# MOCKS
class MockTTS:
    def tts_to_file(self, text, speaker_wav, language, file_path):
        print(f"[MOCK TTS] Generating: '{text}' -> {file_path}")
        time.sleep(1.0) # Simulate generation time
        # Create dummy file
        with open(file_path, "w") as f:
            f.write("audio data")

class MockPygame:
    def __init__(self):
        self.mixer = self.MockMixer()
        
    class MockMixer:
        def __init__(self):
            self.music = self.MockMusic()
        
        def init(self): pass
        def get_init(self): return True
        
        class MockMusic:
            def __init__(self):
                self.busy = False
                self.start_time = 0
            
            def load(self, path):
                print(f"[MOCK PLAYER] Loading: {path}")
            
            def play(self):
                print(f"[MOCK PLAYER] Playing...")
                self.busy = True
                self.start_time = time.time()
                
            def get_busy(self):
                if self.busy and time.time() - self.start_time > 1.5: # Simulate 1.5s audio
                    self.busy = False
                return self.busy
                
            def unload(self):
                print(f"[MOCK PLAYER] Unloaded")

# GLOBAL CONFIG MOCKS
class Config:
    def __init__(self):
        self.ASSETS_DIR = "."
        self.speech_queue = queue.Queue()
        self.hud_queue = queue.Queue()
        self.is_speaking = threading.Event()
        self.last_spoken_phrase = ""
        self.CORE_VOICE_FILE = "voice.wav"

config = Config()
pygame = MockPygame()
torch = type('obj', (object,), {'cuda': type('obj', (object,), {'is_available': lambda: False})})

# --- PASTE SMART SPEAKER CLASS HERE ---
class SmartSpeaker:
    def __init__(self, tts_model, voice_file):
        self.tts = tts_model
        self.voice_file = voice_file
        self.gen_queue = queue.Queue()
        self.play_queue = queue.Queue()
        self.is_active = True
        
        # Start Threads
        threading.Thread(target=self.processor_loop, daemon=True).start()
        threading.Thread(target=self.generator_loop, daemon=True).start()
        threading.Thread(target=self.player_loop, daemon=True).start()

    def split_sentences(self, text):
        """Splits text into sentences for fluid streaming."""
        import re
        # Split by . ! ? but keep the punctuation
        parts = re.split(r'([.!?]+)', text)
        sentences = []
        # Re-attach punctuation
        for i in range(0, len(parts)-1, 2):
            sentences.append(parts[i] + parts[i+1])
        # Add remaining part if any
        if len(parts) % 2 == 1 and parts[-1]:
            sentences.append(parts[-1])
        return sentences

    def processor_loop(self):
        """Consumes the global speech_queue and splits into sentences."""
        while self.is_active:
            try:
                # 1. Get big text chunk
                text = config.speech_queue.get(timeout=0.5)
                
                # Update HUD
                config.is_speaking.set()
                config.last_spoken_phrase = text.lower().strip()[:100]
                config.hud_queue.put("SPEAKING...")

                # 2. Split and queue for generation
                # If short, just send it all
                if len(text) < 50:
                    self.gen_queue.put(text)
                else:
                    sentences = self.split_sentences(text)
                    if not sentences: sentences = [text] # Fallback
                    for sent in sentences:
                        if sent.strip():
                            self.gen_queue.put(sent)
                
            except queue.Empty:
                # MOCK SCRIPT FIX: Don't check busy here to avoid infinite loop in test
                continue
            except Exception as e:
                print(f"[PROCESSOR ERROR] {e}")

    def generator_loop(self):
        """Consumes sentences -> Generates Audio -> Queues File Path"""
        import uuid
        while self.is_active:
            try:
                text = self.gen_queue.get(timeout=0.5)
                if not text: continue

                # Create unique temp file
                filename = f"temp_tts_{uuid.uuid4().hex}.wav"
                filepath = os.path.join(config.ASSETS_DIR, filename)

                # Generate
                try:
                    print(f"[GEN] Starting: {text[:10]}...")
                    self.tts.tts_to_file(text=text, speaker_wav=self.voice_file, language="en", file_path=filepath)
                    self.play_queue.put(filepath)
                    print(f"[GEN] Finished: {text[:10]}...")
                except Exception as e:
                    print(f"[TTS GEN ERROR] {e}")

            except queue.Empty:
                continue

    def player_loop(self):
        """Consumes Audio Files -> Plays -> Deletes"""
        while self.is_active:
            try:
                filepath = self.play_queue.get(timeout=0.5)
                
                print(f"[PLAY] Ready to play: {filepath}")
                
                # Wait if previous is still playing
                while pygame.mixer.music.get_busy(): 
                    time.sleep(0.05)
                
                print(f"[PLAY] STARTING: {filepath}")
                pygame.mixer.music.load(filepath)
                pygame.mixer.music.play()
                
                while pygame.mixer.music.get_busy():
                    time.sleep(0.05)
                
                print(f"[PLAY] FINISHED: {filepath}")
                pygame.mixer.music.unload()
                
                try:
                    os.remove(filepath)
                except:
                    pass

            except queue.Empty:
                continue
            except Exception as e:
                print(f"[PLAYER ERROR] {e}")

# --- RUN TEST ---
if __name__ == "__main__":
    speaker = SmartSpeaker(MockTTS(), "voice.wav")
    
    print("Injecting long text...")
    long_text = "Sentence one is here. Sentence two is following shortly after! sentence three is the last one?"
    config.speech_queue.put(long_text)
    
    # Let it run for 10 seconds
    time.sleep(10)
    speaker.is_active = False
    print("Test Complete.")
