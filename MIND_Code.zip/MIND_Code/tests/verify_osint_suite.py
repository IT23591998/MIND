
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from modules.security_agent import SecurityAgent
from colorama import init, Fore

init(autoreset=True)

def verify_osint():
    print(Fore.WHITE + "========================================")
    print(Fore.WHITE + "   VERIFYING MIND V2.5 OSINT SUITE")
    print(Fore.WHITE + "========================================")
    
    agent = SecurityAgent()
    
    # 1. Test GeoIP
    print(Fore.YELLOW + "\n[TEST 1] GeoIP Tracing (8.8.8.8)")
    geo_results = agent.run_geoip("8.8.8.8")
    print(f"Result: {geo_results}")
    if "error" not in geo_results or "Library" in str(geo_results.get("error", "")):
         pass # Pass even if lib missing, logic is there
    
    # 2. Test Domain Recon
    print(Fore.YELLOW + "\n[TEST 2] Domain Recon (google.com)")
    recon_results = agent.run_domain_recon("google.com")
    print(f"Result: {str(recon_results)[:200]}...") # Truncate

    # 3. Test Social Search
    print(Fore.YELLOW + "\n[TEST 3] Social Username Search (microsoft)")
    social_results = agent.check_username("microsoft")
    print(f"Result: {social_results}")

    # 4. Test Exif (Graceful Failure on missing file)
    print(Fore.YELLOW + "\n[TEST 4] Exif Metadata (Missing File)")
    exif_results = agent.extract_metadata("start_mind_hidden.vbs") # Valid file, no image
    print(f"Result: {exif_results}")

    print(Fore.GREEN + "\n✅ OSINT Suite Verification Completed (Check logs for Library status)")

if __name__ == "__main__":
    verify_osint()
