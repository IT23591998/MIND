import sys
import os

# Adjust path to find modules
sys.path.append(os.getcwd())

from modules.android_agent import AndroidAutomator

def test_build_mission():
    bot = AndroidAutomator()
    
    print("\n--- 1. DIAGNOSE ENVIRONMENT ---")
    bot.diagnose_environment()
    
    print("\n--- 2. TRIGGER BUILD & HEAL ---")
    # Using the project name found in project_config.json
    # "A Do-Do List ." -> folder "ADo-DoList." or "ADo-DoList"
    # The agent uses replace(" ", "") so "A Do-Do List ." -> "ADo-DoList."
    # Let's try the cleanest name possible.
    
    target_app = "ToDoList" # FIXED: Use the project folder that definitely has gradle files
    bot.build_and_heal(target_app)

if __name__ == "__main__":
    test_build_mission()
