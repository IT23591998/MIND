import sys
import os
from colorama import init, Fore

sys.path.append(os.getcwd())

from modules.web_dev_agent import WebDevAgent

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + "🚀 Verify Web Gen...")
    
    agent = WebDevAgent()
    res = agent.generate_portfolio("VerifyPort", "My Title", ["Python", "Rust"])
    
    if os.path.exists(res['path']):
        print(Fore.GREEN + "✅ Web Gen Sucess.")
    else:
        print(Fore.RED + "❌ Failed.")

if __name__ == "__main__":
    run_verification()
