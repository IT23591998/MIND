import unittest
import json
import os
import time

class TestHUDLink(unittest.TestCase):
    def test_status_file_contract(self):
        file_path = "D:/MIND_Project/hud_status.json"
        
        # 1. Simulate Python Write
        status = {
            "face_detected": True,
            "firewall_status": "THREAT"
        }
        with open(file_path, "w") as f:
            json.dump(status, f)
            
        # 2. Simulate C++ Read (Verify content)
        with open(file_path, "r") as f:
            data = json.load(f)
            
        self.assertTrue(data["face_detected"])
        self.assertEqual(data["firewall_status"], "THREAT")
        print("HUD Link Contract Verified.")

if __name__ == '__main__':
    unittest.main()
