import unittest
from unittest.mock import MagicMock, patch
import os
import sys
import json

# Mock dependencies
sys.modules['mind_brain'] = MagicMock()
sys.modules['config'] = MagicMock()

from modules.web_agent import WebAutomator

class TestWebAgentV2(unittest.TestCase):
    @patch('os.makedirs')
    @patch('os.path.exists')
    def test_dynamic_scaffold(self, mock_exists, mock_makedirs):
        mock_exists.return_value = False
        agent = WebAutomator()
        agent.brain = MagicMock()
        agent._run_shell = MagicMock()
        
        # Test 1: Svelte
        agent.brain.think.return_value = "npm create svelte@latest my-app"
        try:
            res = agent.step_1_scaffold_project("TestApp", "Svelte")
            print(f"Scaffold Command Logic: {res}")
            self.assertTrue(agent._run_shell.called)
            self.assertIn("my-app", str(agent._run_shell.call_args))
        except Exception:
            import traceback
            traceback.print_exc()
            raise

    @patch('os.makedirs')
    @patch('os.path.exists')
    def test_dynamic_structure(self, mock_exists, mock_makedirs):
        agent = WebAutomator()
        agent.brain = MagicMock()
        
        # Mock structure response
        fake_structure = json.dumps([
            {"path": "src/routes/+page.svelte", "desc": "Home"}
        ])
        agent.brain.think.side_effect = [fake_structure, "<h1>Hello Svelte</h1>"] 
        
        # Mock file writing by mocking open
        with patch("builtins.open", unittest.mock.mock_open()) as mock_file:
            agent.step_2_generate_code("TestApp", "Svelte", "D:/MyProjects/test-app")
            
        print("Structure Generation: OK")

if __name__ == '__main__':
    unittest.main()
