
import sys
import os
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init
init(autoreset=True)

def test_live_search():
    print("Initializing DataCoreAgent...")
    agent = DataCoreAgent()
    
    # 1. Force Clear Index for this test (simulate new file)
    agent.file_index = [] 
    
    # 2. Create Dummy File
    dummy_path = "d:/x99_zeta_99x.txt"
    with open(dummy_path, "w") as f:
        f.write("secret content")
        
    print(f"Created dummy file: {dummy_path}")
    print("Index cleared. Invoking search...")
    
    # 3. Search
    # This should trigger _live_search
    result = agent.search_file("x99 zeta 99x")
    
    print(f"\nResult: {result}")
    
    if result and "x99_zeta_99x.txt" in result:
        print("✅ Live Search PASSED")
    else:
        print("❌ Live Search FAILED")

    # Cleanup
    if os.path.exists(dummy_path):
        os.remove(dummy_path)

if __name__ == "__main__":
    test_live_search()
