import unittest
from unittest.mock import MagicMock, patch
import sys
import os

# MOCK Dependencies
sys.modules['config'] = MagicMock()
sys.modules['ollama'] = MagicMock()
sys.modules['psutil'] = MagicMock()
sys.modules['cv2'] = MagicMock()
sys.modules['google'] = MagicMock()
sys.modules['google.generativeai'] = MagicMock()

from modules.vision_agent import VisionAgent

class TestLocalVision(unittest.TestCase):
    def test_vram_check(self):
        agent = VisionAgent()
        
        # Mock Low VRAM (Pass)
        sys.modules['psutil'].virtual_memory.return_value.percent = 50
        self.assertTrue(agent.check_vram())
        
        # Mock High VRAM (Fail)
        sys.modules['psutil'].virtual_memory.return_value.percent = 95
        self.assertFalse(agent.check_vram())

    def test_analyze_local_flow(self):
        agent = VisionAgent()
        
        # Mock VRAM OK
        sys.modules['psutil'].virtual_memory.return_value.percent = 50
        
        # Mock Capture success
        agent.capture_image = MagicMock()
        
        # Mock Ollama Response
        sys.modules['ollama'].chat.return_value = {
            'message': {'content': 'A 3D Wireframe Cube'}
        }
        
        with patch('os.path.exists', return_value=True):
            res = agent.analyze_local()
            
        self.assertIn("Cube", res)
        sys.modules['ollama'].chat.assert_called()
        print("Local Vision Flow Verified.")

if __name__ == '__main__':
    unittest.main()
