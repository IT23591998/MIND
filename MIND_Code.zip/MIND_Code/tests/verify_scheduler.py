import sys
import os
import time
from colorama import init, Fore

sys.path.append(os.getcwd())

from modules.scheduler_agent import SchedulerAgent

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + "🚀 Starting Scheduler Verification...")
    
    agent = SchedulerAgent()
    
    print(Fore.CYAN + "   Setting Reminder for 2 seconds...")
    agent.set_reminder("Test Reminder Message", 2)
    
    print(Fore.YELLOW + "   Waiting 1 second (Should NOT trigger)...")
    time.sleep(1)
    pending = agent.check_pending()
    if not pending:
        print(Fore.GREEN + "✅ Check 1: No premature trigger.")
    else:
        print(Fore.RED + "❌ Premature trigger!")
        
    print(Fore.YELLOW + "   Waiting 2 seconds (Should trigger)...")
    time.sleep(2)
    due = agent.check_pending()
    
    if len(due) > 0 and due[0]['message'] == "Test Reminder Message":
        print(Fore.GREEN + f"✅ Check 2: Triggered correctly! msg='{due[0]['message']}'")
    else:
        print(Fore.RED + f"❌ Failed to trigger. Pending count: {len(due)}")

if __name__ == "__main__":
    run_verification()
