import unittest
from unittest.mock import MagicMock, patch
import sys
import os

from modules.android_agent import AndroidAutomator
import config

class TestFlutter(unittest.TestCase):
    @patch("subprocess.run")
    def test_flutter_create(self, mock_run):
        agent = AndroidAutomator()
        
        # Mock speech
        config.speech_queue = MagicMock()
        
        # Mock Flutter check
        agent.check_flutter_installed = MagicMock(return_value=True)
        
        # Run
        agent.create_flutter_app("MySuperApp")
        
        # Verify Command
        expected_cmd = "flutter create --org com.example mysuperapp"
        
        # Inspect subprocess calls
        # We expect [check_installed, create, open]
        # Just check if 'flutter create' was called
        calls = mock_run.call_args_list
        created = False
        for c in calls:
            args, kwargs = c
            if "flutter create" in str(args[0]):
                created = True
        
        self.assertTrue(created, "Flutter create command was not executed.")
        print("Flutter Logic verified.")

if __name__ == "__main__":
    unittest.main()
