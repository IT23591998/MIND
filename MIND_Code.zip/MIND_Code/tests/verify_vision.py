import unittest
from unittest.mock import MagicMock, patch
import os

# Mock dependencies if missing for CI/Test safety, though we try to install them.
try:
    import cv2
    import google.generativeai as genai
    DEPENDENCIES_OK = True
except ImportError:
    DEPENDENCIES_OK = False

from modules.vision_agent import VisionAgent

class TestVisionAgent(unittest.TestCase):
    def setUp(self):
        if not DEPENDENCIES_OK:
            self.skipTest("Dependencies missing")
            
        # Patch Environment
        self.env_patcher = patch.dict(os.environ, {"GEMINI_API_KEY": "fake_key"})
        self.env_patcher.start()
        self.addCleanup(self.env_patcher.stop)
        
        # Patch GenAI
        self.genai_patcher = patch('modules.vision_agent.genai')
        self.mock_genai = self.genai_patcher.start()
        self.addCleanup(self.genai_patcher.stop)

        # Patch PIL (to avoid image loading errors on fake file)
        self.pil_patcher = patch('PIL.Image.open')
        self.mock_pil = self.pil_patcher.start()
        self.addCleanup(self.pil_patcher.stop)
        
        self.agent = VisionAgent()
        
        # Mock Camera
        self.agent.capture_image = MagicMock(return_value=True)
        
        # Mock Gemini Model
        self.agent.model = MagicMock()
        mock_response = MagicMock()
        mock_response.text = "I see a test object."
        self.agent.model.generate_content.return_value = mock_response

    def test_analyze_feed(self):
        # Create dummy image file expected by logic
        with open("vision_temp.jpg", "wb") as f:
            f.write(b"\xFF\xD8\xFF") # Fake JPEG header
            
        res = self.agent.analyze_feed()
        print(f"Vision Response: {res}")
        self.assertIn("I see", res)
        
        # Cleanup
        if os.path.exists("vision_temp.jpg"):
            os.remove("vision_temp.jpg")

if __name__ == '__main__':
    unittest.main()
