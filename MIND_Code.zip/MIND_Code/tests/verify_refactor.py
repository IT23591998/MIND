import unittest
from unittest.mock import MagicMock, patch
import sys
import os

# MOCK EVERYTHING
sys.modules['psutil'] = MagicMock()
sys.modules['requests'] = MagicMock()
sys.modules['config'] = MagicMock()
sys.modules['modules.memory_agent'] = MagicMock()
sys.modules['litellm'] = MagicMock()
sys.modules['cv2'] = MagicMock()
sys.modules['google'] = MagicMock()
sys.modules['google.generativeai'] = MagicMock()
sys.modules['PIL'] = MagicMock()
sys.modules['PIL.Image'] = MagicMock()

from mind_brain import DynamicModelLoader
from modules.vision_agent import VisionAgent
from modules.qt_agent import QtAgent

class TestRefactor(unittest.TestCase):
    def test_model_loader(self):
        loader = DynamicModelLoader()
        
        # Mock High Pressure
        mock_mem = MagicMock()
        mock_mem.percent = 90
        sys.modules['psutil'].virtual_memory.return_value = mock_mem
        
        self.assertTrue(loader.check_gpu_pressure())
        
        # Test Unload
        loader.unload_model("llama3")
        sys.modules['requests'].post.assert_called_with(
            "http://localhost:11434/api/generate",
            json={"model": "llama3", "keep_alive": 0}
        )

    def test_vision_shared_memory(self):
        agent = VisionAgent()
        agent.model = MagicMock()
        agent.capture_image = MagicMock(return_value=True)
        
        # Test Return Image
        text, img = agent.analyze_feed(return_image=True)
        self.assertIsNotNone(img)
        
    def test_qt_pch(self):
        agent = QtAgent()
        agent.launch_ide = MagicMock()
        
        # Mock FS
        with patch('os.makedirs'), patch('os.path.exists', return_value=False), patch('builtins.open', unittest.mock.mock_open()) as mock_file:
            agent.create_project("TestApp")
            
            # Check for PCH config
            handle = mock_file()
            # We expect multiple writes. Let's check if 'PRECOMPILED_HEADER' was written
            content_written = False
            for call in handle.write.call_args_list:
                if "PRECOMPILED_HEADER" in call[0][0]:
                    content_written = True
                    break
            
            self.assertTrue(content_written, "PCH Config not found in .pro file")

if __name__ == '__main__':
    unittest.main()
