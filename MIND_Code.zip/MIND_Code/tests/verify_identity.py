import sounddevice as sd
import numpy as np
from resemblyzer import VoiceEncoder, preprocess_wav
from scipy.spatial.distance import cosine

# Load your fingerprint and the encoder
encoder = VoiceEncoder()
saved_fingerprint = np.load("D:/MIND_Project/assets/fingerprint.npy")

def check_access():
    fs = 44100
    duration = 3
    print("\n[MIND] Listening for identity...")
    
    # 1. Record a quick snippet
    recording = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='float32', device=2)
    sd.wait()
    
    # 2. Process the snippet
    wav = preprocess_wav(recording.flatten(), source_sr=fs)
    new_embedding = encoder.embed_utterance(wav)
    
    # 3. Compare with saved fingerprint
    # Cosine distance to similarity: 1 - distance
    score = 1 - cosine(saved_fingerprint, new_embedding)
    
    print(f"[MIND] Identity Score: {score:.2f}")
    
    if score > 0.75:
        print("[MIND] ACCESS GRANTED. Welcome back, Makeepan.")
    else:
        print("[MIND] ACCESS DENIED. Unauthorized user detected.")

if __name__ == "__main__":
    check_access()