import torch
from TTS.api import TTS
import os
import sys
import gc

# --- CONFIGURATION (FIXED) ---
# 1. Point to the FOLDER (not the file)
MODEL_DIR = r"D:\MIND_Project\tts_models\tts\tts_models--multilingual--multi-dataset--xtts_v2"

# 2. The script adds the filename automatically here
MODEL_PATH = os.path.join(MODEL_DIR, "model.pth")
CONFIG_PATH = os.path.join(MODEL_DIR, "config.json")

REF_AUDIO = "assets/mind_voice.wav"
OUTPUT_FILE = "voice_test.wav"
TEXT = "Systems initialized. I am running in Safe Mode on the CPU."

# --- LOW RAM SETTINGS ---
# Forces the AI to be gentle on memory to prevent crashes
torch.set_num_threads(1)
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
# ------------------------

print("   [1/5] Checking environment...")
device = "cpu"
print(f"   [INFO] Forcing Device: {device.upper()}")

# Clean memory before starting
gc.collect()

# Verify the files exist
if not os.path.exists(MODEL_PATH):
    print(f"   [CRITICAL] Missing file: {MODEL_PATH}")
    print("   Double-check your folder path!")
    sys.exit(1)
    
print("   [2/5] Loading AI Model... (This might freeze for 30-60s)")
try:
    # Load the model directly from the file path
    tts = TTS(model_path=MODEL_PATH, config_path=CONFIG_PATH, progress_bar=False).to(device)
    print("   [3/5] Model Loaded Successfully!")
except Exception as e:
    print(f"   [CRITICAL FAIL] Model crashed during load: {e}")
    sys.exit(1)

print("   [4/5] Generating Audio...")
try:
    tts.tts_to_file(text=TEXT, 
                    speaker_wav=REF_AUDIO, 
                    language="en", 
                    file_path=OUTPUT_FILE)
    print("   [5/5] Generation Complete!")
except Exception as e:
    print(f"   [CRITICAL FAIL] Generation error: {e}")
    sys.exit(1)

if os.path.exists(OUTPUT_FILE):
    print(f"   [SUCCESS] Audio saved to: {OUTPUT_FILE}")
    os.system(f"start {OUTPUT_FILE}")
else:
    print("   [ERROR] File was not created.")