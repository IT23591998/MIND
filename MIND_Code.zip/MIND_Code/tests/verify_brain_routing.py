import sys
import os
from unittest.mock import MagicMock

# Add current directory to path
sys.path.append(os.getcwd())

# Mock MemoryAgent to avoid DB connection issues during test
mock_memory = MagicMock()
mock_memory.MemoryAgent = MagicMock()
sys.modules['modules.memory_agent'] = mock_memory

try:
    from mind_brain import MindBrain
    from colorama import init, Fore
except ImportError as e:
    print(f"Import Error: {e}")
    sys.exit(1)

def test_routing():
    init(autoreset=True)
    print(f"{Fore.CYAN}--- INITIALIZING BRAIN FOR TEST ---")
    try:
        brain = MindBrain()
    except Exception as e:
        print(f"{Fore.RED}Failed to init MindBrain: {e}")
        return

    test_cases = [
        ("use ministral to summarize", "MINISTRAL"),
        ("mistral fast check", "MINISTRAL"),
        ("use deepseek r1 to solve", "DEEPSEEK"),
        ("write a python script for scraping", "CODER"),
        ("analyze data from csv", "ANALYST"),
        ("security scan of this target", "SECURITY"),
        ("explain the theory of relativity", "THEORIST"),
        ("just a normal chat", "MANAGER"),
        ("use glm 4.7 capabilities", "GLM"),
        ("advanced capabilities needed", "GLM"),
        ("optimize with cerebras speed", "CEREBRAS"),
        ("open source intelligence", "OSS_LLM")
    ]
    
    print(f"\n{Fore.CYAN}--- STARTING ROUTING VERIFICATION ---")
    all_passed = True
    
    for input_text, expected_brain in test_cases:
        chosen_brain = brain._determine_brain(input_text)
        
        if chosen_brain == expected_brain:
            print(f"{Fore.GREEN}✅ [PASS] '{input_text}' -> {chosen_brain}")
        else:
            # Some overlap might happen, let's see why
            print(f"{Fore.RED}❌ [FAIL] '{input_text}' -> Expected {expected_brain}, Got {chosen_brain}")
            all_passed = False
            
    if all_passed:
        print(f"\n{Fore.GREEN}🎉 ALL ROUTING TESTS PASSED.")
    else:
        print(f"\n{Fore.RED}⚠️ SOME ROUTING TESTS FAILED.")

if __name__ == "__main__":
    test_routing()
