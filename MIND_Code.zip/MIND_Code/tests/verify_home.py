import unittest
from unittest.mock import MagicMock, patch
import os
import json
import shutil
import config

from modules.home_agent import HomeAutomationAgent

class TestHomeAgent(unittest.TestCase):
    def setUp(self):
        # Patch config queues
        self.speech_patcher = patch('config.speech_queue')
        self.mock_speech = self.speech_patcher.start()
        self.addCleanup(self.speech_patcher.stop)
        
        self.hud_patcher = patch('config.hud_queue')
        self.mock_hud = self.hud_patcher.start()
        self.addCleanup(self.hud_patcher.stop)

        self.agent = HomeAutomationAgent()
        # Use a temporary state file for testing
        self.agent.state_file = "test_home_state.json"
        
    def tearDown(self):
        if os.path.exists("test_home_state.json"):
            os.remove("test_home_state.json")

    def test_control_lights(self):
        res = self.agent.control_device("bedroom lights", "on")
        print(f"Control Res: {res}")
        self.assertIn("turned on", res)
        
        # Verify JSON
        with open(self.agent.state_file, "r") as f:
            data = json.load(f)
        self.assertEqual(data["bedroom"]["lights"], "on")

    def test_set_environment(self):
        res = self.agent.set_environment("living room", "movie")
        print(f"Env Res: {res}")
        self.assertIn("movie", res)
        
        with open(self.agent.state_file, "r") as f:
            data = json.load(f)
        self.assertEqual(data["living_room"]["color"], "movie")

if __name__ == '__main__':
    unittest.main()
