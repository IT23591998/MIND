import unittest
import os
import shutil
import csv
from modules.accountant_agent import AccountantAgent

class TestAccountantAgent(unittest.TestCase):
    def setUp(self):
        # Use a test ledger
        self.agent = AccountantAgent()
        self.original_ledger = self.agent.ledger_file
        self.test_ledger = "D:/MIND_Project/test_finance_ledger.csv"
        self.agent.ledger_file = self.test_ledger
        
        if os.path.exists(self.test_ledger):
            os.remove(self.test_ledger)
        self.agent._ensure_ledger()

    def tearDown(self):
        if os.path.exists(self.test_ledger):
            os.remove(self.test_ledger)
        # Restore original path just in case
        self.agent.ledger_file = self.original_ledger

    def test_log_transaction(self):
        res = self.agent.log_transaction("expense", 100, "food", "lunch")
        print(f"Log Result: {res}")
        self.assertIn("Logged expense", res)
        
        with open(self.test_ledger, 'r') as f:
            lines = f.readlines()
            self.assertEqual(len(lines), 2) # Header + 1 row
            self.assertIn("lunch", lines[1])

    def test_get_balance(self):
        self.agent.log_transaction("income", 1000, "salary", "job")
        self.agent.log_transaction("expense", 200, "bills", "electric")
        
        res = self.agent.get_balance()
        print(f"Balance Result: {res}")
        self.assertIn("800.00", res)

    def test_report(self):
        self.agent.log_transaction("expense", 50, "food", "lunch")
        report = self.agent.generate_monthly_report()
        print(f"Report: \n{report}")
        self.assertIn("Total Spent: 50.00", report)

if __name__ == '__main__':
    unittest.main()
