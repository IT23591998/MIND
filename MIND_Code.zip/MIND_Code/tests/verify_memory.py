import unittest
import os
import shutil
import time
import config
from modules.memory_agent import MemoryAgent
from mind_brain import MindBrain

class TestMemory(unittest.TestCase):
    def setUp(self):
        # Use a separate test DB
        self.test_db = os.path.join(config.ASSETS_DIR, "test_mind_memory.db")
        # Ensure cleanup
        if os.path.exists(self.test_db):
            os.remove(self.test_db)
            
    def tearDown(self):
        if os.path.exists(self.test_db):
            try:
                os.remove(self.test_db)
            except:
                pass

    def test_agent_persistence(self):
        # 1. Init Agent with Test DB
        agent = MemoryAgent()
        agent.db_path = self.test_db
        agent._init_db()
        
        # 2. Save Data
        agent.save_message("user", "Hello Memory")
        agent.save_message("assistant", "Hi there")
        
        # 3. Re-init Agent (Simulate Restart)
        new_agent = MemoryAgent()
        new_agent.db_path = self.test_db
        
        # 4. Fetch
        context = new_agent.get_recent_context(limit=5)
        print(f"Retrieved Context: {context}")
        
        self.assertEqual(len(context), 2)
        self.assertEqual(context[0]['role'], 'user')
        self.assertEqual(context[1]['content'], 'Hi there')

    def test_brain_integration(self):
        # To test Brain, we need to inject the test DB into its memory agent
        brain = MindBrain()
        brain.memory.db_path = self.test_db
        brain.memory._init_db()
        
        # Add to history
        brain.add_to_history("user", "Testing Brain Memory")
        
        # Simulate Restart
        new_brain = MindBrain()
        new_brain.memory.db_path = self.test_db
        # We manually trigger load because __init__ ran before we swapped the DB path
        new_brain.history = new_brain.memory.get_recent_context(limit=10)
        
        print(f"Brain History: {new_brain.history}")
        self.assertTrue(any(msg['content'] == "Testing Brain Memory" for msg in new_brain.history))

if __name__ == '__main__':
    unittest.main()
