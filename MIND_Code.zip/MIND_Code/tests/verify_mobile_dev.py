import sys
import os
from colorama import init, Fore

sys.path.append(os.getcwd())

from modules.mobile_dev_agent import MobileDevAgent

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + "🚀 Starting Mobile Dev Verification...")
    
    agent = MobileDevAgent()
    
    # Simple generation test
    # This will likely run in SIMULATION mode if SDK is missing
    print(Fore.CYAN + "   Requesting: 'Mind_App_Test' with [maps, camera]")
    
    result = agent.create_flutter_app("Mind_App_Test", features=["maps", "camera"])
    
    print(Fore.YELLOW + f"   Status: {result['status']}")
    
    if result['status'] in ['success', 'simulated']:
        print(Fore.GREEN + "✅ Mobile Dev Agent responded correctly.")
    else:
        print(Fore.RED + f"❌ Mobile Dev Agent failed: {result.get('error')}")

if __name__ == "__main__":
    run_verification()
