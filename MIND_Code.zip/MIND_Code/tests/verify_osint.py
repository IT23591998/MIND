import sys
import os
from colorama import init, Fore

sys.path.append(os.getcwd())

from modules.security_agent import SecurityAgent

def run_verification():
    init(autoreset=True)
    print(Fore.WHITE + "🚀 Verify OSINT...")
    
    agent = SecurityAgent()
    # Scan self
    res = agent.run_port_scan("127.0.0.1", [135, 445]) # Common Windows ports
    
    if res['total_scanned'] > 0:
        print(Fore.GREEN + "✅ OSINT Scan executed.")
        print(res)
    else:
        print(Fore.RED + "❌ Failed.")

if __name__ == "__main__":
    run_verification()
