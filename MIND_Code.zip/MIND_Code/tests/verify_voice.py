import unittest
from unittest.mock import MagicMock, patch
import sys
import os

# MOCK CONFIG
sys.modules['config'] = MagicMock()
sys.modules['sounddevice'] = MagicMock()
sys.modules['soundfile'] = MagicMock()

# Mock TTS
sys.modules['TTS'] = MagicMock()
sys.modules['TTS.api'] = MagicMock()

from modules.voice_agent import NeuralVoiceAgent

class TestVoice(unittest.TestCase):
    @patch('modules.voice_agent.HAS_NEURAL', True)
    def test_neural_speak(self):
        agent = NeuralVoiceAgent()
        # Mock successful load
        agent.tts = MagicMock()
        agent.is_loaded = True
        
        agent.speak("Hello Neural World")
        
        agent.tts.tts_to_file.assert_called()
        print("Neural Speak Test Passed")

    @patch('modules.voice_agent.HAS_NEURAL', False)
    def test_fallback_speak(self):
        agent = NeuralVoiceAgent()
        with patch('subprocess.run') as mock_run:
            agent.speak("Hello System World")
            mock_run.assert_called()
            print("Fallback Speak Test Passed")

if __name__ == '__main__':
    unittest.main()
