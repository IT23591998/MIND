import hashlib
from modules.sentinel import Sentinel

s = Sentinel()
target = "8bcd1d5225fae3740d6d5d5c0734dd23aa4b6480d1969a53e6d30b910103cce0" # alpha1

print(f"Target Hash: {target}")

attempts = ["alpha1", "alpha 1", "Alpha1"]
for p in attempts:
    cleaned = p.strip().lower().replace(" ", "")
    h = hashlib.sha256(cleaned.encode()).hexdigest()
    print(f"Input: '{p}' -> Cleaned: '{cleaned}' -> Hash: {h} -> Match: {h == target}")
