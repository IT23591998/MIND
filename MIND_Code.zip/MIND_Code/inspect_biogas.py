
import pandas as pd
import sys
from colorama import init, Fore
init(autoreset=True)

file_path = "d:/MIND_Project/Farm-scale Biodigester 2024_Performance.xlsx"

try:
    print(f"{Fore.CYAN}Loading {file_path}...")
    df = pd.read_excel(file_path)
    
    print(f"\n{Fore.GREEN}Columns Found:{Fore.RESET}")
    print(df.columns.tolist())
    
    print(f"\n{Fore.GREEN}First 3 Rows:{Fore.RESET}")
    print(df.head(3))
    
    print(f"\n{Fore.GREEN}Data Types:{Fore.RESET}")
    print(df.dtypes)
    
except Exception as e:
    print(f"{Fore.RED}Error reading file: {e}")
