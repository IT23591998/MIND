import requests
import os

# The exact address of the bad file
DEST_PATH = r"D:\MIND_Project\tts_models\tts\tts_models--multilingual--multi-dataset--xtts_v2\vocab.json"

# The official clean version
URL = "https://huggingface.co/coqui/XTTS-v2/resolve/main/vocab.json"

print("   [SURGERY] Removing corrupted vocab.json...")
if os.path.exists(DEST_PATH):
    os.remove(DEST_PATH)

print("   [SURGERY] Downloading fresh copy...")
try:
    response = requests.get(URL)
    with open(DEST_PATH, 'wb') as f:
        f.write(response.content)
    print("   [SUCCESS] New vocab.json installed.")
    print(f"   [INFO] New Size: {len(response.content)} bytes")
except Exception as e:
    print(f"   [FAIL] Download error: {e}")