# Visual Evidence

Since the large 3D models and assets are not included in this repository, please add a screenshot of the 3D models (e.g., from Blender) in this folder.

**Action Required:**
1. Open your 3D project in Blender or your preferred tool.
2. Take a high-quality screenshot of the models.
3. Save the image as `3d_models_preview.png` (or similar) in this folder.
4. Update this README or the main README to reference this image.

This provides visual proof that the "missing" 30GB of assets actually exists and works.
