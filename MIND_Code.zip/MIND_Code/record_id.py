import sounddevice as sd
from scipy.io.wavfile import write
import os

def record_voice(name, duration=7):
    fs = 16000 # High quality for AI
    print(f"\n--- RECORDING: {name} ---")
    print("Speak naturally: 'Jarvis, this is my voice. Secure the system.'")
    recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
    sd.wait()
    write(f"voice_id/{name}.wav", fs, recording)
    print("Recording saved!")

if not os.path.exists("voice_id"):
    os.makedirs("voice_id")

# We will take 3 samples to be accurate
for i in range(1, 4):
    record_voice(f"master_voice_{i}")