
import pandas as pd
file_path = "d:/MIND_Project/Farm-scale Biodigester 2024_Performance.xlsx"
try:
    df = pd.read_excel(file_path)
    print("--- COLUMNS ---")
    for col in df.columns:
        print(repr(col))
except Exception as e:
    print(e)
