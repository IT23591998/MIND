import sys
import os

# Add local path
sys.path.append(os.getcwd())

from modules.android_agent import AndroidAutomator
from colorama import init, Fore

init(autoreset=True)

print(f"{Fore.CYAN}📱 [BUILDER] Inherited Android Agent. Initializing build sequence...")

try:
    bot = AndroidAutomator()
    # Force project root if needed, or stick to default "D:/MyProjects/"
    # bot.projects_root = "D:/NewFolderMobile/" # Uncomment if user strictly implied a SPECIFIC new folder
    
    print(f"{Fore.CYAN}📱 [BUILDER] Target: D:/MyProjects/MIND_Client")
    bot.generate_mind_client()
    
    print(f"{Fore.GREEN}✅ [BUILDER] Build sequence complete.")

except Exception as e:
    print(f"{Fore.RED}❌ [BUILDER] Error: {e}")
    import traceback
    traceback.print_exc()
