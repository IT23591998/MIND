import torch
from TTS.api import TTS
import os
import sys
import time

# --- CONFIGURATION ---
# The correct Folder Path
MODEL_DIR = r"D:\MIND_Project\tts_models\tts\tts_models--multilingual--multi-dataset--xtts_v2"
MODEL_PATH = os.path.join(MODEL_DIR, "model.pth")
CONFIG_PATH = os.path.join(MODEL_DIR, "config.json")

REF_AUDIO = "assets/mind_voice.wav"
OUTPUT_FILE = "response.wav"

# Low RAM Settings
torch.set_num_threads(1)
os.environ["OMP_NUM_THREADS"] = "1"
# ---------------------

print("\n   [SYSTEM] Initializing MIND Interface...")

# Load the brain once (so we don't have to wait every time)
try:
    print("   [SYSTEM] Loading Neural Network... (Stand by)")
    tts = TTS(model_path=MODEL_DIR, config_path=CONFIG_PATH, progress_bar=False).to("cpu")
    print("   [SYSTEM] Neural Network Active.\n")
except Exception as e:
    print(f"   [CRITICAL FAIL] {e}")
    sys.exit(1)

print("   ==================================================")
print("   MIND: Systems online. Audio output enabled.")
print("   (Type 'exit' to shut me down)")
print("   ==================================================\n")

while True:
    user_input = input("   [YOU] > ")
    
    if user_input.lower() in ["exit", "quit"]:
        print("   [MIND] Entering sleep mode...")
        break
    
    if not user_input.strip():
        continue

    # --- THE PERSONALITY FILTER ---
    # Currently, we don't have Llama 3 connected yet, so we will fake the logic.
    # We make him repeat what you said, but with attitude.
    response_text = f"Oh, wonderful. You want me to say: {user_input}"
    
    print(f"   [MIND] > {response_text}")
    print("   [...processing audio...]")
    
    try:
        # Generate the audio
        tts.tts_to_file(text=response_text, 
                        speaker_wav=REF_AUDIO, 
                        language="en", 
			speed=3.0,
                        file_path=OUTPUT_FILE)
        
        # Play it immediately
        os.system(f"start {OUTPUT_FILE}")
        
    except Exception as e:
        print(f"   [ERROR] Voice Module Failure: {e}")