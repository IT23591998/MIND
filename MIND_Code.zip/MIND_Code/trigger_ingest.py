
import sys
import os
sys.path.append("d:/MIND_Project")
from modules.knowledge_agent import KnowledgeAgent
from colorama import init, Fore
init(autoreset=True)

print("Initializing KnowledgeAgent...")
ka = KnowledgeAgent()
print(f"Knowledge Dir: {ka.knowledge_dir}")
if os.path.exists(ka.knowledge_dir):
    print(f"Contents: {os.listdir(ka.knowledge_dir)}")
else:
    print("Knowledge Dir does not exist!")

print("Ingesting new data (Mechadex)...")
res = ka.ingest_data()
print(f"Ingestion Result: {res}")
