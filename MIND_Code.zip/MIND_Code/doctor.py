import os
import json

# The folder we are checking
MODEL_DIR = r"D:\MIND_Project\tts_models\tts\tts_models--multilingual--multi-dataset--xtts_v2"

required_files = {
    "model.pth": 1000000000,     # Should be > 1GB
    "dvae.pth": 100000000,       # Should be > 100MB
    "speakers_xtts.pth": 1000,   # Should be > 1KB
    "config.json": 10,           # Should be > 10 bytes
    "vocab.json": 100            # Should be > 100 bytes
}

print(f"--- DIAGNOSING BRAIN AT: {MODEL_DIR} ---")

if not os.path.exists(MODEL_DIR):
    print(f"[CRITICAL FAIL] The folder does not exist!\nPath: {MODEL_DIR}")
    exit()

all_good = True

for filename, min_size in required_files.items():
    filepath = os.path.join(MODEL_DIR, filename)

    if not os.path.exists(filepath):
        print(f"[MISSING] {filename} is NOT in the folder.")
        all_good = False
        continue

    size = os.path.getsize(filepath)
    status = "OK" if size > min_size else "CORRUPT/EMPTY"

    # Check if JSON files are valid
    if filename.endswith(".json") and size > 0:
        try:
            with open(filepath, 'r') as f:
                json.load(f)
        except:
            status = "INVALID JSON (Syntax Error)"

    print(f"File: {filename:<20} | Size: {size/1024:.2f} KB | Status: {status}")

    if status != "OK":
        all_good = False

if all_good:
    print("\n[RESULT] All files look healthy.")
else:
    print("\n[RESULT] FOUND BROKEN FILES. See above.")