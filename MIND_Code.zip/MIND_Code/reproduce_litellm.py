import os
import sys
from litellm import completion
from dotenv import load_dotenv

sys.path.append(os.getcwd())
load_dotenv()
os.environ["TIKTOKEN_CACHE_DIR"] = r"D:\MIND_Project\cache"

print("Attempting LiteLLM completion with Groq...")

try:
    # Use a dummy key if not set, though it might fail auth, we want to catch the connection error first
    api_key = os.getenv("GROQ_API_KEY", "gsk_dummy")
    
    response = completion(
        model="groq/llama-3.3-70b-versatile",
        messages=[{"role": "user", "content": "Hi"}],
        api_key=api_key
    )
    print("Success!")
    print(response)
except Exception as e:
    print(f"Caught error: {e}")
