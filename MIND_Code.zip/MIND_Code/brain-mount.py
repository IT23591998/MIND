import torch
from TTS.api import TTS
print("CUDA Available:", torch.cuda.is_available())
print("TTS Models:", TTS().list_models()[0:5]) # Should list some models
exit()