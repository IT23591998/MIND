from resemblyzer import VoiceEncoder, preprocess_wav
from pathlib import Path
import numpy as np

# 1. Initialize the Encoder (Pre-trained model)
encoder = VoiceEncoder()

# 2. Load and Pre-process your recording
fpath = Path("D:/MIND_Project/assets/my_voice_sample.wav")
wav = preprocess_wav(fpath)

# 3. Create the 256-value fingerprint
fingerprint = encoder.embed_utterance(wav)

# 4. Save the embedding for later use
np.save("D:/MIND_Project/assets/fingerprint.npy", fingerprint)

print("Voice fingerprint successfully generated and saved!")
print(f"Embedding shape: {fingerprint.shape}")  # Should be (256,)