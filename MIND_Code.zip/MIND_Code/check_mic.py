import sounddevice as sd

print("\n--- AVAILABLE AUDIO DEVICES ---")
print(sd.query_devices())

print("\n--- DEFAULT INPUT DEVICE ---")
try:
    default_mic = sd.query_devices(kind='input')
    print(f"Name: {default_mic['name']}")
    print(f"Channels: {default_mic['max_input_channels']}")
except:
    print("No default input found.")