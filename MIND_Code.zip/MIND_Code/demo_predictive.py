
import sys
import os
import pandas as pd
import numpy as np
sys.path.append("d:/MIND_Project")

from modules.datacore_agent import DataCoreAgent
from colorama import init, Fore
init(autoreset=True)

def run_demo():
    print(f"{Fore.CYAN}--- MIND DataCore: Predictive Modeling Demo ---")
    
    # 1. Generate Synthetic Data (Salary Prediction)
    print(f"{Fore.YELLOW}Generating synthetic dataset...")
    np.random.seed(42)
    n_samples = 100
    
    experience = np.random.normal(5, 2, n_samples)
    certifications = np.random.randint(0, 5, n_samples)
    noise = np.random.normal(0, 5000, n_samples)
    
    # Formula: Base 30k + 8k per year + 2k per cert
    salary = 30000 + (experience * 8000) + (certifications * 2000) + noise
    
    df = pd.DataFrame({
        'YearsExperience': experience,
        'Certifications': certifications,
        'Salary': salary
    })
    
    csv_path = "d:/mind_salary_data.csv"
    df.to_csv(csv_path, index=False)
    print(f"{Fore.GREEN}Dataset saved to: {csv_path}")
    print(df.head(3))
    
    # 2. Initialize Agent
    agent = DataCoreAgent()
    
    # 3. Ask Agent to Predict
    print(f"\n{Fore.YELLOW}Asking DataCore to train a model for 'Salary'...")
    report = agent.analyze_predictive(csv_path, target_col="Salary")
    
    print(f"\n{Fore.CYAN}--- Final Report ---")
    print(report)
    
    # Cleanup
    # os.remove(csv_path) 

if __name__ == "__main__":
    run_demo()
