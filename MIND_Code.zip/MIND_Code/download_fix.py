import os
from TTS.utils.manage import ModelManager

# Force the AI to use the D: drive for storage
os.environ["TTS_HOME"] = r"D:\MIND_Project\tts_models"

print("   [SYSTEM] Starting Clean Download of XTTS v2...")
print("   [SYSTEM] Target Folder: D:\\MIND_Project\\tts_models")
print("   [SYSTEM] This is a 1.87GB file. Please wait for the success message.")

try:
    # Use the internal manager to pull the model
    manager = ModelManager(output_prefix=os.environ["TTS_HOME"])
    manager.download_model("tts_models/multilingual/multi-dataset/xtts_v2")
    print("\n   [SUCCESS] Download Complete! The brain is fully assembled.")
except Exception as e:
    print(f"\n   [ERROR] Download failed: {e}")