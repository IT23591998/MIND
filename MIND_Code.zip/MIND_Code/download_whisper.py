import os
from faster_whisper import WhisperModel

# --- CONFIGURATION ---
my_cache_path = "D:/MIND_Project/huggingface_cache"
os.environ['HF_HOME'] = my_cache_path

if not os.path.exists(my_cache_path):
    os.makedirs(my_cache_path)

print(f"--- STARTING FRESH DOWNLOAD TO {my_cache_path} ---")
print("This may take a few minutes. Please wait...")

try:
    # This command forces the download of the 'base' model
    model = WhisperModel("base", device="cuda", compute_type="float16", download_root=my_cache_path)
    
    print("\n✅ SUCCESS: Whisper Model 'base' downloaded and verified.")
    print("You can now run 'mind_core_loop.py' again.")
    
except Exception as e:
    print(f"\n❌ ERROR: Download failed.")
    print(e)