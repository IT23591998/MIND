import json
import os
import time
from colorama import Fore

class SchedulerAgent:
    """
    Manages time-based tasks and reminders via a JSON queue.
    """
    FILE_PATH = "d:/MIND_Project/memory/schedule.json"

    def __init__(self):
        os.makedirs(os.path.dirname(self.FILE_PATH), exist_ok=True)
        self.tasks = self._load()

    def _load(self):
        if os.path.exists(self.FILE_PATH):
            try:
                with open(self.FILE_PATH, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []

    def _save(self):
        with open(self.FILE_PATH, 'w') as f:
            json.dump(self.tasks, f, indent=2)

    def set_reminder(self, message: str, delay_seconds: int):
        """
        Adds a reminder to the queue.
        """
        due_time = time.time() + delay_seconds
        task = {
            "type": "reminder",
            "message": message,
            "due_time": due_time,
            "created_at": time.time()
        }
        self.tasks.append(task)
        self.tasks.sort(key=lambda x: x['due_time']) # Keep sorted
        self._save()
        print(Fore.CYAN + f"⏰ [SCHEDULER] Timer set for {delay_seconds}s: '{message}'")

    def check_pending(self):
        """
        Checks for tasks that are due. Removes them from queue and returns them.
        """
        now = time.time()
        due_tasks = []
        remaining_tasks = []
        
        for task in self.tasks:
            if task['due_time'] <= now:
                due_tasks.append(task)
            else:
                remaining_tasks.append(task)
        
        if due_tasks:
            self.tasks = remaining_tasks
            self._save()
            
        return due_tasks
