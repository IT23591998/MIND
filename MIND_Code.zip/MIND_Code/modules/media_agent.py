import pyautogui
import config

class MediaAgent:
    def play_pause(self):
        pyautogui.press("playpause")
        return "Toggled playback."
        
    def next_track(self):
        pyautogui.press("nexttrack")
        return "Skipped track."
        
    def previous_track(self):
        pyautogui.press("prevtrack")
        return "Previous track."
        
    def volume_up(self):
        pyautogui.press("volumeup")
        pyautogui.press("volumeup")
        return "Volume increased."
        
    def volume_down(self):
        pyautogui.press("volumedown")
        pyautogui.press("volumedown")
        return "Volume decreased."
