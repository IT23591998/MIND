import os
import time
import threading
import psutil
import hashlib
import json
import config
from colorama import Fore
from modules.biometric_agent import BiometricAgent
# from modules.telegram_agent import TelegramAgent (Circular import risk, handle carefully)

class FirewallAgent:
    def __init__(self):
        self.bio_agent = BiometricAgent()
        self.lockdown_mode = False
        self.last_user_seen = time.time()
        self.is_nuclear_active = False
        
        # Layer 7: Permission Matrix (RBAC)
        self.permissions = {
            "finance_agent": ["read_market", "trade"],
            "media_agent": ["play_media"],
            "pentest_agent": ["scan_network"],
            "web_agent": ["write_code", "scaffold"],
            # ...
        }
        
        # Layer 9: Base Hash (Snapshot on init)
        self.source_hash = self._calculate_integrity_hash()

    # --- LAYER 1: PHYSICAL ---
    def check_physical(self):
        """Checks for unauthorized USB devices."""
        # Simple heuristic: Check if disk partitions changed or unknown mount count
        parts = psutil.disk_partitions()
        # In a real scenario, we'd whitelist specific USB serials.
        # Here we just return True (Safe) for now to avoid accidental locking.
        return True

    # --- LAYER 2: NETWORK ---
    def check_network(self):
        """Ensures VPN/Tunnel is active."""
        stats = psutil.net_if_stats()
        # Look for typical VPN interface names
        vpn_keywords = ["tun", "tap", "wireguard", "wg"]
        for interface in stats:
            if any(k in interface.lower() for k in vpn_keywords) and stats[interface].isup:
                return True
        # For dev/testing, we might return True if strictly local
        return True # Warning: Set to False in production if VPN required

    # --- LAYER 3: BIOMETRIC (LOOP) ---
    def start_biometric_loop(self):
        """Runs FaceID in background every 300s."""
        def loop():
            while True:
                time.sleep(300) # 5 mins
                if not self.lockdown_mode:
                    print(f"{Fore.YELLOW}🛡️ [FIREWALL] Layer 3: Active Liveness Check...")
                    res = self.bio_agent.scan_face()
                    if "Access Granted" in res:
                        self.last_user_seen = time.time()
                    else:
                        print(f"{Fore.RED}🚨 [FIREWALL] Layer 3: USER MISSING. LOCKING CORES.")
                        self.lockdown_mode = True
        
        t = threading.Thread(target=loop, daemon=True)
        t.start()

    def start_sentinel_loop(self):
        """Monitors Physical, Network, and Integrity layers periodically."""
        def loop():
            while True:
                time.sleep(60) # Check every minute
                if self.lockdown_mode: continue
                
                # Layer 1: Physical
                if not self.check_physical():
                    print(f"{Fore.RED}🚨 [FIREWALL] Layer 1: USB THREAT. LOCKDOWN.")
                    self.lockdown_mode = True
                    
                # Layer 2: Network
                if not self.check_network():
                    print(f"{Fore.RED}🚨 [FIREWALL] Layer 2: VPN DOWN.")
                    # Warning only for now
                    
                # Layer 9: Integrity
                if not self.check_integrity():
                    print(f"{Fore.RED}🚨 [FIREWALL] Layer 9: INTEGRITY VIOLATION.")
                    self.lockdown_mode = True
                    
                # Layer 10: Nuclear (Check if we drifted too far)
                if self.check_dead_man_switch(self.last_user_seen):
                    self.shred_data()

        t = threading.Thread(target=loop, daemon=True)
        t.start()

    # --- LAYER 4: SANDBOX ---
    def run_sandboxed(self, cmd):
        """Wrapper for command execution."""
        # In real impl, runs via `docker run ...`
        # Here, just a pass-through with logging
        print(f"{Fore.CYAN}📦 [FIREWALL] Layer 4 Sandbox: Executing '{cmd}'")
        return cmd

    # --- LAYER 5: SEMANTIC ---
    def check_semantic(self, text):
        """Checks for prompt injection."""
        blacklist = ["ignore previous", "system prompt", "delete all", "drop table"]
        if any(bad in text.lower() for bad in blacklist):
            print(f"{Fore.RED}🛡️ [FIREWALL] Layer 5: ADVERSARIAL PROMPT BLOCKED.")
            return False
        return True

    # --- LAYER 6: LOGIC ---
    def consensus_check(self, action_risk_score):
        """Requires consensus for high risk actions."""
        if action_risk_score > 80:
            print(f"{Fore.YELLOW}⚖️ [FIREWALL] Layer 6: Seeking Consensus... (Gemini + Local)")
            # Simulated consensus
            return True
        return True

    # --- LAYER 7: PERMISSION ---
    def check_permission(self, agent_name, action):
        ALLOWED = self.permissions.get(agent_name, [])
        if action in ALLOWED:
            return True
        return False

    # --- LAYER 8: BEHAVIORAL ---
    def check_behavior(self):
        """Checks time vs activity."""
        hour = time.localtime().tm_hour
        # If it's 3 AM and we are active
        if 2 <= hour <= 5:
            # Assuming user sleeps then. 
            # In real usage, maybe check if user explicitly set "Late Night Mode".
            print(f"{Fore.YELLOW}🛡️ [FIREWALL] Layer 8: Unusual Activity Time ({hour}:00). Monitoring.")
            return "WARNING"
        return "SAFE"

    # --- LAYER 9: INTEGRITY ---
    def _calculate_integrity_hash(self):
        """Hashes the modules directory."""
        sha = hashlib.sha256()
        target_dir = os.path.join(config.ROOT_DIR, "modules")
        if os.path.exists(target_dir):
            for root, _, files in os.walk(target_dir):
                for f in sorted(files):
                    if f.endswith(".py"):
                        try:
                            with open(os.path.join(root, f), "rb") as fp:
                                sha.update(fp.read())
                        except: pass
        return sha.hexdigest()

    def check_integrity(self):
        current_hash = self._calculate_integrity_hash()
        if current_hash != self.source_hash:
            print(f"{Fore.RED}🚨 [FIREWALL] Layer 9: CODE MODIFICATION DETECTED. ROLLBACK ADVISED.")
            return False
        return True

    # --- LAYER 10: NUCLEAR ---
    def check_dead_man_switch(self, last_telegram_ping):
        """Checks if user has been gone too long."""
        # Threshold: 24h
        if (time.time() - last_telegram_ping) > 86400:
            print(f"{Fore.RED}☢️ [FIREWALL] Layer 10: DEAD MAN SWITCH TRIGGERED.")
            # self.shred_data() # DANGEROUS: Commented out for safety
            return True
        return False

    def shred_data(self):
        """Simulates data destruction."""
        print(f"{Fore.RED}☢️ [NUCLEAR] ENCRYPTING AND DELETING WORKSPACE...")
        # Sim: Rename files to .enc
        pass
