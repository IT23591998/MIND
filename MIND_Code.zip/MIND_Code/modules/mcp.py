import json
import uuid
import time
from dataclasses import dataclass, asdict, field
from typing import Dict, Any, Optional, List
from colorama import Fore, Style

# Import MindBrain for execution
from mind_brain import MindBrain

@dataclass
class MCPTask:
    """Standardized Task Definition."""
    input_text: str
    domain: str = "General"
    task_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    priority: str = "normal"
    status: str = "pending"

@dataclass
class MCPResult:
    """Standardized Result Definition."""
    task_id: str
    output: str
    overall_confidence: float
    meta_log: Dict[str, Any]
    status: str = "completed"

class MasterControlProgram:
    """
    The Central Orchestrator for MIND.
    Manages task routing, execution, and quality control (Confidence Feedback Loop).
    """
    
    def __init__(self):
        self.brain = MindBrain()
        self.task_queue: List[MCPTask] = []
        self.task_history: Dict[str, MCPResult] = {}
        
        # Thresholds
        self.CONFIDENCE_THRESHOLD = 0.70  # Below this, we flag for review or retry

    def submit_task(self, input_text: str, domain: str = "General") -> MCPResult:
        """Entry point for new tasks."""
        task = MCPTask(input_text=input_text, domain=domain)
        self.task_queue.append(task)
        print(Fore.CYAN + f"🌐 [MCP] Task Submitted: {task.task_id} | Domain: {domain}")
        
        # For now, execute immediately (Sequential Mode)
        return self._process_task(task)

    def _process_task(self, task: MCPTask) -> MCPResult:
        """
        Internal processing loop:
        1. Route (Select Brain)
        2. Execute (Think)
        3. Evaluate (Confidence Check)
        """
        print(Fore.CYAN + f"⚙️  [MCP] Processing Task: {task.task_id}...")
        task.status = "processing"
        
        # 1. Routing & Execution
        # Check for Simulation Requests
        if task.domain.lower() == "simulation" or "simulate" in task.input_text.lower():
            from modules.simulation.controller import SimulationController
            sim = SimulationController()
            
            # Simple parsing for V1: Try to determine type from text if not structured
            sim_payload = { "simulation_type": "energy", "sub_type": "solar", "parameters": {"area_m2": 20} }
            
            # NLP Helper for V2.1
            txt = task.input_text.lower()
            if "wind" in txt:
                sim_payload["sub_type"] = "wind"
                sim_payload["parameters"] = {"turbine_count": 2}
            elif "stress" in txt or "beam" in txt:
                sim_payload["simulation_type"] = "engineering"
                sim_payload["sub_type"] = "stress"
                sim_payload["parameters"] = {"load_n": 5000, "material": "steel"}
            elif "gear" in txt:
                sim_payload["simulation_type"] = "engineering"
                sim_payload["sub_type"] = "gear"
                sim_payload["parameters"] = {"driver_teeth": 20, "driven_teeth": 60}
            
            sim_result = sim.run_simulation(sim_payload)
            
            # Convert Sim Result to MCP Result
            result = MCPResult(
                task_id=task.task_id,
                output=f"Simulation Complete. Results: {json.dumps(sim_result['results'], indent=2)}",
                overall_confidence=sim_result['confidence'],
                meta_log={"source": "Simulation Engine", "details": sim_result}
            )
        
        # Check for Knowledge Updates
        elif task.domain.lower() == "knowledge" or "update knowledge" in task.input_text.lower():
            from modules.knowledge_agent import KnowledgeAgent
            agent = KnowledgeAgent()
            
            # Extract path (Primitive extraction for V1)
            # Assumption: Input is "Update knowledge from [PATH]"
            import re
            path_match = re.search(r"from\s+([a-zA-Z0-9_:/\\.-]+)", task.input_text)
            path = path_match.group(1) if path_match else task.input_text
            
            # Clean up path quotes is common
            path = path.strip().strip("'").strip('"')
            
            status_msg = agent.ingest_external_source(path)
            
            result = MCPResult(
                task_id=task.task_id,
                output=status_msg,
                overall_confidence=1.0, 
                meta_log={"action": "Knowledge Ingestion", "path": path}
            )

        else:
            # Standard Brain Execution
            log_entry = self.brain.think_with_meta(task.input_text)
            
            # 2. Extract Results
            result = MCPResult(
                task_id=task.task_id,
                output=log_entry.final_response,
                overall_confidence=log_entry.overall_confidence,
                meta_log=log_entry.to_dict()
            )
        
        # 3. Evaluation & Feedback Loop
        final_result = self._evaluate_and_refine(task, result)
        
        self.task_history[task.task_id] = final_result
        return final_result

    def _evaluate_and_refine(self, task: MCPTask, result: MCPResult) -> MCPResult:
        """
        The Feedback Loop.
        Checks confidence. If low, can trigger a retry or flag it.
        """
        if result.overall_confidence < self.CONFIDENCE_THRESHOLD:
            print(Fore.YELLOW + f"⚠️  [MCP] Low Confidence detected ({result.overall_confidence:.2f}).")
            
            # Simple heuristic: If it's really low, append a disclaimer or retry hint
            # Future: Auto-retry with "Think step-by-step" prompt
            
            if result.overall_confidence < 0.4:
                result.status = "flagged_for_review"
                result.output = f"[WARNING: Low Confidence {result.overall_confidence}] " + result.output
            else:
                result.status = "needs_verification"
        
        print(Fore.GREEN + f"✅ [MCP] Task Completed: {task.task_id} | Conf: {result.overall_confidence}")
        return result

    def get_status(self):
        return {
            "queue_pending": len(self.task_queue),
            "history_count": len(self.task_history)
        }

    def submit_consensus_task(self, input_text: str, brains: List[str] = ["THEORIST", "ANALYST"]) -> MCPResult:
        """
        Executes a High-Assurance task by querying multiple brains and aggregating results.
        """
        print(Fore.MAGENTA + f"⚖️  [MCP] Consensus Sequence Initiated: {brains}")
        task_id = str(uuid.uuid4())[:8]
        
        # 1. Parallel Execution (Sequential for V1)
        brain_outputs = []
        for brain_type in brains:
            print(Fore.CYAN + f"   👉 Consulting {brain_type}...")
            # Route to specific brain by temporarily locking or forcing routing prompt
            # For V1, we simply prepend the persona instruction to the prompt
            persona_prompt = f"[SYSTEM: Act as {brain_type} for this task.] {input_text}"
            
            log_entry = self.brain.think_with_meta(persona_prompt)
            brain_outputs.append({
                "brain": brain_type,
                "output": log_entry.final_response,
                "confidence": log_entry.overall_confidence
            })
            
        # 2. Aggregation (Manager)
        print(Fore.MAGENTA + "   🔄 Synthesizing Consensus...")
        synthesis_prompt = "You are the MANAGER. Synthesize the following expert opinions into one final verified answer.\n\n"
        for i, out in enumerate(brain_outputs):
            synthesis_prompt += f"--- {out['brain']} said: ---\n{out['output']} (Conf: {out['confidence']})\n\n"
            
        synthesis_prompt += "Final Answer:"
        
        final_log = self.brain.think_with_meta(synthesis_prompt)
        
        # 3. Wrap Result
        final_result = MCPResult(
            task_id=task_id,
            output=final_log.final_response,
            overall_confidence=final_log.overall_confidence, # Manager's confidence in the synthesis
            meta_log={
                "type": "CONSENSUS",
                "contributors": brain_outputs,
                "steps": final_log.steps
            }
        )
        self.task_history[task_id] = final_result
        return final_result

if __name__ == "__main__":
    # Test stub
    mcp = MasterControlProgram()
    res = mcp.submit_task("What is the capital of France?")
    print(json.dumps(asdict(res), indent=2))
