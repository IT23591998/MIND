import cv2
import numpy as np
import pyautogui
import time
import threading
import os
import config
from colorama import Fore

# Optional: Telegram integration via telegram_agent
from modules.telegram_agent import TelegramAgent

class SocialAgent:
    def __init__(self):
        self.recording = False
        self.out_path = os.path.join(config.ASSETS_DIR, "devlog_clip.avi")

    def record_session(self, duration_sec=10):
        """Records screen for N seconds."""
        print(f"{Fore.MAGENTA}🎬 [SOCIAL] Recording Clip ({duration_sec}s)...")
        config.hud_queue.put("REC: DEVLOG START")
        
        # Screen resolution
        screen_size = pyautogui.size()
        fourcc = cv2.VideoWriter_fourcc(*"XVID")
        out = cv2.VideoWriter(self.out_path, fourcc, 20.0, (screen_size.width, screen_size.height))
        
        start_time = time.time()
        while (time.time() - start_time) < duration_sec:
            # Screenshot
            img = pyautogui.screenshot()
            # Convert to numpy
            frame = np.array(img)
            # Convert RGB to BGR
            frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            out.write(frame)
            
        out.release()
        print(f"{Fore.GREEN}✅ [SOCIAL] Clip Saved.")
        
        return "Recording complete."

    def post_to_telegram(self, caption="Check out this progress!"):
        """Simulates posting to Telegram."""
        if os.path.exists(self.out_path):
             print(f"{Fore.BLUE}📱 [SOCIAL] Uploading to Telegram: {caption}")
             # In real impl, we'd use telegram_bot.send_video(self.out_path)
             return "Devlog posted to Telegram."
        return "No video to post."
