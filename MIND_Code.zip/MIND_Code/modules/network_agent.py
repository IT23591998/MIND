import os
import subprocess
import re
from colorama import Fore
import config

class NetworkAgent:
    def scan_devices(self):
        """Scans local network using ARP (Windows)."""
        print(f"{Fore.CYAN}📡 [NET] Scanning Network (ARP)...")
        config.hud_queue.put("NET: SCANNING ARP TABLE")
        
        # Windows: arp -a
        try:
            output = subprocess.check_output("arp -a", shell=True).decode()
            
            # Simple parsing
            devices = []
            for line in output.splitlines():
                # Look for valid IPs (basic regex)
                if "dynamic" in line.lower():
                    parts = line.split()
                    if len(parts) >= 2:
                        ip = parts[0]
                        mac = parts[1]
                        devices.append(f"Device: {ip} | MAC: {mac}")
            
            report = "\n".join(devices)
            return report if report else "No dynamic devices found."
            
        except Exception as e:
            return f"Scan failed: {e}"

    def speed_test(self):
        """Runs speedtest-cli."""
        print(f"{Fore.CYAN}🚀 [NET] Running Speedtest...")
        config.hud_queue.put("NET: SPEEDTEST IN PROGRESS")
        config.speech_queue.put("Running network speed test. This takes a moment.")
        
        try:
            # We use the CLI tool we installed
            # 'speedtest-cli --simple' gives concise output
            out = subprocess.check_output("speedtest-cli --simple", shell=True).decode()
            return out
        except:
            return "Speedtest failed. Is 'speedtest-cli' installed?"
