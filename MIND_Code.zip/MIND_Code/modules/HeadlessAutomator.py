import os
import json
import time
import subprocess
from posthog import project_root
import pyautogui
import pyperclip
import config
from mind_brain import MindBrain
from modules.HybridTyper import HybridTyper

class HeadlessAndroid:
    """
    AI-driven end-to-end Android pipeline:
    1. Creates project structure
    2. Generates MainActivity.kt with AI
    3. Launches Android Studio if needed
    4. Performs headless build
    5. Auto-fixes compilation errors via AI
    """

    def __init__(self):
        self.hybrid = HybridTyper()
        self.config_file = os.path.join(config.BASE_PATH, "project_config.json")
        self.brain = MindBrain()

    # ------------------ Project Utilities ------------------
    def save_project_path(self, app_name):
        project_path = os.path.join(config.PROJECTS_ROOT, app_name.replace(" ", ""))
        try:
            with open(self.config_file, "w") as f:
                json.dump({"current_project_name": app_name, "current_project_path": project_path}, f)
        except:
            pass

    def find_android_studio(self):
        cfg_path = config.APP_LIBRARY.get("android studio")
        if cfg_path and os.path.exists(cfg_path):
            return cfg_path

        standard_paths = [
            r"C:\Program Files\Android\Android Studio\bin\studio64.exe",
            r"C:\Program Files\Android\Android Studio1\bin\studio64.exe",
            r"D:\Android Studio\bin\studio64.exe",
            r"E:\Android Studio\bin\studio64.exe"
        ]
        for p in standard_paths:
            if os.path.exists(p):
                print(f"[SYSTEM] Found Android Studio at: {p}")
                return p
        return None

    def create_project_structure(self, app_name):
        safe_name = app_name.replace(" ", "").lower()
        project_root = os.path.join(config.PROJECTS_ROOT, app_name.replace(" ", ""))

        # ✅ Place default folder creation here
        default_folders = [
            "app/src/main/java/com/example/<appname>",
            "app/src/main/res/layout",
            "app/src/main/res/values",
            "app/src/main/res/drawable",
            "app/src/androidTest/java/com/example/<appname>",
            "app/src/test/java/com/example/<appname>"
        ]

        for folder in default_folders:
            os.makedirs(os.path.join(project_root, folder.replace("<appname>", safe_name)), exist_ok=True)

        # ... your existing build.gradle creation ...
        gradle_content = """ ... """
        with open(os.path.join(project_root, "app", "build.gradle"), "w") as f:
            f.write(gradle_content)

        return project_root


    # ------------------ AI Code Generation ------------------
    def generate_main_activity(self, app_name):
        safe_name = app_name.replace(" ", "").lower()
        project_path = os.path.join(config.PROJECTS_ROOT, app_name.replace(" ", ""))
        package_name = f"com.example.{safe_name}"

        config.hud_queue.put("AI: CODING")
        config.speech_queue.put(f"Drafting code for {app_name}...")

        prompt = (
            f"Write Kotlin 'MainActivity.kt' for: {app_name}. Package: {package_name}.\n"
            "REQUIREMENTS: Use Jetpack Compose. Create a simple To-Do list UI.\n"
            "OUTPUT: Code only. Start with 'package com.example...'"
        )

        code = self.brain.think(prompt, system_role="Senior Android Developer")
        clean_code = code.replace("```kotlin", "").replace("```", "").strip()

        target_file = os.path.join(project_path, "app", "src", "main", "java", "com", "example", safe_name, "MainActivity.kt")
        self.hybrid.smart_type(target_file, clean_code, force_visual=False)
        config.speech_queue.put("Code written successfully.")

    # ------------------ Headless Build ------------------
    def ensure_local_properties(self, project_path):
        user_home = os.path.expanduser("~")
        sdk_path = os.path.join(user_home, "AppData", "Local", "Android", "Sdk")
        local_prop = os.path.join(project_path, "local.properties")
        if not os.path.exists(local_prop):
            sdk_escaped = sdk_path.replace("\\", "\\\\")
            with open(local_prop, "w") as f:
                f.write(f"sdk.dir={sdk_escaped}")

    def find_main_activity(self, project_path):
        for root, dirs, files in os.walk(project_path):
            if "MainActivity.kt" in files:
                return os.path.join(root, "MainActivity.kt")
        return None

    def run_build_cycle(self):
        name, path = self.load_project()
        if not path or not os.path.exists(path):
            config.speech_queue.put("I can't find the project folder. Create an app first.")
            return

        config.hud_queue.put("SYSTEM: COMPILING")
        config.speech_queue.put(f"Starting headless build for {name}...")

        self.ensure_local_properties(path)
        gradle_wrapper = os.path.join(path, "gradlew.bat")

        for attempt in range(1, 4):
            config.hud_queue.put(f"BUILD: ATTEMPT {attempt}/3")
            print(f"--- Running Build Attempt {attempt} ---")
            try:
                process = subprocess.run(
                    [gradle_wrapper, "assembleDebug"],
                    cwd=path,
                    capture_output=True,
                    text=True,
                    timeout=300
                )

                if process.returncode == 0:
                    config.hud_queue.put("BUILD: SUCCESS")
                    config.speech_queue.put(f"Build successful! {name} is ready.")
                    apk_dir = os.path.join(path, "app", "build", "outputs", "apk", "debug")
                    if os.path.exists(apk_dir):
                        os.startfile(apk_dir)
                    return
                else:
                    config.hud_queue.put("BUILD: FAILED")
                    error_log = process.stderr + "\n" + process.stdout
                    clean_errors = "\n".join([line for line in error_log.split('\n') if "error" in line.lower() or "exception" in line.lower() or "failed" in line.lower()][:20])
                    if not clean_errors:
                        clean_errors = error_log[-1000:]
                    config.speech_queue.put(f"Build failed. Fixing bugs. Attempt {attempt}...")
                    self.agentic_fix(name, path, clean_errors)
                    time.sleep(2)
            except Exception as e:
                print(f"Gradle Error: {e}")
                config.speech_queue.put("Gradle wrapper failed to run.")
                return
        config.speech_queue.put("I tried 3 times but couldn't fix the compilation errors. Please check the logs manually.")

    # ------------------ AI Bug Fix ------------------
    def agentic_fix(self, app_name, project_path, error_log):
        target_file = self.find_main_activity(project_path)
        if not target_file:
            print("Could not find MainActivity.kt to fix.")
            return
        try:
            with open(target_file, "r", encoding="utf-8") as f:
                current_code = f.read()
        except:
            current_code = "// File unreadable"

        prompt = (
            f"Fix this Android compilation error for app '{app_name}'.\n"
            f"ERROR LOG:\n{error_log}\n\n"
            f"CURRENT MainActivity.kt:\n{current_code[:4000]}...\n\n"
            "RULES:\n"
            "1. Output the COMPLETE corrected MainActivity.kt file.\n"
            "2. Fix imports.\n"
            "3. NO CHAT. CODE ONLY. Start with package declaration.\n"
        )
        try:
            code = self.brain.think(prompt, system_role="Android Debug Specialist")
            new_code = code.replace("```kotlin", "").replace("```", "").strip()
            if "package" not in new_code:
                print("AI generation failed to produce valid code.")
                return
            with open(target_file, "w", encoding="utf-8") as f:
                f.write(new_code)
            print(f"[AGENT] Applied fix to {os.path.basename(target_file)}")
        except Exception as e:
            print(f"[AGENT ERROR] {e}")

    # ------------------ Helper ------------------
    def load_project(self):
        try:
            with open(self.config_file, "r") as f:
                data = json.load(f)
                return data.get("current_project_name"), data.get("current_project_path")
        except:
            return None, None

    # ------------------ End-to-End Pipeline ------------------
    def create_and_build_app(self, app_name):
        # Step 1: Create Project
        config.hud_queue.put("WIZARD: GENERATING")
        config.speech_queue.put(f"Creating project {app_name}...")
        project_path = self.create_project_structure(app_name)
        self.save_project_path(app_name)

        # Step 2: Generate Code
        self.generate_main_activity(app_name)

        # Step 3: Launch Studio (optional)
        studio_path = self.find_android_studio()
        if studio_path:
            subprocess.Popen([studio_path, project_path])
        else:
            os.startfile(project_path)
            config.speech_queue.put("Android Studio not found. Project folder opened.")

        # Step 4: Headless Build + AI Fix
        self.run_build_cycle()
