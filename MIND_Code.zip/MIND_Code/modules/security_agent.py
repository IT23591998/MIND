import socket
import datetime
import threading
import json
import os
from colorama import Fore

# Conditional Imports for OSINT Tools
try:
    import whois
except ImportError:
    whois = None

try:
    import dns.resolver
except ImportError:
    dns = None

try:
    import requests
except ImportError:
    requests = None

try:
    from PIL import Image, ExifTags
except ImportError:
    Image = None

class SecurityAgent:
    """
    Handles Security Audits and Advanced OSINT Scanning.
    Capabilities: Port Scan, Whois, DNS, GeoIP, Exif, Social Recon.
    """
    
    def __init__(self):
        pass

    # ---------------------------------------------------------
    # 1. NETWORK & PORT SECURITY
    # ---------------------------------------------------------
    def run_port_scan(self, target_ip="127.0.0.1", ports=[21, 22, 80, 443, 3000, 8080]):
        """
        Scans specified ports on the target IP.
        """
        print(Fore.RED + f"🛡️  [SEC] Starting Port Scan on {target_ip}...")
        results = []
        
        for port in ports:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.5)
            result = sock.connect_ex((target_ip, port))
            if result == 0:
                print(Fore.RED + f"   ! OPEN PORT: {port}")
                results.append({"port": port, "state": "OPEN"})
            sock.close()
            
        return {
            "target": target_ip,
            "scan_time": str(datetime.datetime.now()),
            "open_ports": results,
            "total_scanned": len(ports)
        }

    # ---------------------------------------------------------
    # 2. DOMAIN RECON (WHOIS & DNS)
    # ---------------------------------------------------------
    def run_domain_recon(self, domain):
        """
        Performs Whois lookup and DNS record enumeration.
        """
        print(Fore.RED + f"🛡️  [SEC] Starting Domain Recon for: {domain}")
        data = {"domain": domain, "whois": None, "dns": {}}

        # WHOIS
        if whois:
            try:
                w = whois.whois(domain)
                data["whois"] = str(w)
                print(Fore.CYAN + "   > Whois data retrieved.")
            except Exception as e:
                data["whois"] = f"Error: {e}"
        else:
            data["whois"] = "Library 'python-whois' not installed."

        # DNS
        if dns:
            try:
                for record_type in ["A", "MX", "NS", "TXT"]:
                    try:
                        answers = dns.resolver.resolve(domain, record_type)
                        data["dns"][record_type] = [r.to_text() for r in answers]
                        print(Fore.CYAN + f"   > DNS {record_type}: {len(data['dns'][record_type])} records")
                    except Exception:
                        pass
            except Exception as e:
                data["dns"]["error"] = str(e)
        else:
            data["dns"] = "Library 'dnspython' not installed."

        return data

    # ---------------------------------------------------------
    # 3. GEO-LOCATION INTELLIGENCE
    # ---------------------------------------------------------
    def run_geoip(self, ip_address):
        """
        Locates an IP address using public APIs.
        """
        print(Fore.RED + f"🛡️  [SEC] Tracing IP: {ip_address}")
        if not requests:
            return {"error": "Library 'requests' not installed."}

        try:
            response = requests.get(f"http://ip-api.com/json/{ip_address}", timeout=5)
            if response.status_code == 200:
                geo = response.json()
                print(Fore.CYAN + f"   > Location: {geo.get('city')}, {geo.get('country')}")
                return geo
            return {"error": f"API Error: {response.status_code}"}
        except Exception as e:
            return {"error": str(e)}

    # ---------------------------------------------------------
    # 4. IMAGE FORENSICS (EXIF)
    # ---------------------------------------------------------
    def extract_metadata(self, image_path):
        """
        Extracts EXIF metadata from images (GPS, Camera Model).
        """
        print(Fore.RED + f"🛡️  [SEC] Analyzing Image: {os.path.basename(image_path)}")
        if not Image:
            return {"error": "Library 'Pillow' not installed."}

        meta_data = {}
        try:
            img = Image.open(image_path)
            exif_raw = img._getexif()
            
            if exif_raw:
                for tag, value in exif_raw.items():
                    tag_name = ExifTags.TAGS.get(tag, tag)
                    if tag_name in ["Make", "Model", "DateTimeOriginal", "GPSInfo"]:
                        meta_data[tag_name] = str(value)
                print(Fore.CYAN + f"   > Extracted {len(meta_data)} tags.")
            else:
                print(Fore.YELLOW + "   > No EXIF data found.")
                
            return meta_data
        except Exception as e:
            return {"error": str(e)}

    # ---------------------------------------------------------
    # 5. ARGUS SOCIAL RECON (Username Manhunt)
    # ---------------------------------------------------------
    def run_argus_scan(self, username):
        """
        Argus-Style Social Media Manhunt.
        Scans platform list from modules/data/argus_sites.json.
        """
        print(Fore.RED + f"🛡️  [SEC] ARGUS PROTOCOL INITIATED: Hunting '{username}'...")
        if not requests: return {"error": "Requests lib missing"}
        
        from concurrent.futures import ThreadPoolExecutor
        
        # Load sites from JSON
        sites_file = os.path.join(os.path.dirname(__file__), 'data', 'argus_sites.json')
        platforms = {}
        
        if os.path.exists(sites_file):
            try:
                with open(sites_file, 'r') as f:
                    data = json.load(f)
                    raw_sites = data.get("sites", {})
                    # Format URLs with username
                    for site, url_tmpl in raw_sites.items():
                        platforms[site] = url_tmpl.format(username)
                print(Fore.CYAN + f"   > Loaded {len(platforms)} platforms from database.")
            except Exception as e:
                print(Fore.RED + f"   > Error loading sites DB: {e}")
        else:
            print(Fore.YELLOW + "   > Database not found. Using fallback list.")
            # Fallback list (small)
            platforms = {
                "GitHub": f"https://github.com/{username}",
                "Twitter": f"https://twitter.com/{username}",
                "Instagram": f"https://www.instagram.com/{username}/"
            }

        found_profiles = {}
        
        def check_url(item):
            site, url = item
            try:
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
                r = requests.get(url, headers=headers, timeout=5)
                if r.status_code == 200:
                    # Basic False Positive check
                    if "not found" not in r.text.lower():
                        return (site, url)
            except:
                pass
            return None

        # Parallel Scanning (Higher workers for larger list)
        with ThreadPoolExecutor(max_workers=20) as executor:
            results = executor.map(check_url, platforms.items())
            
        for res in results:
            if res:
                site, url = res
                print(Fore.CYAN + f"   > [FOUND] {site}: {url}")
                found_profiles[site] = url
        
        print(Fore.GREEN + f"   > Argus Scan Complete. Found {len(found_profiles)} profiles.")
        return found_profiles

    # Legacy wrapper
    def check_username(self, username):
        return self.run_argus_scan(username)

    # ---------------------------------------------------------
    # 6. WEB SECURITY (SSL & HEADERS)
    # ---------------------------------------------------------
    def run_ssl_check(self, domain):
        """
        Retrieves SSL Certificate details.
        """
        print(Fore.RED + f"🛡️  [SEC] Checking SSL: {domain}")
        import ssl
        
        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((domain, 443)) as sock:
                with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                    cert = ssock.getpeercert()
                    
            subject = dict(x[0] for x in cert['subject'])
            issuer = dict(x[0] for x in cert['issuer'])
            
            info = {
                "issued_to": subject.get('commonName'),
                "issued_by": issuer.get('commonName'),
                "valid_till": cert['notAfter'],
                "version": cert['version']
            }
            print(Fore.CYAN + f"   > Verified: Issued by {info['issued_by']}")
            return info
        except Exception as e:
            return {"error": str(e)}

    def analyze_headers(self, domain):
        """
        Analyzes HTTP headers for security best practices.
        """
        domain = domain if domain.startswith("http") else f"https://{domain}"
        print(Fore.RED + f"🛡️  [SEC] Analyzing Headers: {domain}")
        
        if not requests:
            return {"error": "Requests lib missing"}

        try:
            r = requests.get(domain, timeout=5)
            headers = r.headers
            
            security_headers = [
                "Strict-Transport-Security",
                "Content-Security-Policy",
                "X-Frame-Options",
                "X-Content-Type-Options",
                "Referrer-Policy"
            ]
            
            report = {"score": 0, "missing": [], "present": {}}
            
            for h in security_headers:
                if h in headers:
                    report["score"] += 1
                    report["present"][h] = headers[h]
                else:
                    report["missing"].append(h)
            
            print(Fore.CYAN + f"   > Security Score: {report['score']}/5")
            return report
        except Exception as e:
            return {"error": str(e)}

    # ---------------------------------------------------------
    # 7. SEARCH INTELLIGENCE (DORKS)
    # ---------------------------------------------------------
    def generate_dorks(self, domain):
        """
        Generates Google Dorks for recon.
        """
        print(Fore.RED + f"🛡️  [SEC] Generating Dorks for: {domain}")
        dorks = [
            f"site:{domain} filetype:pdf",
            f"site:{domain} filetype:xlsx",
            f"site:{domain} inurl:admin",
            f"site:{domain} intitle:\"index of\"",
            f"site:{domain} intext:\"password\" filetype:log",
            f"site:{domain} \"confidential\""
        ]
        return dorks

    # ---------------------------------------------------------
    # 8. HARDWARE RECON (MAC VENDOR)
    # ---------------------------------------------------------
    def lookup_mac(self, mac_address):
        """
        Identifies device manufacturer via MAC address.
        """
        print(Fore.RED + f"🛡️  [SEC] Looking up MAC: {mac_address}")
        if not requests: return {"error": "Requests lib missing"}
        
        try:
            url = f"https://api.macvendors.com/{mac_address}"
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                vendor = r.text
                print(Fore.CYAN + f"   > Vendor: {vendor}")
                return {"mac": mac_address, "vendor": vendor}
            else:
                return {"error": "Vendor not found"}
        except Exception as e:
            return {"error": str(e)}

    # ---------------------------------------------------------
    # 9. INFRASTRUCTURE RECON (SUBDOMAINS & TECH)
    # ---------------------------------------------------------
    def find_subdomains(self, domain):
        """
        Finds subdomains using Certificate Transparency logs (crt.sh).
        """
        print(Fore.RED + f"🛡️  [SEC] Hunting Subdomains for: {domain}")
        if not requests: return {"error": "Requests lib missing"}
        
        try:
            url = f"https://crt.sh/?q=%.{domain}&output=json"
            r = requests.get(url, timeout=10)
            if r.status_code == 200:
                data = r.json()
                subdomains = set()
                for entry in data:
                    name_value = entry.get('name_value')
                    if name_value:
                        for sub in name_value.split('\n'):
                            if domain in sub:
                                subdomains.add(sub)
                
                print(Fore.CYAN + f"   > Found {len(subdomains)} subdomains.")
                return sorted(list(subdomains))
            return []
        except Exception as e:
            return {"error": str(e)}

    def detect_tech_stack(self, domain):
        """
        Identifies server technologies from headers and HTML.
        """
        domain = domain if domain.startswith("http") else f"https://{domain}"
        print(Fore.RED + f"🛡️  [SEC] Fingerprinting Tech Stack: {domain}")
        
        stack = {"server": "Unknown", "powered_by": "Unknown", "clues": []}
        if not requests: return {"error": "Requests lib missing"}

        try:
            r = requests.get(domain, timeout=5)
            headers = r.headers
            
            # Header Analysis
            if 'Server' in headers:
                stack['server'] = headers['Server']
            if 'X-Powered-By' in headers:
                stack['powered_by'] = headers['X-Powered-By']
            
            # Simple HTML clues
            html = r.text.lower()
            if 'wp-content' in html: stack['clues'].append("WordPress")
            if 'react' in html: stack['clues'].append("React")
            if 'vue' in html: stack['clues'].append("Vue.js")
            if 'bootstrap' in html: stack['clues'].append("Bootstrap")
            if 'shopify' in html: stack['clues'].append("Shopify")
            
            print(Fore.CYAN + f"   > Server: {stack['server']}")
            return stack
        except Exception as e:
            return {"error": str(e)}

    # ---------------------------------------------------------
    # 10. CONTENT RECON (ROBOTS & PDF)
    # ---------------------------------------------------------
    def analyze_robots_txt(self, domain):
        """
        Parses robots.txt for disallowed paths.
        """
        domain = domain if domain.startswith("http") else f"https://{domain}"
        url = f"{domain}/robots.txt"
        print(Fore.RED + f"🛡️  [SEC] Reading Robots.txt: {url}")
        
        if not requests: return {"error": "Requests lib missing"}

        try:
            r = requests.get(url, timeout=5)
            if r.status_code == 200:
                lines = r.text.split('\n')
                disallowed = [l.split(': ')[1].strip() for l in lines if l.lower().startswith('disallow:')]
                print(Fore.CYAN + f"   > Found {len(disallowed)} disallowed paths.")
                return disallowed[:10] # Return top 10
            return {"error": "No robots.txt found"}
        except Exception as e:
            return {"error": str(e)}
            
    def analyze_pdf_metadata(self, pdf_url):
        """
        Downloads a PDF and extracts metadata (Author, Creator).
        """
        print(Fore.RED + f"🛡️  [SEC] Analyzing PDF Metadata: {pdf_url}")
        if not requests: return {"error": "Requests lib missing"}
        
        # Dynamic import for pypdf
        try:
            from pypdf import PdfReader
            from io import BytesIO
        except ImportError:
            return {"error": "Library 'pypdf' not installed."}

        try:
            r = requests.get(pdf_url, timeout=10)
            f = BytesIO(r.content)
            reader = PdfReader(f)
            meta = reader.metadata
            if meta:
                print(Fore.CYAN + f"   > Author: {meta.get('/Author', 'Unknown')}")
                return {k:v for k,v in meta.items()}
            return {"status": "No metadata"}
        except Exception as e:
            return {"error": str(e)}
