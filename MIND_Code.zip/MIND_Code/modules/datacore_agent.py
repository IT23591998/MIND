import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import os
import json
import uuid
import uuid
from colorama import Fore
import config
import config

# Ensure assets directory exists for visuals
VIZ_DIR = os.path.join(config.ASSETS_DIR, "datacore_viz")
os.makedirs(VIZ_DIR, exist_ok=True)

class DataCoreAgent:
    def __init__(self):
        self.viz_dir = VIZ_DIR
        self.index_path = os.path.join(self.viz_dir, "data_index.json")
        self.matter_db_path = os.path.join(config.ASSETS_DIR, "matter_db.json")
        self.file_index = []
        self.matter_db = []
        self._load_index()
        self._load_matter_db()
        print(f"{Fore.CYAN} [DATACORE] Initialized. Ready for analysis.")

    def _load_matter_db(self):
        if os.path.exists(self.matter_db_path):
            try:
                with open(self.matter_db_path, "r") as f:
                    self.matter_db = json.load(f)
            except: 
                self.matter_db = []

    def _load_index(self):
        if os.path.exists(self.index_path):
            try:
                with open(self.index_path, "r") as f:
                    self.file_index = json.load(f)
            except: 
                self.file_index = []

    def _auto_clean(self, df):
        """
        Self-Healing Data Wrangler:
        1. Drops duplicates
        2. Fills numeric NaNs with mean
        3. Fills categorical NaNs with mode
        """
        initial_rows = len(df)
        df = df.drop_duplicates()
        
        # Numeric cleanup
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            df[col] = df[col].fillna(df[col].mean())

        # Categorical cleanup
        cat_cols = df.select_dtypes(include=['object', 'category']).columns
        for col in cat_cols:
            if not df[col].mode().empty:
                df[col] = df[col].fillna(df[col].mode()[0])
            else:
                df[col] = df[col].fillna("Unknown")
                
        cleaned_rows = len(df)
        print(f"{Fore.CYAN} [DATACORE] Data healed. Rows preserved: {cleaned_rows}/{initial_rows}")
        return df

    def _generate_viz(self, df):
        """
        Visual Intelligence:
        Generates a pairplot or correlation heatmap automatically.
        """
        try:
            plt.figure(figsize=(10, 8))
            numeric_df = df.select_dtypes(include=[np.number])
            
            if not numeric_df.empty:
                # Correlation Heatmap
                sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm')
                filename = f"viz_corr_{uuid.uuid4().hex[:8]}.png"
                filepath = os.path.join(self.viz_dir, filename)
                plt.title("Automated Correlation Analysis")
                plt.savefig(filepath)
                plt.close()
                return filepath
            else:
                return None
        except Exception as e:
            print(f"[DATACORE VIZ ERROR] {e}")
            return None

    def analyze_diagnostic(self, data_source):
        """
        Analyst Mode: 'What Happened?'
        Loads data, cleans it, and provides summary stats + visualization.
        """
        try:
            # Detect Load Method
            if data_source.endswith(".csv"):
                df = pd.read_csv(data_source)
            elif data_source.endswith(".json"):
                df = pd.read_json(data_source)
            elif data_source.endswith(".xlsx"):
                df = pd.read_excel(data_source)
            else:
                # Assume raw text csv from clipboard if passing simple string
                from io import StringIO
                df = pd.read_csv(StringIO(data_source))

            df = self._auto_clean(df)
            
            summary = df.describe().to_string()
            viz_path = self._generate_viz(df)
            
            report = f"""
            📊 [DATACORE DIAGNOSTIC REPORT]
            -------------------------------
            DataSource: {data_source}
            Rows: {len(df)}
            Columns: {list(df.columns)}
            
            Stats Summary:
            {summary}
            
            Visualization Exported: {viz_path}
            """
            config.speech_queue.put("Diagnostic analysis complete. Visualizations generated.")
            print(report)
            return report

        except Exception as e:
            err = f"Diagnostic failed: {str(e)}"
            print(Fore.RED + err)
            return err

    def analyze_predictive(self, data_source, target_col):
        """
        Scientist Mode: 'What Will Happen?'
        AutoML logic to train a simplified model.
        """
        try:
            # 1. Load & Clean
            if not os.path.exists(data_source):
                return "File not found."

            if data_source.endswith(".xlsx"):
                df = pd.read_excel(data_source)
            elif data_source.endswith(".json"):
                 df = pd.read_json(data_source)
            else:
                df = pd.read_csv(data_source)

            df = self._auto_clean(df)
            
            if target_col not in df.columns:
                return f"Target column '{target_col}' not found."

            # Lazy Import Pattern to prevent crashes if sklearn is missing
            from sklearn.model_selection import train_test_split
            from sklearn.linear_model import LinearRegression, LogisticRegression
            from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
            from sklearn.metrics import mean_squared_error, accuracy_score

            # 2. Preprocessing
            # Simple encoding for categoricals
            df = pd.get_dummies(df, drop_first=True)
            
            X = df.drop(columns=[target_col])
            y = df[target_col]
            
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # 3. Model Selection (Heuristic)
            is_classification = False
            if y.nunique() < 10 or y.dtype == 'object':
                is_classification = True
                
            model = None
            model_type = ""
            metric = ""
            
            if is_classification:
                model = RandomForestClassifier()
                model_type = "RandomForest Classifier"
                model.fit(X_train, y_train)
                preds = model.predict(X_test)
                score = accuracy_score(y_test, preds)
                metric = f"Accuracy: {score:.2%}"
            else:
                model = RandomForestRegressor()
                model_type = "RandomForest Regressor"
                model.fit(X_train, y_train)
                preds = model.predict(X_test)
                score = mean_squared_error(y_test, preds, squared=False) # RMSE
                metric = f"RMSE: {score:.4f}"

            result = f"""
            🔮 [DATACORE PREDICTIVE ENGINE]
            -------------------------------
            Target: {target_col}
            Model Selected: {model_type}
            Training Set: {len(X_train)} rows
            
            Performance:
            {metric}
            """
            config.speech_queue.put(f"Predictive model trained. {metric}")
            print(result)
            return result

        except Exception as e:
            err = f"Predictive analysis failed: {str(e)}"
            print(Fore.RED + err)
            return err

    def scan_system_drives(self):
        """
        Storage Intelligence:
        Scans all available logical drives (C:, D:, E:, etc.) for data assets.
        """
        import string
        from ctypes import windll
        
        print(f"{Fore.CYAN} [DATACORE] Initiating System-Wide Storage Scan...")
        config.speech_queue.put("Scanning all connected drives for data sources.")
        
        available_drives = []
        bitmask = windll.kernel32.GetLogicalDrives()
        for letter in string.ascii_uppercase:
            if bitmask & 1:
                available_drives.append(f"{letter}:/")
            bitmask >>= 1
            
        print(f"{Fore.CYAN} [DATACORE] Detect Drives: {available_drives}")
        
        print(f"{Fore.CYAN} [DATACORE] Detect Drives: {available_drives}")
        
        data_assets = []
        # UPDATED: Added document extensions
        extensions = {'.csv', '.xlsx', '.json', '.sql', '.parquet', '.pdf', '.docx', '.pptx', '.txt', '.md'}
        skip_dirs = {'Windows', 'Program Files', 'Program Files (x86)', 'AppData', '$Recycle.Bin', 'System Volume Information'}
        
        for drive in available_drives:
            print(f"{Fore.CYAN} [DATACORE] Indexing {drive}...")
            # We use os.walk but limit depth/scope to avoid hanging on massive drives for this demo
            # strict=False allows continuing on permission errors
            try:
                for root, dirs, files in os.walk(drive, topdown=True):
                    # In-place filtering of dirs to skip system folders
                    dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith('.')]
                    
                    for file in files:
                        _, ext = os.path.splitext(file)
                        if ext.lower() in extensions:
                            full_path = os.path.join(root, file)
                            data_assets.append(full_path)
                            
                            # Limit for demo purposes to avoid million-file lists
                            if len(data_assets) > 100: 
                                break # Stop scanning this drive if we found plenty
                    if len(data_assets) > 100: break
            except Exception as e:
                print(f"[WARN] Access denied on {drive}: {e}")
                
        # Save manifest
        with open(self.index_path, "w") as f:
            json.dump(data_assets, f, indent=4)
        
        # Update memory
        self.file_index = data_assets
            
        summary = f"""
        💾 [STORAGE INTELLIGENCE REPORT]
        ------------------------------
        Drives Scanned: {available_drives}
        Assets Found: {len(data_assets)}
        Index Location: {self.index_path}
        
        Sample Findings:
        {data_assets[:5]}...
        """
        print(summary)
        config.speech_queue.put(f"Scan complete. Found {len(data_assets)} files.")
        return summary

    def search_file(self, query):
        """
        Fuzzy File Search
        Finds the best matching file path for a natural language query.
        """
        if not self.file_index:
            self._load_index()
            if not self.file_index:
                return None

        query_tokens = query.lower().split()
        best_match = None
        best_score = 0
        
        for filepath in self.file_index:
            filename = os.path.basename(filepath).lower()
            
            # Simple scoring: count how many query tokens exist in filename
            score = 0
            for token in query_tokens:
                if token in filename:
                    score += 1
            
            # Bonus for contiguous match
            if query.lower() in filename:
                score += 2
                
            if score > best_score:
                best_score = score
                best_match = filepath
        
        # Threshold (must match at least something)
        if best_score > 0:
            print(f"{Fore.CYAN} [DATACORE] Found File (Cache): {best_match} (Score: {best_score})")
            return best_match
        
        # Fallback: Live Search
        print(f"{Fore.YELLOW} [DATACORE] File not in cache. Initiating Live Search for '{query}'...")
        return self._live_search(query)

    def _live_search(self, query):
        """
        Real-time Drive Walking for immediate file finding.
        """
        import string
        from ctypes import windll
        
        config.speech_queue.put("Searching your computer for that file...")
        
        available_drives = []
        bitmask = windll.kernel32.GetLogicalDrives()
        for letter in string.ascii_uppercase:
            if bitmask & 1:
                available_drives.append(f"{letter}:/")
            bitmask >>= 1
            
        extensions = {'.csv', '.xlsx', '.json', '.sql', '.parquet', '.pdf', '.docx', '.pptx', '.txt', '.md'}
        query_tokens = query.lower().split()
        skip_dirs = {'Windows', 'Program Files', 'Program Files (x86)', 'AppData', '$Recycle.Bin', 'System Volume Information'}

        for drive in available_drives:
            try:
                for root, dirs, files in os.walk(drive, topdown=True):
                    dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith('.')]
                    
                    for file in files:
                        fname_lower = file.lower()
                        # Strict Match Check: All tokens must be present for a live search hit? 
                        # Or at least most? Let's be lenient but require significant overlap.
                        
                        match_count = 0
                        for token in query_tokens:
                            if token in fname_lower:
                                match_count += 1
                        
                        # Heuristic: If we matched most of the words or it's a direct substring
                        # Strictness increased to 0.9 to avoid false positives during full scan
                        if match_count >= len(query_tokens) * 0.9 or query.lower() in fname_lower:
                            # It's a hit!
                            full_path = os.path.join(root, file)
                            print(f"{Fore.GREEN} [DATACORE] Live Search Found: {full_path}")
                            
                            # Cache it!
                            self.file_index.append(full_path)
                            with open(self.index_path, "w") as f:
                                json.dump(self.file_index, f, indent=4)
                                
                            return full_path
                            
            except Exception:
                continue
                
        config.speech_queue.put("I couldn't find that file anywhere on your computer.")
        return None

    def get_element_info(self, query):
        """
        Scientific Database Lookup. Supports Isotopes (e.g. "Carbon-14").
        """
        query_str = str(query).lower().strip()
        
        # 1. Isotope Detection Logic
        target_mass = None
        target_name = None
        
        # Check for "Carbon-14" format
        if "-" in query_str:
            parts = query_str.split("-")
            # Usually [Name, Mass] or [Symbol, Mass]
            if len(parts) == 2 and parts[1].isdigit():
                target_name = parts[0]
                target_mass = int(parts[1])
        
        # Check for named isotopes (Deuterium, Tritium)
        named_isotopes = {
            "protium": ("hydrogen", 1),
            "deuterium": ("hydrogen", 2),
            "tritium": ("hydrogen", 3)
        }
        if query_str in named_isotopes:
            target_name, target_mass = named_isotopes[query_str]

        # 2. Search Database
        for el in self.matter_db:
             match = (el['name'].lower() == (target_name or query_str)) or \
                     (el['symbol'].lower() == (target_name or query_str)) or \
                     (str(el['atomic_number']) == query_str)
                     
             if match:
                 # Sub-search for Isotope if mass specified
                 if target_mass and "isotopes" in el:
                     for iso in el["isotopes"]:
                         if iso["mass_number"] == target_mass:
                             iso_info = f"""
                 ⚛️ [ISOTOPE DATA] {iso['name']}
                 ---------------------------------------
                 Parent Element : {el['name']} ({el['symbol']})
                 Atomic Mass    : {iso['mass']} u
                 Abundance      : {iso['abundance']}
                 Stability      : {'Stable' if iso['stable'] else 'Radioactive'}
                 Half-Life      : {iso.get('half_life', 'N/A')}
                             """
                             print(Fore.CYAN + iso_info)
                             config.speech_queue.put(f"Found Isotope {iso['name']}. {iso.get('half_life', 'It is stable')}.")
                             return iso_info
                 
                 # FALLBACK: If Isotope not in DB, Simulate it!
                 if target_mass:
                      return self._simulate_isotope(el, target_mass)
                             
                 # Standard Element Info + Isotope List
                 iso_list = ", ".join([iso['name'] for iso in el.get("isotopes", [])])
                 
                 info = f"""
                 ⚛️ [MATTER DATABASE] Element Found: {el['name']} ({el['symbol']})
                 ---------------------------------------
                 Atomic Number : {el['atomic_number']}
                 Atomic Weight : {el['atomic_weight']} u
                 Phase (STP)   : {el['phase']}
                 Melting Point : {el['melting_point_k']} K
                 Known Isotopes: {iso_list if iso_list else "Standard Only"}
                 """
                 print(Fore.CYAN + info)
                 config.speech_queue.put(f"{el['name']}. atomic weight {el['atomic_weight']}.")
                 return info
        
        config.speech_queue.put("Element or Isotope not found in Matter Database.")
        return "Element not found."

    def synthesize_element(self, name, symbol, number, weight, phase="Solid"):
        """
        Tony Stark Protocol: Create New Element.
        """
        # Validate uniqueness
        for el in self.matter_db:
            if str(el['atomic_number']) == str(number):
                return f"Atomic Number {number} is already occupied by {el['name']}."
            if el['name'].lower() == name.lower():
                return f"Element {name} already exists."
                
        new_element = {
            "atomic_number": int(number),
            "symbol": symbol,
            "name": name,
            "atomic_weight": float(weight),
            "phase": phase,
            "melting_point_k": "Theoretical"
        }
        
        self.matter_db.append(new_element)
        
        # Persist
        try:
            with open(self.matter_db_path, "w") as f:
                json.dump(self.matter_db, f, indent=4)
                
            msg = f"🧪 [SYNTHESIS COMPLETE] New Element Created: {name} ({symbol}-{number})."
            print(Fore.GREEN + msg)
            config.speech_queue.put(f"Synthesis successful. Element {name} has been added to the periodic table.")
            return msg
        except Exception as e:
            return f"Synthesis Failed: {e}"

    def _simulate_isotope(self, element, mass_number):
        """
        Nuclear Physics Engine: Calculates stability based on N/Z ratio.
        """
        protons = element['atomic_number']
        neutrons = mass_number - protons
        ratio = neutrons / protons if protons > 0 else 0
        
        # Simple Stability Band Approximation
        # Light elements (Z<20) stable ~ 1.0
        # Heavy elements (Z>80) stable ~ 1.5
        ideal_ratio = 1.0 + (protons / 100.0) * 0.5
        deviation = abs(ratio - ideal_ratio)
        
        status = "Unknown"
        if deviation < 0.1:
            status = "Theoretically Stable"
        elif deviation < 0.2:
            status = "Radioactive (Long Half-Life)"
        else:
            status = "Highly Unstable (Short Half-Life)"
            
        sim_info = f"""
        ⚠️ [PHYSICS SIMULATION] {element['name']}-{mass_number}
        ---------------------------------------
        Protons (Z)    : {protons}
        Neutrons (N)   : {neutrons}
        N/Z Ratio      : {ratio:.2f} (Ideal: {ideal_ratio:.2f})
        Stability      : {status}
        Note           : Data derived mathematically.
        """
        print(Fore.YELLOW + sim_info)
        config.speech_queue.put(f"Calculated data for {element['name']}-{mass_number}. It appears {status}.")
        return sim_info

    def calculate_bonding(self, el1_ident, el2_ident):
        """
        Predicts chemical interaction between two elements.
        """
        # Helper to find element obj
        def _find(ident):
             ident = str(ident).lower()
             for el in self.matter_db:
                 if el['name'].lower() == ident or el['symbol'].lower() == ident:
                     return el
             return None

        e1 = _find(el1_ident)
        e2 = _find(el2_ident)
        
        if not e1 or not e2:
            msg = f"Could not find one or both elements: {el1_ident}, {el2_ident}"
            print(Fore.RED + msg)
            config.speech_queue.put("I couldn't find those elements in my database.")
            return msg

        # Check for data
        if "electronegativity" not in e1 or "electronegativity" not in e2:
             msg = f"Missing electronegativity data for simulation. Please update database."
             config.speech_queue.put("I lack the electronegativity data for those elements.")
             return msg

        # 1. Electronegativity Difference
        en1 = e1['electronegativity']
        en2 = e2['electronegativity']
        delta_en = abs(en1 - en2)
        
        bond_type = "Unknown"
        if delta_en > 1.7:
            bond_type = "Ionic Bond (Transfer of electrons)"
        elif delta_en > 0.4:
            bond_type = "Polar Covalent Bond (Unequal sharing)"
        else:
            bond_type = "Non-Polar Covalent Bond (Equal sharing)"
            
        # 2. Formula Prediction (Basic Cross-Over)
        # Assume E1 is Metal/Cation if EN1 < EN2, else Anion
        cation = e1 if en1 < en2 else e2
        anion = e2 if en1 < en2 else e1
        
        # Get likely states
        cat_val = max(cation.get('oxidation_states', [0])) # Take max positive
        an_val = min(anion.get('oxidation_states', [0]))   # Take max negative (min value)
        
        formula = "?"
        if cat_val > 0 and an_val < 0:
            # Cross over: Cation(+X) Anion(-Y) -> Cation_Y Anion_X
            # Simplified: just absolute values
            num_cat = abs(an_val)
            num_an = abs(cat_val)
            
            # Reduce ratio (e.g. 2:2 -> 1:1)
            import math
            gcd = math.gcd(int(num_cat), int(num_an))
            num_cat //= gcd
            num_an //= gcd
            
            cat_sub = str(num_cat) if num_cat > 1 else ""
            an_sub = str(num_an) if num_an > 1 else ""
            formula = f"{cation['symbol']}{cat_sub}{anion['symbol']}{an_sub}"

        report = f"""
        ⚗️ [REACTION PREDICTION] {e1['name']} + {e2['name']}
        ---------------------------------------
        Electronegativity : {e1['symbol']}({en1}) vs {e2['symbol']}({en2})
        Delta EN          : {delta_en:.2f}
        Bond Type         : {bond_type}
        Predicted Formula : {formula}
        """
        print(Fore.GREEN + report)
        config.speech_queue.put(f"Reaction analysis complete. They form a {bond_type}. Likely formula is {formula}.")
        return report

