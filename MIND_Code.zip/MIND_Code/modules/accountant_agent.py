import os
import csv
import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from colorama import Fore

class AccountantAgent:
    def __init__(self):
        self.ledger_file = "D:/MIND_Project/finance_ledger.csv"
        self._ensure_ledger()

    def _ensure_ledger(self):
        """Creates the ledger file with headers if it doesn't exist."""
        if not os.path.exists(self.ledger_file):
            with open(self.ledger_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(["Date", "Type", "Amount", "Category", "Description"])

    def log_transaction(self, t_type, amount, category, description):
        """Logs a transaction (Income/Expense)."""
        try:
            date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            with open(self.ledger_file, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([date_str, t_type, amount, category, description])
            return f"Logged {t_type}: {amount} for {description}."
        except Exception as e:
            return f"Error logging transaction: {e}"

    def get_balance(self):
        """Calculates current balance."""
        total_income = 0.0
        total_expense = 0.0
        
        if not os.path.exists(self.ledger_file):
            return "Ledger empty."

        try:
            with open(self.ledger_file, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    try:
                        amt = float(row['Amount'])
                        if row['Type'].lower() == 'income':
                            total_income += amt
                        else:
                            total_expense += amt
                    except ValueError:
                        continue
            
            balance = total_income - total_expense
            return f"Your balance is {balance:.2f}. (Income: {total_income}, Expenses: {total_expense})"
        except Exception as e:
            return f"Error calculating balance: {e}"

    def generate_monthly_report(self):
        """Summarizes this month's activity."""
        current_month = datetime.datetime.now().strftime("%Y-%m")
        categories = {}
        total_spent = 0.0
        
        try:
            with open(self.ledger_file, 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row['Date'].startswith(current_month) and row['Type'].lower() == 'expense':
                        try:
                            amt = float(row['Amount'])
                            cat = row['Category']
                            categories[cat] = categories.get(cat, 0) + amt
                            total_spent += amt
                        except: continue
            
            if not categories:
                return f"No expenses recorded for {current_month}."
                
            report = f"Spending Report for {current_month}:\n"
            for cat, amt in categories.items():
                report += f"- {cat}: {amt:.2f}\n"
            report += f"Total Spent: {total_spent:.2f}"
            return report
            
        except Exception as e:
            return f"Error generating report: {e}"

    def sync_to_sheets(self, sheet_name="MIND Finances"):
        """Syncs the local ledger to a Google Sheet."""
        # Check for credentials
        creds_file = "D:/MIND_Project/credentials.json"
        if not os.path.exists(creds_file):
            return "Creation failed. Please place 'credentials.json' in the project root."

        try:
            scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
            creds = ServiceAccountCredentials.from_json_keyfile_name(creds_file, scope)
            client = gspread.authorize(creds)
            
            # Open Sheet
            try:
                sheet = client.open(sheet_name).sheet1
            except gspread.SpreadsheetNotFound:
                # Try to create it? (Requires Drive API write access usually)
                return f"Could not find sheet '{sheet_name}'. Please create it and share with the bot email."

            # Read CSV
            with open(self.ledger_file, 'r') as f:
                reader = csv.reader(f)
                data = list(reader)
            
            # Clear and Update
            sheet.clear()
            sheet.update(data)
            
            return f"Successfully synced {len(data)} rows to Google Sheet '{sheet_name}'."
            
        except Exception as e:
            return f"Sync failed: {e}"

