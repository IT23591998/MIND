import os
import subprocess
import requests
import pyperclip
from colorama import Fore
import config

class DownloaderAgent:
    def __init__(self):
        # Default download path
        self.download_path = "D:/Downloads_MIND"
        if not os.path.exists(self.download_path):
            os.makedirs(self.download_path)

    def download(self, identifier):
        """
        Smart download function.
        identifier: "clipboard", "this", or a specific URL string (rarely used via voice).
        """
        target_url = identifier
        
        # 1. Resolve URL from Clipboard if requested
        if identifier.lower() in ["clipboard", "this", "here", "link"]:
            print(f"{Fore.CYAN}📥 [DOWNLOADER] Reading Clipboard...")
            target_url = pyperclip.paste().strip()
            
            if not target_url.startswith("http"):
                config.speech_queue.put("Clipboard does not contain a valid link.")
                return

        print(f"{Fore.CYAN}📥 [DOWNLOADER] Target: {target_url}")
        config.speech_queue.put("Starting download.")

        # 2. Determine Type (Git vs File)
        try:
            if "github.com" in target_url or target_url.endswith(".git"):
                self._download_git(target_url)
            else:
                self._download_file(target_url)
                
        except Exception as e:
            print(f"{Fore.RED}❌ [ERROR] Download failed: {e}")
            config.speech_queue.put("Download failed.")

    def _download_git(self, url):
        """Handles Git Repositories."""
        repo_name = url.split("/")[-1].replace(".git", "")
        final_path = os.path.join(self.download_path, repo_name)
        
        if os.path.exists(final_path):
            print(f"{Fore.YELLOW}⚠️ [WARN] Repo exists. Pulling changes instead...")
            subprocess.run(["git", "pull"], cwd=final_path, shell=True)
            config.speech_queue.put(f"Updated repository {repo_name}.")
        else:
            print(f"{Fore.GREEN}Cloning {repo_name}...")
            subprocess.run(["git", "clone", url, final_path], shell=True)
            config.speech_queue.put(f"Cloned repository {repo_name} successfully.")
            
        # Open folder
        os.startfile(final_path)

    def _download_file(self, url):
        """Handles regular file downloads."""
        filename = url.split("/")[-1]
        # Fallback if filename is empty or query params mess it up
        if not filename or "?" in filename:
            filename = "downloaded_file_" + str(int(subprocess.time.time()))
            
        final_path = os.path.join(self.download_path, filename)
        
        print(f"{Fore.GREEN}Downloading {filename}...")
        
        # Streaming download
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(final_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192): 
                    f.write(chunk)
                    
        config.speech_queue.put(f"Download complete: {filename}")
        print(f"{Fore.GREEN}✅ Saved to {final_path}")
        
        # Open folder logic
        # We don't execute the file for security, just show it.
        win_path = final_path.replace("/", "\\")
        subprocess.run(f'explorer /select,"{win_path}"', shell=True)
