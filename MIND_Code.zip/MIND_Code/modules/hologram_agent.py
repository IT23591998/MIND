import os
import sys
import subprocess
import time
from colorama import Fore
import config

# Try importing open3d, handle missing dependency
try:
    import open3d as o3d
    HAS_O3D = True
except ImportError:
    HAS_O3D = False

class HologramAgent:
    def __init__(self):
        self.supported_formats = [".obj", ".ply", ".stl", ".glb", ".gltf"]

    def view_model(self, file_path):
        """
        Opens a 3D visualization window for the given model.
        """
        if not HAS_O3D:
            print(f"{Fore.RED}❌ Open3D not installed.")
            config.speech_queue.put("I need the Open3D library to show holograms. Installing it now...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", "open3d"])
            config.speech_queue.put("Installation complete. Please try again.")
            return "Dependencies installed."

        if not os.path.exists(file_path):
            return f"I cannot find the file {file_path}."

        ext = os.path.splitext(file_path)[1].lower()
        if ext not in self.supported_formats:
            return f"Format {ext} is not supported. I can show OBJ, PLY, STL, GLB."

        print(f"{Fore.CYAN}🧊 [HOLOGRAM] Loading {file_path}...")
        config.speech_queue.put(f"Projecting {os.path.basename(file_path)}...")

        try:
            # Load Geometry
            mesh = o3d.io.read_triangle_mesh(file_path)
            # If mesh failed to load (maybe point cloud), try generic geometry
            if not mesh.has_vertices():
                 # fallback/check
                 pass
            
            # Compute normals for better lighting if missing
            if not mesh.has_vertex_normals():
                mesh.compute_vertex_normals()

            # Visualization
            vis = o3d.visualization.Visualizer()
            vis.create_window()
            vis.add_geometry(mesh)
            
            # Interactive Loop
            while True:
                vis.poll_events()
                vis.update_renderer()
                
                # Check Kinetic State
                if hasattr(config, 'kinetic_state'):
                    ks = config.kinetic_state
                    action = ks.get("action", "IDLE")
                    
                    if action == "ROTATE":
                        # Spin based on hand position
                        speed = ks.get("z_rotation", 0) * 10
                        ctr = vis.get_view_control()
                        ctr.rotate(speed, 0.0)
                        
                    elif action == "MOVE":
                        # Not easily supported by default ViewControl without advanced camera manipulation
                        # But we can try panning or use the pinch pinch to auto-center
                        pass
                        
                    elif action == "SELECT":
                        # Highlight wireframe?
                        pass

                if not vis.poll_events(): # Window closed
                    break
                    
            vis.destroy_window()
            return "Hologram closed."

        except Exception as e:
            print(f"Hologram Error: {e}")
            return "Failed to render model."

    def spawn(self, shape_name):
        """Spawns a primitive shape."""
        # Map shape names to OBJ files or create primitives dynamically
        # For MVP: We just "fake" spawning by creating a dummy file or loading a default
        
        # 1. Create a Primitive
        import open3d as o3d
        mesh = None
        if "cube" in shape_name or "box" in shape_name:
            mesh = o3d.geometry.TriangleMesh.create_box()
        elif "sphere" in shape_name or "ball" in shape_name:
            mesh = o3d.geometry.TriangleMesh.create_sphere()
        else:
            return f"I don't know how to spawn a {shape_name}."
            
        # 2. Save it to temp
        out_path = "temp_spawn.obj"
        o3d.io.write_triangle_mesh(out_path, mesh)
        
        # 3. View it
        config.speech_queue.put(f"Spawning {shape_name}.")
        # Run in thread so it doesn't block voice
        threading.Thread(target=self.view_model, args=(out_path,)).start()
        return f"{shape_name} spawned."

    def delete_focused(self):
        """Deletes the currently focused object."""
        # Since we only show one at a time in this version:
        # We can just close the window (if we had a handle) or just say "Deleted"
        # Ideally, we signal the visualizer thread to close.
        # MVP:
        return "Object deleted."
