import cv2
import mediapipe as mp
import threading
import time
import math
import config
from colorama import Fore

class KineticAgent:
    def __init__(self):
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.7
        )
        self.mp_draw = mp.solutions.drawing_utils
        self.cap = None
        self.running = False
        self.state = "IDLE" # IDLE, ROTATE, MOVE, SELECT
        self.hand_centroid = (0, 0) # Normalized X, Y
        self.pinch_strength = 0.0
        
        # Shared State interface
        if not hasattr(config, 'kinetic_state'):
            config.kinetic_state = {
                "action": "IDLE",
                "x": 0.0,
                "y": 0.0,
                "z_rotation": 0.0
            }

    def start_tracking(self):
        """Starts the background tracking thread."""
        if self.running: return
        self.running = True
        threading.Thread(target=self._update_loop, daemon=True).start()
        print(f"{Fore.CYAN}🖐️ [KINETIC] Hand Tracking Online.")

    def stop_tracking(self):
        self.running = False

    def _calculate_distance(self, p1, p2):
        return math.hypot(p1.x - p2.x, p1.y - p2.y)

    def _update_loop(self):
        # Use index 0 or try to find available camera
        self.cap = cv2.VideoCapture(0)
        
        while self.running and self.cap.isOpened():
            success, img = self.cap.read()
            if not success:
                time.sleep(0.1)
                continue

            # Flip for mirror view
            img = cv2.flip(img, 1)
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            
            results = self.hands.process(img_rgb)
            
            action = "IDLE"
            cx, cy = 0.0, 0.0
            rotation = 0.0

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    # Logic for Gestures
                    
                    # 1. Centroid (Approximate using wrist and middle finger MCP)
                    wrist = hand_landmarks.landmark[self.mp_hands.HandLandmark.WRIST]
                    middle_mcp = hand_landmarks.landmark[self.mp_hands.HandLandmark.MIDDLE_FINGER_MCP]
                    cx = (wrist.x + middle_mcp.x) / 2
                    cy = (wrist.y + middle_mcp.y) / 2
                    
                    # 2. Fingers State
                    # Thumb, Index, Middle, Ring, Pinky tips
                    thumb_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.THUMB_TIP]
                    index_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.INDEX_FINGER_TIP]
                    middle_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.MIDDLE_FINGER_TIP]
                    ring_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.RING_FINGER_TIP]
                    pinky_tip = hand_landmarks.landmark[self.mp_hands.HandLandmark.PINKY_TIP]
                    
                    # Calculate Pinch (Thumb + Index)
                    pinch_dist = self._calculate_distance(thumb_tip, index_tip)
                    
                    # Calculate Fist (Tips close to wrist/palm base)
                    # Simplified: Check if fingertips are below MCPs (y coordinate higher on screen is lower value usually, but here y increases downwards)
                    # Open Palm: Tips are far from wrist. Fist: Tips are close.
                    
                    wrist_dist_index = self._calculate_distance(index_tip, wrist)
                    wrist_dist_middle = self._calculate_distance(middle_tip, wrist)
                    wrist_dist_ring = self._calculate_distance(ring_tip, wrist)
                    wrist_dist_pinky = self._calculate_distance(pinky_tip, wrist)
                    
                    avg_dist = (wrist_dist_index + wrist_dist_middle + wrist_dist_ring + wrist_dist_pinky) / 4
                    
                    # GESTURE RECOGNITION
                    
                    # AIR-TAP (Pinch) -> SELECT
                    if pinch_dist < 0.05:
                        action = "SELECT"
                    
                    # CLOSED FIST -> MOVE
                    elif avg_dist < 0.2: # Threshold for fist
                        action = "MOVE"
                        
                    # OPEN PALM -> ROTATE
                    elif avg_dist > 0.3: # Threshold for open hand
                        action = "ROTATE"
                        # Rotation Logic: Use Wrist X vs Middle X or just Hand X relative to center screen
                        # Let's use hand X position as a dial
                        rotation = (cx - 0.5) * 2 # -1 to 1 range
                        
                    # Update Config
                    config.kinetic_state["action"] = action
                    config.kinetic_state["x"] = cx
                    config.kinetic_state["y"] = cy
                    config.kinetic_state["z_rotation"] = rotation
                    
            else:
                config.kinetic_state["action"] = "IDLE"

            time.sleep(0.01) # Yield
        
        if self.cap:
             self.cap.release()
