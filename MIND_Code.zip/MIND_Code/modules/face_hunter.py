import os
import requests
import numpy as np
import config
from colorama import Fore
from io import BytesIO

# Conditional Imports
try:
    import face_recognition
    from PIL import Image
    HAS_FR = True
except ImportError:
    HAS_FR = False
    face_recognition = None
    Image = None

from modules.security_agent import SecurityAgent

class FaceHunter:
    """
    God's Eye Lite: Searches for a target face across social media profiles.
    Combines Argus (Url Discovery) + Face Recognition (Image Matching).
    """
    
    def __init__(self):
        self.security_agent = SecurityAgent()
        self.target_encoding = None
        self.target_name = "Unknown"

    def load_target_face(self, image_path):
        """
        Loads and encodes the target face from a local file.
        """
        if not HAS_FR:
            print(Fore.RED + "⚠️  [FACE] 'face_recognition' library missing. Install via pip.")
            return False

        if not os.path.exists(image_path):
            print(Fore.RED + f"⚠️  [FACE] Target image not found: {image_path}")
            return False
            
        try:
            print(Fore.YELLOW + f"👁️  [FACE] Encoding Target: {os.path.basename(image_path)}...")
            image = face_recognition.load_image_file(image_path)
            encodings = face_recognition.face_encodings(image)
            
            if len(encodings) > 0:
                self.target_encoding = encodings[0]
                self.target_name = os.path.basename(image_path)
                print(Fore.GREEN + "✅ Target Face Locked.")
                return True
            else:
                print(Fore.RED + "⚠️  No face found in target image!")
                return False
        except Exception as e:
            print(Fore.RED + f"⚠️  Error loading face: {e}")
            return False

    def _extract_profile_image(self, url):
        """
        Attempts to find the profile picture URL from a social media page.
        Heuristic: Looks for og:image or twitter:image meta tags.
        """
        if not requests: return None
        
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            r = requests.get(url, headers=headers, timeout=5)
            if r.status_code == 200:
                text = r.text
                # Simple string parsing to avoid bs4 dependency if desired, 
                # but let's assume simple unique keywords for meta tags
                lines = text.split('>')
                for line in lines:
                    if 'property="og:image"' in line or 'name="twitter:image"' in line:
                        # Extract content="..."
                        start = line.find('content="')
                        if start != -1:
                            sub = line[start+9:]
                            end = sub.find('"')
                            if end != -1:
                                return sub[:end]
        except:
            pass
        return None

    def _compare_face_from_url(self, image_url):
        """
        Downloads image from URL and compares with target.
        """
        if not self.target_encoding is not None: return False
        
        try:
            r = requests.get(image_url, timeout=5)
            file = BytesIO(r.content)
            image = face_recognition.load_image_file(file)
            
            unknown_encodings = face_recognition.face_encodings(image)
            
            for unknown_encoding in unknown_encodings:
                results = face_recognition.compare_faces([self.target_encoding], unknown_encoding)
                if results[0] == True:
                    return True
        except:
            pass
        return False

    def hunt(self, username):
        """
        Main Protocol:
        1. Run Argus Scan for username.
        2. For each found profile, extract image.
        3. Compare image to target.
        """
        if not HAS_FR:
            return {"error": "Face Recognition module missing"}
        
        if self.target_encoding is None:
            return {"error": "No target face loaded. Call load_target_face() first."}

        print(Fore.RED + f"\n👁️  [FACE HUNTER] Tracking '{username}' across the web...")
        
        # 1. Argus Scan
        profiles = self.security_agent.run_argus_scan(username)
        
        matches = []
        
        print(Fore.CYAN + f"   > Analyzing {len(profiles)} profiles for biometric matches...")
        
        for site, url in profiles.items():
            # 2. Extract Image
            img_url = self._extract_profile_image(url)
            
            if img_url:
                # 3. Compare
                is_match = self._compare_face_from_url(img_url)
                if is_match:
                    print(Fore.GREEN + f"   🔥 MATCH ALERT! Face detected on {site}: {url}")
                    matches.append({"site": site, "url": url, "image": img_url})
                else:
                    # print(f"      No match on {site}")
                    pass
            else:
                # print(f"      No image extracted from {site}")
                pass
                
        return {"total_profiles": len(profiles), "matches": matches}
