import os
import json
import datetime
from colorama import Fore

class AdminAgent:
    def __init__(self):
        self.tasks_file = "D:/MIND_Project/tasks.json"
        self._load_tasks()

    def _load_tasks(self):
        """Loads tasks from JSON file."""
        if not os.path.exists(self.tasks_file):
            self.tasks = []
            self._save_tasks()
        else:
            try:
                with open(self.tasks_file, 'r') as f:
                    self.tasks = json.load(f)
            except:
                self.tasks = []

    def _save_tasks(self):
        """Saves tasks to JSON file."""
        with open(self.tasks_file, 'w') as f:
            json.dump(self.tasks, f, indent=4)

    def add_task(self, description):
        """Adds a new task."""
        task = {
            "id": len(self.tasks) + 1,
            "description": description,
            "date_added": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "pending"
        }
        self.tasks.append(task)
        self._save_tasks()
        return f"Task added: {description}"

    def list_tasks(self):
        """Returns a formatted list of pending tasks."""
        pending = [t for t in self.tasks if t['status'] == 'pending']
        if not pending:
            return "You have no pending tasks."
        
        report = "Here are your tasks:\n"
        for t in pending:
            report += f"{t['id']}. {t['description']}\n"
        return report

    def complete_task(self, task_id_str):
        """Marks a task as complete by ID."""
        try:
            task_id = int(task_id_str)
            for t in self.tasks:
                if t['id'] == task_id:
                    t['status'] = "completed"
                    t['date_completed'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self._save_tasks()
                    return f"Task {task_id} marked as complete."
            return f"I couldn't find task number {task_id}."
        except ValueError:
            return "Invalid task number."
