from modules.simulation.energy import EnergyModel
from modules.simulation.engineering import EngineeringModel
import json

class SimulationController:
    """
    Orchestrates different simulation engines (Energy, Engineering, Physics).
    """
    
    def __init__(self):
        self.energy_engine = EnergyModel()
        self.engineering_engine = EngineeringModel()
        
    def run_simulation(self, task_payload):
        """
        Routes the task to the correct engine based on 'simulation_type'.
        Payload structure:
        {
            "simulation_type": "energy",
            "parameters": { ... },
            "constraints": { ... }
        }
        """
        sim_type = task_payload.get('simulation_type', '').lower()
        
        if 'energy' in sim_type or 'solar' in sim_type or 'wind' in sim_type:
            return self._handle_energy_simulation(task_payload)

        if 'engineering' in sim_type or 'stress' in sim_type or 'gear' in sim_type or 'structure' in sim_type:
            return self._handle_engineering_simulation(task_payload)
        
        return {
            "error": f"Unknown simulation type: {sim_type}",
            "confidence": 0.0
        }

    def _handle_engineering_simulation(self, payload):
        params = payload.get('parameters', {})
        sub_type = payload.get('sub_type', 'stress') 
        
        results = {}
        
        if 'stress' in sub_type or 'beam' in sub_type:
            results = self.engineering_engine.calculate_beam_stress(params)
        elif 'gear' in sub_type:
            results = self.engineering_engine.calculate_gear_ratio(params)
        elif 'thermal' in sub_type or 'expansion' in sub_type:
            results = self.engineering_engine.thermal_expansion(params)
            
        return {
            "simulation_type": "engineering",
            "sub_type": sub_type,
            "results": results,
            "confidence": 0.90, # Physics formulas are reliable
            "source": "MIND Engineering Core"
        }

    def _handle_energy_simulation(self, payload):
        params = payload.get('parameters', {})
        sub_type = payload.get('sub_type', 'solar') 
        
        results = {}
        if 'solar' in sub_type:
            results = self.energy_engine.simulate_solar(params)
        elif 'wind' in sub_type:
            results = self.energy_engine.simulate_wind(params)
        elif 'hybrid' in sub_type:
            results = self.energy_engine.optimize_hybrid(payload.get('constraints', {}))
            
        return {
            "simulation_type": "energy",
            "sub_type": sub_type,
            "results": results,
            "confidence": 0.95, 
            "source": "MIND Energy Simulator v1.0"
        }

    def run_chained_simulation(self, chain_request):
        """
        Executes multi-domain simulations.
        """
        results = []
        steps = chain_request.get('steps', [])
        
        for i, step in enumerate(steps):
            current_params = step.get('params', {}).copy()
            
            # Map inputs from previous context (Simplified logic for demo)
            if i > 0 and 'map_input' in step:
                 # HARDCODED LOGIC: Solar Yield -> Weight
                 if 'weight_kg' in str(step.get('map_input')):
                     # Assume area is available in step 0
                     area = steps[0]['params'].get('area_m2', 0)
                     current_params['load_n'] = (area * 12) * 9.81
            
            payload = {
                "simulation_type": step.get('type'),
                "sub_type": step.get('sub_type'),
                "parameters": current_params
            }
            results.append(self.run_simulation(payload))
            
        return {
            "chain_name": chain_request.get('chain_name'),
            "steps_executed": len(results),
            "final_result": results[-1],
            "full_trace": results
        }
