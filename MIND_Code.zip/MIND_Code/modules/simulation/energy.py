import math

class EnergyModel:
    """
    Simulation module for Energy Systems (Solar, Wind, Hybrid).
    Calculates yields, costs, and basic optimization.
    """
    
    def __init__(self):
        # Constants tailored for Sri Lanka (approximate averages)
        self.solar_irradiance = 5.0  # kWh/m²/day
        self.avg_wind_speed = 6.0    # m/s
        self.electricity_cost = 45.0 # LKR per kWh (Average high tier)

    def simulate_solar(self, params):
        """
        Input: { 'area_m2': float, 'efficiency': float, 'panel_cost': float }
        """
        area = params.get('area_m2', 20)
        efficiency = params.get('efficiency', 0.18)
        cost_per_panel = params.get('panel_cost', 50000) # LKR
        
        daily_generation = area * self.solar_irradiance * efficiency
        monthly_generation = daily_generation * 30
        
        # Simple ROI
        # Assuming 1 panel per 2 m2 roughly
        num_panels = math.ceil(area / 2)
        total_cost = num_panels * cost_per_panel
        
        monthly_savings = monthly_generation * self.electricity_cost
        payback_months = total_cost / monthly_savings if monthly_savings > 0 else 999
        
        return {
            "daily_kwh": round(daily_generation, 2),
            "monthly_kwh": round(monthly_generation, 2),
            "estimated_cost_lkr": total_cost,
            "monthly_savings_lkr": round(monthly_savings, 2),
            "payback_period_years": round(payback_months / 12, 2)
        }

    def simulate_wind(self, params):
        """
        Input: { 'turbine_count': int, 'efficiency': float, 'rotor_radius_m': float }
        Power = 0.5 * rho * A * V^3 * Cp
        """
        count = params.get('turbine_count', 1)
        radius = params.get('rotor_radius_m', 2.0)
        efficiency = params.get('efficiency', 0.4) # Betz limit is 0.59
        
        rho = 1.225 # Air density
        area = math.pi * (radius ** 2)
        
        # Power per turbine in Watts
        power_watts = 0.5 * rho * area * (self.avg_wind_speed ** 3) * efficiency
        
        daily_generation_kwh = (power_watts * count * 24) / 1000
        monthly_generation = daily_generation_kwh * 30
        
        return {
            "turbine_count": count,
            "power_rating_kw": round((power_watts * count) / 1000, 2),
            "daily_kwh": round(daily_generation_kwh, 2),
            "monthly_kwh": round(monthly_generation, 2)
        }

    def optimize_hybrid(self, constraints):
        """
        Find best mix of Solar + Wind for a given budget or target.
        Input: { 'budget_lkr': float, 'target_kwh_month': float }
        """
        budget = constraints.get('budget_lkr', 1000000)
        
        # Simplified assumptions for optimization
        solar_cost_per_kwh_month = 50000 / ( (2 * 5.0 * 0.18 * 30) ) # Cost / (Yield of 2m2 panel)
        wind_cost_per_kwh_month = 150000 / ( (0.5 * 1.225 * math.pi*4 * 6**3 * 0.4 * 24 * 30 / 1000) ) 
        
        # Heuristic: Solar is usually cheaper per kWh upfront in small scale, Wind better at scale/high wind.
        # This is a placeholder for a real optimization algorithm (Linear Programming)
        
        recommendation = "Solar Priority" 
        if wind_cost_per_kwh_month < solar_cost_per_kwh_month:
            recommendation = "Wind Priority"
            
        return {
            "strategy": recommendation,
            "note": "Optimization uses simplified cost heuristics relative to Sri Lankan context."
        }
