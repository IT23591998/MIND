class EngineeringModel:
    """
    Simulation module for Engineering Systems (Mechanical, Structural, Thermal).
    Provides basic physics calculations for MIND.
    """
    
    def __init__(self):
        # Material Properties (approximate constants)
        self.materials = {
            "steel": {"density": 7850, "yield_strength": 250e6, "elastic_modulus": 200e9, "thermal_exp": 12e-6},
            "aluminum": {"density": 2700, "yield_strength": 95e6, "elastic_modulus": 69e9, "thermal_exp": 23e-6},
            "concrete": {"density": 2400, "yield_strength": 20e6, "elastic_modulus": 30e9, "thermal_exp": 10e-6},
            "wood": {"density": 600, "yield_strength": 40e6, "elastic_modulus": 11e9, "thermal_exp": 5e-6}
        }

    def calculate_beam_stress(self, params):
        """
        Simple Beam Bending Stress (S = M*y / I)
        Assumes a rectangular cross-section simply supported beam with center load.
        Input: { 'load_n': float, 'length_m': float, 'width_m': float, 'height_m': float, 'material': str }
        """
        load = params.get('load_n', 1000)
        length = params.get('length_m', 2.0)
        width = params.get('width_m', 0.1)
        height = params.get('height_m', 0.1)
        material_name = params.get('material', 'steel').lower()
        
        # Max Moment for center load = PL/4
        moment = (load * length) / 4
        
        # Moment of Inertia for rectangle = bh^3 / 12
        inertia = (width * (height ** 3)) / 12
        
        # Max distance from neutral axis = h/2
        y = height / 2
        
        # Stress = My / I
        stress_pa = (moment * y) / inertia
        
        # Safety Factor
        material = self.materials.get(material_name, self.materials['steel'])
        yield_strength = material['yield_strength']
        safety_factor = yield_strength / stress_pa if stress_pa > 0 else 999
        
        return {
            "max_stress_pa": round(stress_pa, 2),
            "max_stress_mpa": round(stress_pa / 1e6, 2),
            "safety_factor": round(safety_factor, 2),
            "material": material_name,
            "status": "SAFE" if safety_factor > 1.5 else "UNSAFE" if safety_factor < 1.0 else "WARNING"
        }

    def calculate_gear_ratio(self, params):
        """
        Input: { 'driver_teeth': int, 'driven_teeth': int, 'input_rpm': float }
        """
        driver = params.get('driver_teeth', 20)
        driven = params.get('driven_teeth', 40)
        rpm = params.get('input_rpm', 1000)
        
        ratio = driven / driver
        output_rpm = rpm / ratio
        torque_mult = ratio # Torque increases as speed decreases
        
        return {
            "gear_ratio": f"{ratio}:1",
            "output_rpm": round(output_rpm, 2),
            "torque_multiplier": round(ratio, 2)
        }

    def thermal_expansion(self, params):
        """
        Linear Expansion: dL = L * alpha * dT
        Input: { 'length_m': float, 'temp_change_c': float, 'material': str }
        """
        length = params.get('length_m', 10.0)
        dt = params.get('temp_change_c', 50.0)
        material_name = params.get('material', 'steel').lower()
        
        alpha = self.materials.get(material_name, self.materials['steel'])['thermal_exp']
        delta_l = length * alpha * dt
        
        return {
            "material": material_name,
            "original_length": length,
            "temp_change": dt,
            "expansion_m": delta_l,
            "expansion_mm": round(delta_l * 1000, 4)
        }
