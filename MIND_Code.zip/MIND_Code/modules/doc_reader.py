import os
import PyPDF2
from docx import Document
from pptx import Presentation
from mind_brain import MindBrain

class DocReader:
    def __init__(self):
        self.brain = MindBrain()
        self.max_chars = 4000  # Limit for LLM context

    def extract_text(self, filepath):
        """Extracts text from PDF, DOCX, or PPTX."""
        if not os.path.exists(filepath):
            return "File not found."
            
        ext = os.path.splitext(filepath)[1].lower()
        text = ""

        try:
            if ext == ".pdf":
                with open(filepath, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    for page in reader.pages:
                        text += page.extract_text() + "\n"
                        
            elif ext == ".docx":
                doc = Document(filepath)
                for para in doc.paragraphs:
                    text += para.text + "\n"
                    
            elif ext == ".pptx":
                prs = Presentation(filepath)
                for slide in prs.slides:
                    for shape in slide.shapes:
                        if hasattr(shape, "text"):
                            text += shape.text + "\n"
                            
            elif ext == ".txt":
                with open(filepath, 'r', encoding='utf-8') as f:
                    text = f.read()
            else:
                return "Unsupported file format. Use PDF, DOCX, or PPTX."

            return text.strip()
            
        except Exception as e:
            return f"Error reading file: {str(e)}"

    def explain_document(self, filepath):
        """Reads the doc and asks the 'Theorist' brain to explain it."""
        raw_text = self.extract_text(filepath)
        
        if "Error" in raw_text or "File not found" in raw_text:
            return raw_text
            
        if len(raw_text) < 10:
            return "The document appears to be empty."

        # Truncate if too long (simple approach for now)
        # Ideally we would chunk, but for 'One short sentence' / summary, a chunk is fine.
        content_to_analyze = raw_text[:self.max_chars]
        
        prompt = f"""
        You are a Professor explaining a document to a student.
        Document Content (Excerpt):
        {content_to_analyze}
        
        Please provide a concise summary or explanation of the key concepts found in this text.
        Focus on the 'Theory' or 'Core Idea'.
        """
        
        # This will naturally route to THEORIST if "explain" or "theory" is in the prompt/logic
        # But we can force it or just use think() which now has routing.
        # Since the user explicitly asked for 'Explain', we construct a query that triggers the THEORIST.
        
        response = self.brain.think(f"Explain this theory from the document: {prompt}")
        return response
