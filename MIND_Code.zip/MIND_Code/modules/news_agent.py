import os
import time
import sqlite3
import threading
import requests
import json
import psutil
import datetime
from colorama import Fore
import config

# Try feedparser, fallback to manual XML
try:
    import feedparser
    HAS_FEEDPARSER = True
except ImportError:
    HAS_FEEDPARSER = False
    import xml.etree.ElementTree as ET

DB_PATH = "D:/MIND_Project/assets/global_pulse.db"
HUD_PATH = "D:/MIND_Project/hud_status.json"

KEYWORDS_CRITICAL = ["mageepan", "sliit", "vulnerability", "blender", "zero-day", "mind"]
KEYWORDS_HIGH = ["ai", "python", "quantum", "nvidia", "google", "openai"]

class NewsAgent:
    def __init__(self):
        self.running = False
        self.db = None
        self._init_db()
        self.sources = [
            "https://news.google.com/rss/search?q=technology&hl=en-US&gl=US&ceid=US:en",
            "https://feeds.bbci.co.uk/news/technology/rss.xml"
        ]
        
    def _init_db(self):
        os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
        self.db = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.db.execute('''CREATE TABLE IF NOT EXISTS news (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            timestamp TEXT,
                            source TEXT,
                            headline TEXT UNIQUE,
                            impact_score INTEGER
                        )''')
        self.db.commit()

    def _pin_to_ecores(self):
        try:
            p = psutil.Process()
            count = psutil.cpu_count()
            # E-Cores (Last 2)
            if count >= 4:
                p.cpu_affinity([count-1, count-2])
        except: pass

    def calculate_impact(self, text):
        text = text.lower()
        for kw in KEYWORDS_CRITICAL:
            if kw in text: return 10
        for kw in KEYWORDS_HIGH:
            if kw in text: return 6
        return 1

    def _parse_feed(self, url):
        items = []
        try:
            if HAS_FEEDPARSER:
                feed = feedparser.parse(url)
                for entry in feed.entries:
                    items.append((entry.title, entry.link))
            else:
                # Basic XML fallback
                resp = requests.get(url, timeout=5)
                root = ET.fromstring(resp.text)
                # RSS 2.0 usually channel/item/title
                for item in root.findall('.//item'):
                    title = item.find('title').text
                    link = item.find('link').text
                    items.append((title, link))
        except Exception as e:
            # print(f"Feed Error {url}: {e}")
            pass
        return items

    def _prune_db(self):
        # Keep last 48 hours
        cutoff = (datetime.datetime.now() - datetime.timedelta(hours=48)).isoformat()
        self.db.execute("DELETE FROM news WHERE timestamp < ?", (cutoff,))
        self.db.commit()

    def start_stream(self):
        self.running = True
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        self._pin_to_ecores()
        print(f"{Fore.BLUE}[Global Pulse] Stream Active (E-Cores)")
        
        while self.running:
            for url in self.sources:
                news_items = self._parse_feed(url)
                
                for title, link in news_items:
                    score = self.calculate_impact(title)
                    
                    try:
                        # Insert
                        ts = datetime.datetime.now().isoformat()
                        self.db.execute("INSERT INTO news (timestamp, source, headline, impact_score) VALUES (?, ?, ?, ?)",
                                      (ts, "RSS", title, score))
                        self.db.commit()
                        
                        # INTERRUPTION LOGIC
                        if score >= 8:
                            print(f"{Fore.RED}🚨 BREAKING NEWS: {title}")
                            self.trigger_alert(title)
                            
                    except sqlite3.IntegrityError:
                        pass # Duplicate
            
            self._prune_db()
            time.sleep(30) # Poll every 30s

    def trigger_alert(self, headline):
        # 1. Update HUD (Red Pulse)
        try:
            with open(HUD_PATH, "r") as f:
                status = json.load(f)
            status["firewall_status"] = "CRITICAL" # Re-use critical state for red pulse
            with open(HUD_PATH, "w") as f:
                json.dump(status, f)
        except: pass
        
        # 2. Speak
        # Access config speech queue directly
        config.speech_queue.put(f"Alert. Breaking News: {headline}")

    def get_latest_news(self, limit=5):
        cursor = self.db.execute("SELECT headline, impact_score FROM news ORDER BY timestamp DESC LIMIT ?", (limit,))
        return cursor.fetchall()

if __name__ == "__main__":
    agent = NewsAgent()
    agent.start_stream()
    while True:
        time.sleep(1)
