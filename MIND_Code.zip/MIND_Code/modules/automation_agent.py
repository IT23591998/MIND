import os
import sys
import subprocess
import datetime
import threading
import requests
import webbrowser
from colorama import Fore
import config

# --- DEPENDENCY CHECK ---
def check_dependencies():
    missing = []
    try: import psutil
    except ImportError: missing.append("psutil")
    
    try: import bs4
    except ImportError: missing.append("beautifulsoup4")
    
    try: import comtypes
    except ImportError: missing.append("comtypes")
    
    try: import pycaw
    except ImportError: missing.append("pycaw")

    try: import cv2
    except ImportError: missing.append("opencv-python")
    
    try: import yt_dlp
    except ImportError: missing.append("yt-dlp")
    
    try: import vlc
    except ImportError: missing.append("python-vlc")

    if missing:
        print(f"{Fore.YELLOW}⚙️ [AUTO] Installing JARVIS dependencies (Targeting D: Drive): {', '.join(missing)}...")
        
        # Force pip to use D: drive for temp and cache to avoid C: full error
        # Assuming config.BASE_PATH is defined, or we calculate it relative to this file
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        temp_dir = os.path.join(base_dir, "pip_temp")
        cache_dir = os.path.join(base_dir, "pip_cache")
        
        os.makedirs(temp_dir, exist_ok=True)
        os.makedirs(cache_dir, exist_ok=True)
        
        # Set environment variables for this subprocess only
        env = os.environ.copy()
        env["TMP"] = temp_dir
        env["TEMP"] = temp_dir
        
        # Run pip with custom cache dir
        cmd = [sys.executable, "-m", "pip", "install", "--cache-dir", cache_dir] + missing
        
        try:
            subprocess.check_call(cmd, env=env)
            print(f"{Fore.GREEN}✅ Dependencies installed.")
        except subprocess.CalledProcessError as e:
            print(f"{Fore.RED}❌ Install Failed: {e}")
            print(f"{Fore.RED}Please try manually running: pip install {' '.join(missing)}")

check_dependencies()

# Late imports after install
import psutil
import cv2
import vlc
import yt_dlp
from bs4 import BeautifulSoup
from ctypes import cast, POINTER, windll
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

class AutomationAgent:
    def __init__(self):
        self.brain = None # Lazy load if needed to avoid circular import issues
        
    def get_system_status(self):
        """
        Returns a string summary of system health.
        """
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        battery = psutil.sensors_battery()
        
        status = f"CPU is at {cpu}%. Memory is at {mem.percent}% used."
        
        if battery:
            plugged = "Plugged in" if battery.power_plugged else "On battery"
            status += f" Battery is at {battery.percent}% ({plugged})."
            
        print(f"{Fore.CYAN}🖥️ [STATUS] {status}")
        config.speech_queue.put(status)

    def control_media(self, command):
        """
        Controls Volume (Up/Down/Mute).
        """
        try:
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            
            current_vol = volume.GetMasterVolumeLevelScalar()
            
            if command == "vol_up":
                new_vol = min(1.0, current_vol + 0.1)
                volume.SetMasterVolumeLevelScalar(new_vol, None)
                config.speech_queue.put("Volume increased.")
                
            elif command == "vol_down":
                new_vol = max(0.0, current_vol - 0.1)
                volume.SetMasterVolumeLevelScalar(new_vol, None)
                config.speech_queue.put("Volume decreased.")
                
            elif command == "mute":
                volume.SetMute(1, None)
                config.speech_queue.put("System muted.")
                
            elif command == "unmute":
                volume.SetMute(0, None)
                config.speech_queue.put("System unmuted.")
                
        except Exception as e:
            print(f"Media Error: {e}")
            config.speech_queue.put("I cannot control the audio on this device.")

    def get_weather(self, city):
        """
        Gets generic weather from OpenMeteo (No API Key required).
        """
        print(f"{Fore.CYAN}☁️ [WEATHER] Checking for {city}...")
        try:
            # 1. Geocoding
            geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={city}&count=1&language=en&format=json"
            r = requests.get(geo_url).json()
            if "results" not in r:
                config.speech_queue.put(f"I couldn't find a city named {city}.")
                return
                
            lat = r["results"][0]["latitude"]
            lon = r["results"][0]["longitude"]
            name = r["results"][0]["name"]
            
            # 2. Weather
            w_url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
            w = requests.get(w_url).json()
            temp = w["current_weather"]["temperature"]
            
            report = f"It is currently {temp} degrees Celsius in {name}."
            config.speech_queue.put(report)
            
        except Exception as e:
            print(f"Weather Error: {e}")
            config.speech_queue.put("I couldn't fetch the weather data.")

    def web_search(self, query):
        """
        Opens Google Search.
        """
        print(f"{Fore.CYAN}🌐 [WEB] Searching: {query}")
        url = f"https://www.google.com/search?q={query}"
        webbrowser.open(url)
        config.speech_queue.put(f"Searching for {query}.")

    def read_page(self, target="clipboard"):
        """
        Reads the URL from clipboard, extracts text, and summarizes it.
        """
        import pyperclip
        from mind_brain import MindBrain # Import here to avoid circular dep
        
        url = ""
        if target == "clipboard":
            url = pyperclip.paste()
        else:
            url = target
            
        if not url.startswith("http"):
            config.speech_queue.put("That doesn't look like a valid URL.")
            return

        print(f"{Fore.CYAN}📖 [READING] Fetching {url}...")
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            r = requests.get(url, headers=headers, timeout=5)
            soup = BeautifulSoup(r.text, 'html.parser')
            
            # Remove scripts and styles
            for script in soup(["script", "style"]):
                script.extract()
                
            text = soup.get_text()
            # Clean formatting
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            clean_text = '\n'.join(chunk for chunk in chunks if chunk)
            
            # Summarize with Brain
            if not self.brain: self.brain = MindBrain()
            
            # Truncate to avoid context limit
            input_text = clean_text[:4000] 
            
            print(f"{Fore.CYAN}🧠 [THINKING] Summarizing...")
            summary = self.brain.think(f"Summarize this webpage in 3 sentences: {input_text}", system_role="Assistant")
            
            print(f"{Fore.GREEN}🗣️ [SPEAKING] Summary ready.")
            config.speech_queue.put(f"Here is a summary: {summary}")
            
        except Exception as e:
            print(f"Read Error: {e}")
            config.speech_queue.put("I could not read that webpage.")

    # --- SECURE VAULT FEATURES ---
    
    def create_vault(self, name):
        """
        Creates a super-hidden system folder.
        """
        vault_path = os.path.join(config.BASE_PATH, "Vaults", name)
        
        if os.path.exists(vault_path):
            config.speech_queue.put(f"Vault {name} already exists.")
            return

        try:
            os.makedirs(vault_path)
            # Use attrib to make it System (+s) and Hidden (+h)
            # This makes it invisible even with "Show Hidden Items" on (unless "Hide Protected OS files" is off)
            subprocess.run(f'attrib +h +s "{vault_path}"', shell=True)
            
            print(f"{Fore.MAGENTA}🔒 [VAULT] Created Secure Folder: {name}")
            config.speech_queue.put(f"Secure folder {name} created and hidden.")
            
        except Exception as e:
            print(f"Vault Error: {e}")
            config.speech_queue.put("I failed to engage the cloaking protocols.")

    def open_vault(self, name):
        """
        Opens a hidden vault.
        """
        vault_path = os.path.join(config.BASE_PATH, "Vaults", name)
        
        if not os.path.exists(vault_path):
            config.speech_queue.put(f"I cannot find a vault named {name}.")
            return
            
        print(f"{Fore.MAGENTA}🔓 [VAULT] Accessing: {name}")
        config.speech_queue.put(f"Accessing secure folder {name}.")
        os.startfile(vault_path)

    # --- JARVIS V2 FEATURES ---

    def lock_system(self):
        """
        Locks the workstation immediately.
        """
        print(f"{Fore.RED}🔒 [SYSTEM] Locking Workstation...")
        config.speech_queue.put("Securing the system, Sir.")
        windll.user32.LockWorkStation()

    def camera_snapshot(self):
        """
        Takes a photo using the webcam.
        """
        print(f"{Fore.CYAN}📸 [SURVEILLANCE] Accessing Camera...")
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                config.speech_queue.put("I cannot access the camera sensors.")
                return

            ret, frame = cap.read()
            if ret:
                timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = os.path.join(config.BASE_PATH, f"snapshot_{timestamp}.jpg")
                cv2.imwrite(filename, frame)
                print(f"{Fore.GREEN}🖼️ [SAVED] Snapshot: {filename}")
                config.speech_queue.put("Snapshot taken.")
                os.startfile(filename)
            else:
                config.speech_queue.put("Camera feed unstable.")
            
            cap.release()
        except Exception as e:
            print(f"Camera Error: {e}")
            config.speech_queue.put("Surveillance systems failing.")

    def set_power_mode(self, mode="high"):
        """
        Switches Windows Power Plan (High Performance vs Balanced).
        """
        # GUIDs for Standard Windows Power Plans
        HIGH_PERF = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
        BALANCED = "381b4222-f694-41f0-9685-ff5bb260df2e"
        
        target_guid = HIGH_PERF if mode == "high" else BALANCED
        mode_name = "High Performance" if mode == "high" else "Balanced"
        
        print(f"{Fore.YELLOW}⚡ [ENERGY] Switching to {mode_name}...")
        try:
            subprocess.run(f"powercfg /setactive {target_guid}", shell=True)
            config.speech_queue.put(f"Power rerouted to {mode_name} mode.")
        except Exception as e:
            print(f"Power Error: {e}")
            config.speech_queue.put("I could not adjust the power relays.")

    def play_music(self, query):
        """
        Plays music via yt-dlp (audio stream) + VLC (headless).
        Stop current track if running.
        """
        # Global or Class-level player tracking would be better, but for now:
        if hasattr(self, 'current_player') and self.current_player:
            self.current_player.stop()

        print(f"{Fore.MAGENTA}🎵 [MUSIC] Searching: {query}")
        config.speech_queue.put(f"Queuing {query} from the cloud...")

        def _play_thread():
            try:
                ydl_opts = {
                    'format': 'bestaudio/best',
                    'noplaylist': True,
                    'quiet': True,
                    'default_search': 'ytsearch',
                }
                
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    info = ydl.extract_info(query, download=False)
                    if 'entries' in info:
                        info = info['entries'][0]
                    
                    audio_url = info['url']
                    title = info.get('title', query)
                    
                    print(f"{Fore.MAGENTA}▶️ [PLAYING] {title}")
                    config.speech_queue.put(f"Now playing: {title}")
                    
                    # Initialize VLC
                    instance = vlc.Instance('--no-video')
                    player = instance.media_player_new()
                    media = instance.media_new(audio_url)
                    player.set_media(media)
                    
                    player.play()
                    self.current_player = player # Keep reference
                    
                    # Wait for track to finish (optional loop for daemon thread)
                    # For now, just let it play in background. 
                    # Note: If this thread dies, player might stop depending on GC.
                    # We store it in self.current_player to keep it alive.
            
            except Exception as e:
                print(f"Music Error: {e}")
                config.speech_queue.put("I couldn't stream that track.")

        threading.Thread(target=_play_thread, daemon=True).start()
