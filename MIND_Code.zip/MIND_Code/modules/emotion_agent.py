import cv2
import config
from colorama import Fore

# Optional Import
try:
    from deepface import DeepFace
    HAS_DEEPFACE = True
except ImportError:
    HAS_DEEPFACE = False
    print(f"{Fore.RED}⚠️ [EMOTION] DeepFace not installed. Emotion detection disabled.")

class EmotionAgent:
    def detect_mood(self):
        """Analyzes facial expression via Webcam."""
        if not HAS_DEEPFACE:
            return "Emotion module not active."
            
        print(f"{Fore.MAGENTA}🎭 [EMOTION] Scanning Expression...")
        config.hud_queue.put("EMO: SCANNING FACIAL CUES")
        
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()
        
        if not ret: return "Camera error."
        
        try:
            # DeepFace analyze
            # We use a temp file or pass numpy array directly if supported (it is)
            results = DeepFace.analyze(frame, actions=['emotion'], enforce_detection=False)
            
            # Results is a list in newer versions
            if isinstance(results, list):
                dom_emotion = results[0]['dominant_emotion']
            else:
                dom_emotion = results['dominant_emotion']
                
            print(f"{Fore.GREEN}🎭 Detected: {dom_emotion}")
            return dom_emotion
        except Exception as e:
            return f"Error analyzing emotion: {e}"

    def adaptive_response(self, mood):
        """Returns a system response modifier based on mood."""
        mood = mood.lower()
        if mood in ["sad", "fear", "angry"]:
            return "I sense distress. Switching to Gentle Mode. Playing calming music?"
        elif mood in ["happy", "surprise"]:
            return "You seem energetic! Let's get to work."
        else:
            return "Systems nominal."
