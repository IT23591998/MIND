import os
import subprocess
import webbrowser
import config  # Imports your APP_LIBRARY and queues

class SystemNavigator:
    def __init__(self):
        # We don't strictly need the Brain for simple navigation (opening apps),
        # so we skip initializing it here to save speed.
        pass

    def execute(self, user_text):
        # 1. CLEANUP TEXT
        clean_text = user_text.lower()
        for char in [",", ".", "!", "?", "'"]:
            clean_text = clean_text.replace(char, "")
            
        target = clean_text
        for word in ["mind", "open", "launch", "go to", "search", "please"]:
            target = target.replace(word, "")
        
        target = target.strip()
        target = target.replace("you tube", "youtube")
        target = target.replace("face book", "facebook")
        target = target.replace("chat gpt", "chatgpt")

        # 2. WEB MAPPING
        web_map = {
            "youtube": "www.youtube.com",
            "google": "www.google.com",
            "github": "www.github.com",
            "canvas": "courseweb.sliit.lk/",
            "chatgpt": "chat.openai.com",
            "gmail": "mail.google.com"
        }

        # 3. APP LAUNCH CHECK (Using config.APP_LIBRARY)
        if target in config.APP_LIBRARY:
            config.speech_queue.put(f"Launching {target}.")
            subprocess.Popen(config.APP_LIBRARY[target])
            return True
            
        # 4. DIRECT SITE CHECK
        if target in web_map:
            config.speech_queue.put(f"Opening {target}.")
            webbrowser.open(f"https://{web_map[target]}")
            return True
            
        # 5. FUZZY SITE CHECK
        for key in web_map:
            if key in target:
                config.speech_queue.put(f"Opening {key}.")
                webbrowser.open(f"https://{web_map[key]}")
                return True
        
        # 0. DRIVE MAPPING (New)
        # 0. DRIVE & FOLDER MAPPING
        # Pattern: "ossa folder in e drive" -> target="ossa folder in e drive"
        drive_letter = None
        search_target = None

        # detection logic for "in X drive"
        import re
        match = re.search(r"in\s+(\w)\s*drive", target)
        if match:
            drive_letter = match.group(1).upper()
            # Everything before "in" matches the folder name
            search_target = target.split("in ")[0].replace("folder", "").strip()
        elif "drive" in target:
             # "open e drive"
             possible_letter = target.replace("drive", "").strip().upper()
             if len(possible_letter) == 1 and possible_letter.isalpha():
                 drive_letter = possible_letter

        if drive_letter:
            drive_root = f"{drive_letter}:\\"
            if os.path.exists(drive_root):
                
                # If we have a specific folder to look for
                if search_target:
                    config.speech_queue.put(f"Searching for {search_target} in {drive_letter} Drive...")
                    found = False
                    
                    # 1. PRIORITY: Check for Directories first
                    try:
                        for item in os.listdir(drive_root):
                            full_path = os.path.join(drive_root, item)
                            # Logic: If user specifically asked for "folder", prioritize is_dir
                            if search_target.lower() in item.lower() and os.path.isdir(full_path):
                                config.speech_queue.put(f"Opening folder {item}")
                                os.startfile(full_path)
                                return True
                    except: pass
                    
                    # 2. SECONDARY: Check for Files (only if folder not strictly requested or not found)
                    # If user said "folder", we should perhaps SKIP files or try them as fallback?
                    # User: "open OSSA folder", System opened "OSSA Lecture.pptx".
                    # Fix: If "folder" in target, strict directory check?
                    # Let's keep file fallback but prioritize exact directory match above.
                    
                    if not found:
                         try:
                            for item in os.listdir(drive_root):
                                if search_target.lower() in item.lower():
                                    full_path = os.path.join(drive_root, item)
                                    # If it's a file but we wanted a folder, maybe warn? 
                                    # But often users say "folder" for a zip or just mixed up terms.
                                    # Let's just open it as fallback.
                                    config.speech_queue.put(f"Opening {item}")
                                    os.startfile(full_path)
                                    return True
                         except: pass

                    if not found:
                        config.speech_queue.put(f"Item not found. Opening {drive_letter} Drive root.")
                        os.startfile(drive_root)
                        return True

                else:
                    # Just open drive
                    config.speech_queue.put(f"Opening {drive_letter} Drive.")
                    os.startfile(drive_root)
                    return True

        # 0.5 GENERIC PATH CHECK
        # Check if the target is a valid path string like "D:/MIND_Project"
        if os.path.exists(target):
             config.speech_queue.put(f"Opening {os.path.basename(target)}")
             os.startfile(target)
             return True

        # 5.5 DEFAULT LOCAL SEARCH (Project & D: Drive)
        # If no specific drive mentioned, search default locations
        if not drive_letter:
            search_paths = [r"D:\MIND_Project", r"D:\\"]
            target_clean = target.replace("folder", "").strip()
            
            for search_root in search_paths:
                if os.path.exists(search_root):
                    config.speech_queue.put(f"Searching {search_root} for {target_clean}...")
                    try:
                        # Priority 1: Exact-ish Match on Directories
                        for item in os.listdir(search_root):
                            full_path = os.path.join(search_root, item)
                            if target_clean.lower() in item.lower():
                                # If user said "folder", prefer directories
                                if "folder" in target and os.path.isdir(full_path):
                                    config.speech_queue.put(f"Found folder {item}")
                                    os.startfile(full_path)
                                    return True
                                # If user didn't specify or we are loose, open whatever matches
                                elif "folder" not in target:
                                    config.speech_queue.put(f"Found {item}")
                                    os.startfile(full_path)
                                    return True
                    except: pass
            
            # Additional Pass: If "folder" was specified but we ignored files above, maybe check files now?
            # Or assume if they said folder they meant it. 
            # Let's keep it simple: The loop above handles strict folder preference if "folder" is in string.

        # 6. FALLBACK GOOGLE SEARCH
        config.speech_queue.put(f"Searching Google for {target}.")
        webbrowser.open(f"https://www.google.com/search?q={target}")
        return True