import os
import cv2
import numpy as np
import config
from colorama import Fore

# Optional import
try:
    import face_recognition
    HAS_FR = True
except ImportError:
    HAS_FR = False
    print(f"{Fore.RED}⚠️ [BIOMETRIC] 'face_recognition' not installed. Face ID disabled.")

class BiometricAgent:
    def __init__(self):
        self.admin_face_path = os.path.join(config.ASSETS_DIR, "admin_face.npy")
        self.known_face_encoding = None
        self._load_admin_face()

    def _load_admin_face(self):
        if os.path.exists(self.admin_face_path):
            try:
                self.known_face_encoding = np.load(self.admin_face_path)
                print(f"{Fore.GREEN}👁️ [BIOMETRIC] Admin Face Loaded.")
            except:
                print(f"{Fore.RED}⚠️ [BIOMETRIC] Corrupt face data.")

    def scan_face(self):
        """
        Captures one frame and checks against admin face.
        Returns: True (Match), False (No Match), or None (No Face Found/Error)
        """
        if not HAS_FR: return True # Bypass if module missing (Dev Mode)
        
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return None # No camera

        ret, frame = cap.read()
        cap.release()
        
        if not ret: return None

        # Convert BGR (OpenCV) to RGB (face_recognition)
        rgb_frame = frame[:, :, ::-1]
        
        face_locations = face_recognition.face_locations(rgb_frame)
        if not face_locations:
            return None # No face detection
            
        encodings = face_recognition.face_encodings(rgb_frame, face_locations)
        
        if not self.known_face_encoding is not None:
            return False # Admin not registered

        for encoding in encodings:
            matches = face_recognition.compare_faces([self.known_face_encoding], encoding)
            if True in matches:
                return True
                
        return False

    def register_admin(self):
        """Captures current user as Admin."""
        if not HAS_FR: return "Module missing."
        
        print(f"{Fore.CYAN}👁️ [BIOMETRIC] Look at camera...")
        config.speech_queue.put("Look at the camera for ID registration.")
        
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()
        
        if not ret: return "Camera error."

        rgb_frame = frame[:, :, ::-1]
        encodings = face_recognition.face_encodings(rgb_frame)
        
        if not encodings:
            return "No face detected."
            
        self.known_face_encoding = encodings[0]
        np.save(self.admin_face_path, self.known_face_encoding)
        return "Admin Face Registered."
