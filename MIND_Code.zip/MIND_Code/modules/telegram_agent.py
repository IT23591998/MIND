import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, CommandHandler, MessageHandler, filters
import threading
import asyncio
import nest_asyncio
import config
import os
import psutil

# Allow nested event loops (crucial for running inside MIND's loop)
nest_asyncio.apply()

class TelegramAgent:
    def __init__(self):
        # We look for token in Env or Config. For now, placeholder.
        self.token = os.getenv("TELEGRAM_BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID", None) # For pushing alerts
        
        self.application = None
        self.running = False
        self.lock_file = "telegram_agent.lock"

        # Check for existing lock
        if self._is_locked():
            print("⚠️ [TELEGRAM] Duplicate Instance Detected (Lock File Exists). Aborting start.")
            return

        # Only start if token is present
        if "YOUR_BOT" not in self.token:
            self._create_lock()
            self._start_bot_thread()
        else:
            print("⚠️ [TELEGRAM] Token not set. Remote access disabled.")

    def _is_locked(self):
        """Checks if a valid lock exists for another running process."""
        if os.path.exists(self.lock_file):
            try:
                with open(self.lock_file, "r") as f:
                    pid = int(f.read().strip())
                
                # Check if this PID is running
                if psutil.pid_exists(pid):
                    print(f"⚠️ [TELEGRAM] Existing instance found at PID: {pid}")
                    return True
                else:
                    print(f"⚠️ [TELEGRAM] Found stale lock from PID {pid}. Overwriting.")
                    return False
            except Exception as e:
                print(f"⚠️ [TELEGRAM] Lock read error: {e}. Overwriting.")
                return False
        return False

    def _create_lock(self):
        """Creates a lock file with current PID."""
        try:
            with open(self.lock_file, "w") as f:
                f.write(str(os.getpid()))
        except Exception as e:
            print(f"⚠️ [TELEGRAM] Could not create lock file: {e}")

    def _remove_lock(self):
        """Removes the lock file."""
        if os.path.exists(self.lock_file):
            try:
                os.remove(self.lock_file)
            except: pass

    def __del__(self):
        self._remove_lock()

    def _start_bot_thread(self):
        self.running = True
        self.thread = threading.Thread(target=self._run_bot, daemon=True)
        self.thread.start()

    def _run_bot(self):
        # Setup Bot
        self.application = ApplicationBuilder().token(self.token).build()
        
        # Handlers
        start_handler = CommandHandler('start', self.start)
        msg_handler = MessageHandler(filters.TEXT & (~filters.COMMAND), self.handle_message)
        
        self.application.add_handler(start_handler)
        self.application.add_handler(msg_handler)
        
        print("📱 [TELEGRAM] Listening...")
        
        from telegram.error import Conflict
        
        async def global_error_handler(update, context):
            if isinstance(context.error, Conflict):
                print("⚠️ [TELEGRAM] Critical Conflict: Another instance is operational. Shutting down remote link.")
                # We can't easily stop the loop from here without being in the loop context or raising
                self.running = False
                self._remove_lock() # Release lock on conflict too? Maybe not if other is real.
                # Actually, if we are the second one and we crash, we should cleanup OUR lock if we made it? 
                # But we wouldn't have made it past init if we checked correctly. 
                # Conflict usually happens if logic failed or race condition.
                raise context.error
            else:
                print(f"⚠️ [TELEGRAM] Error: {context.error}")

        self.application.add_error_handler(global_error_handler)

        try:
            asyncio.run(self.application.run_polling())
        except Conflict:
            print("⚠️ [TELEGRAM] Remote Access Disabled (Conflict Detected).")
            self.running = False
            self._remove_lock()
        except Exception as e:
            print(f"⚠️ [TELEGRAM] Connection Error: {e}")


    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await context.bot.send_message(chat_id=update.effective_chat.id, text="MIND Online. Awaiting commands.")
        # Auto-save chat ID for alerts
        self.chat_id = update.effective_chat.id

    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        text = update.message.text
        # We can push this to the Main Loop via a queue if we want MIND to execute it
        # For now, simple echo or specific remote commands
        response = f"Received: {text}"
        
        if "status" in text.lower():
            # Quick status check
            response = "System Nominal. CPU <Check Monitor>."
            
        await context.bot.send_message(chat_id=update.effective_chat.id, text=response)

    def send_alert(self, message):
        """Sends a message to the user."""
        if self.chat_id and self.application:
            # This needs to be thread-safe/async safe. 
            # In a real app, we'd use the loop properly. 
            # For this prototype, we print intent.
            print(f"📱 [TELEGRAM] Alert: {message}")
            # Actual implementation requires accessing the event loop of the bot
