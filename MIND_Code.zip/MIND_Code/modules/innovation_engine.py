from modules.meta_reasoning import MetaLogEntry
from mind_brain import MindBrain
from colorama import Fore

class InnovationEngine:
    """
    A specialized creative engine using SCAMPER and TRIZ frameworks
    to generate novel ideas and predictions.
    """
    
    def __init__(self, brain_instance=None):
        self.brain = brain_instance if brain_instance else MindBrain()

    def brainstorm(self, topic: str):
        """
        Applies SCAMPER framework to a topic.
        """
        print(Fore.MAGENTA + f"💡 [INNOVATION] Brainstorming on: {topic}")
        
        prompt = f"""
        [SYSTEM: You are the THEORIST, a highly creative innovation engine.]
        [TASK: Apply the SCAMPER method to generate 7 novel ideas for '{topic}'.]
        
        Structure your response exactly like this:
        1. Substitute: (Idea)
        2. Combine: (Idea)
        3. Adapt: (Idea)
        4. Modify: (Idea)
        5. Put to another use: (Idea)
        6. Eliminate: (Idea)
        7. Reverse: (Idea)
        
        Focus on futuristic, high-tech, and 'crazy' implementations.
        """
        
        log_entry = self.brain.think_with_meta(prompt)
        return log_entry.final_response

    def predict_future(self, topic: str, years: int = 10):
        print(Fore.MAGENTA + f"🔮 [INNOVATION] Predicting {years} years into the future for: {topic}")
        
        prompt = f"""
        [SYSTEM: You are the THEORIST. Extrapolate technology trends.]
        [TASK: Predict the evolution of '{topic}' over the next {years} years.]
        
        Provide:
        1. Technical Breakdown (Hardware/Software changes)
        2. Societal Impact
        3. Probability Score (0-100%)
        """
        
        log_entry = self.brain.think_with_meta(prompt)
        return log_entry.final_response
