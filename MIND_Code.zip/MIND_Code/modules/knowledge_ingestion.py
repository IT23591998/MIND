import os
import json
import time
from dataclasses import dataclass, field
from typing import List, Dict, Optional

# Optional PDF support
try:
    from pypdf import PdfReader
    HAS_PDF = True
except ImportError:
    try:
        from PyPDF2 import PdfReader
        HAS_PDF = True
    except ImportError:
        HAS_PDF = False

@dataclass
class KnowledgeEntry:
    content: str
    source: str
    timestamp: str = field(default_factory=lambda: time.strftime("%Y-%m-%d %H:%M:%S"))
    confidence: float = 1.0
    metadata: Dict = field(default_factory=dict)

class KnowledgeIngestion:
    """
    Handles reading and parsing of offline files for the Knowledge Base.
    """
    
    def __init__(self):
        self.supported_extensions = ['.txt', '.md', '.json', '.csv']
        if HAS_PDF:
            self.supported_extensions.append('.pdf')
            
    def ingest_directory(self, directory_path: str) -> List[KnowledgeEntry]:
        """
        Recursively scans a directory and extracts knowledge entries.
        """
        entries = []
        if not os.path.exists(directory_path):
            print(f"⚠️ [INGEST] Directory not found: {directory_path}")
            return entries

        print(f"📥 [INGEST] Scanning {directory_path}...")
        
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                file_path = os.path.join(root, file)
                ext = os.path.splitext(file)[1].lower()
                
                if ext in self.supported_extensions:
                    try:
                        entry = self._process_file(file_path, ext)
                        if entry:
                            entries.append(entry)
                    except Exception as e:
                        print(f"❌ [INGEST] Error processing {file}: {e}")
                        
        print(f"✅ [INGEST] Processed {len(entries)} documents.")
        return entries

    def _process_file(self, file_path: str, ext: str) -> Optional[KnowledgeEntry]:
        content = ""
        source_name = os.path.basename(file_path)
        
        # 1. Text / Markdown
        if ext in ['.txt', '.md']:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
        # 2. JSON (Structured Knowledge)
        elif ext == '.json':
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # Flexible parsing: try to find useful content fields
                if isinstance(data, list):
                    content = "\n".join([str(item) for item in data])
                elif isinstance(data, dict):
                    # Prefer explicit 'content' or 'text' keys
                    content = data.get('content', data.get('text', json.dumps(data, indent=2)))
                else:
                    content = str(data)

        # 3. PDF (If supported)
        elif ext == '.pdf' and HAS_PDF:
            reader = PdfReader(file_path)
            pages = []
            for page in reader.pages:
                text = page.extract_text()
                if text:
                    pages.append(text)
            content = "\n".join(pages)
            
        # 4. CSV (Simple)
        elif ext == '.csv':
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

        if not content.strip():
            return None

        # Determine Confidence using Trusted Sources heuristics
        confidence = self._calculate_confidence(source_name)
        
        return KnowledgeEntry(
            content=content,
            source=source_name,
            confidence=confidence,
            metadata={"path": file_path, "type": ext}
        )

    def _calculate_confidence(self, source_name: str) -> float:
        """
        Assigns confidence based on filename keywords (Simple Heuristic).
        """
        lower_name = source_name.lower()
        
        # High Confidence Keywords
        trusted_keywords = ['nasa', 'mit', 'nist', 'ieee', 'textbook', 'paper', 'verified', 'ocw']
        if any(k in lower_name for k in trusted_keywords):
            return 1.0 # Boost to Max for explicitly trusted files
            
        # Medium Confidence
        if 'guide' in lower_name or 'manual' in lower_name:
            return 0.9
            
        # Default
        return 0.8
