import os
import subprocess
import requests
import json
import socket
import datetime
from colorama import Fore
import config  # Importing the central nervous system
from mind_brain import MindBrain

class SecurityAgent:
    def __init__(self):
        self.brain = MindBrain()
        self.nmap_path = self.find_nmap()
        self.nuclei_path = self.find_nuclei()
        self.john_path = self.find_john()

    def find_john(self):
        """Smart detection of John the Ripper executable."""
        # Common paths or relative paths in project
        paths = [
            r"C:\JohnTheRipper\run\john.exe",
            r"D:\MIND_Project\Tools\JohnTheRipper\run\john.exe",
            r"D:\MIND_Project\john\run\john.exe",
            r"D:\MIND_Project\john-1.9.0-jumbo-1-win64\john-1.9.0-jumbo-1-win64\run\john.exe",
            os.path.expanduser("~/john/run/john.exe")
        ]
        for p in paths:
            if os.path.exists(p): return p
        return None

    def find_nuclei(self):
        """Smart detection of Nuclei executable."""
        paths = [
            r"C:\Users\tmage\go\bin\nuclei.exe",
            r"D:\MIND_Project\Go\bin\nuclei.exe",
            os.path.expanduser("~/go/bin/nuclei.exe"),
            os.path.join(os.environ.get("GOPATH", ""), "bin", "nuclei.exe")
        ]
        for p in paths:
            if os.path.exists(p): return p
        return None

    def find_nmap(self):
        """Smart detection of Nmap executable."""
        paths = [
            r"C:\Program Files (x86)\Nmap\nmap.exe",
            r"C:\Program Files\Nmap\nmap.exe",
            r"D:\MIND_Project\Go\bin\nmap.exe", # Current fallback
            os.path.expanduser("~/nmap/nmap.exe")
        ]
        for p in paths:
            if os.path.exists(p): return p
        return None

    def geoip_track(self, target):
        """
        Traces an IP or Domain to a physical location.
        """
        print(f"{Fore.RED}🛰️ [SECURITY] Tracking Target: {target}")
        config.speech_queue.put(f"Tracing location of {target}...")

        try:
            # Resolve domain to IP if needed
            ip = socket.gethostbyname(target)
            
            # Use ip-api (Free, no key needed for non-commercial)
            response = requests.get(f"http://ip-api.com/json/{ip}")
            data = response.json()

            if data['status'] == 'success':
                country = data.get('country', 'Unknown')
                region = data.get('regionName', 'Unknown')
                city = data.get('city', 'Unknown')
                isp = data.get('isp', 'Unknown')
                
                report = f"Target located in {city}, {region}, {country}. ISP is {isp}."
                print(f"{Fore.GREEN}📍 {report}")
                config.speech_queue.put(report)
            else:
                config.speech_queue.put("Tracking failed. IP is hidden.")

        except Exception as e:
            print(f"GeoIP Error: {e}")
            config.speech_queue.put("Tracking connection failed.")

    def recon_scan(self, target):
        """
        Runs Nmap Port Scan + AI Vulnerability Analysis.
        """
        if not self.nmap_path:
            config.speech_queue.put("I cannot find Nmap on this system. Install it to enable scanning.")
            print(f"{Fore.RED}❌ Nmap not found. Install from https://nmap.org/download.html")
            return

        print(f"{Fore.RED}⚔️ [SECURITY] Engaging Active Recon: {target}")
        config.speech_queue.put(f"Initiating port scan on {target}. Stand by.")
        
        try:
            # Run Nmap (Fast Scan -F)
            # cmd = [self.nmap_path, "-F", target]
            cmd = [self.nmap_path, "-p", "1-1000", "-T4", target] # Scan top 1000 ports fast
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            scan_data = result.stdout

            report_path = os.path.join(config.BASE_PATH, "security_report.txt")
            with open(report_path, "w") as f: 
                f.write(scan_data)

            if "open" in scan_data:
                # Extract open ports count rough est
                open_ports = scan_data.count("open")
                print(f"{Fore.YELLOW}⚠️ FOUND {open_ports} OPEN PORTS")
                
                # 🧠 CLOUD BRAIN ANALYSIS
                analysis = self.brain.think(
                    f"Analyze this Nmap output for a CTF/Pentest. Be concise. What are the vectors? \n\n{scan_data}", 
                    system_role="Red Team Cybersecurity Expert"
                )
                
                # Speak summary
                config.speech_queue.put(f"Scan complete. Found {open_ports} open ports. {analysis[:100]}")
            else:
                config.speech_queue.put("Scan complete. Target appears legally secure.")
                
        except Exception as e:
            print(f"Scan Error: {e}")
            config.speech_queue.put("Scanner malfunction.")

    def osint_scan(self, username):
        """
        Checks if a username exists on major platforms.
        """
        print(f"{Fore.RED}🕵️ [SECURITY] OSINT User Check: {username}")
        config.speech_queue.put(f"Searching for identity {username}...")

        sites = {
            "GitHub": f"https://github.com/{username}",
            "Reddit": f"https://www.reddit.com/user/{username}",
            "Instagram": f"https://www.instagram.com/{username}/",
            "X (Twitter)": f"https://twitter.com/{username}"
        }

        found = []
        for site, url in sites.items():
            try:
                r = requests.get(url, timeout=3)
                if r.status_code == 200:
                    found.append(site)
                    print(f"{Fore.GREEN}   [+] Found on {site}")
            except: pass
        
        if found:
            res_str = ", ".join(found)
            config.speech_queue.put(f"Target found on: {res_str}.")
        else:
            config.speech_queue.put("No public profiles found for this alias.")

    # --- BUG BOUNTY FEATURES ---
    
    def subdomain_enum(self, domain):
        """
        Uses crt.sh to find subdomains.
        """
        print(f"{Fore.CYAN}🔍 [HUNT] Enumerating Subdomains for {domain}...")
        try:
            url = f"https://crt.sh/?q=%.{domain}&output=json"
            r = requests.get(url, timeout=10)
            if r.status_code != 200: return []
            
            data = r.json()
            subs = set()
            for entry in data:
                name = entry['name_value']
                # Clean up newlines
                for sub in name.split('\n'):
                    if domain in sub: subs.add(sub)
            return list(subs)
        except Exception as e:
            print(f"Subdomain Error: {e}")
            return []

    def web_probe(self, url):
        """
        Checks for basic misconfigurations.
        """
        if not url.startswith("http"): url = "http://" + url
        issues = []
        
        try:
            r = requests.get(url, timeout=3)
            headers = r.headers
            
            # 1. Missing Security Headers
            if "X-Frame-Options" not in headers: issues.append("Missing X-Frame-Options (Clickjacking)")
            if "Content-Security-Policy" not in headers: issues.append("Missing CSP (XSS Risk)")
            
            # 2. Sensitive Files (Quick Check)
            vuln_files = [".env", ".git/HEAD", "wp-config.php.bak"]
            for vmod in vuln_files:
                check_url = f"{url}/{vmod}"
                rv = requests.get(check_url, timeout=2)
                if rv.status_code == 200:
                    issues.append(f"CRITICAL: Exposed File {vmod}")

            return issues
        except:
            return []

    def nuclei_scan(self, target):
        """
        Runs Nuclei for advanced vulnerability scanning.
        """
        if not self.nuclei_path:
            return "Nuclei not installed."
            
        print(f"{Fore.MAGENTA}☢️ [HUNT] Engaging Nuclei Scanner on {target}...")
        try:
            # Run Nuclei (Medium+ severity only for speed)
            cmd = [self.nuclei_path, "-target", target, "-severity", "critical,high,medium", "-json", "-silent"]
            result = subprocess.run(cmd, capture_output=True, text=True)
            return result.stdout
        except Exception as e:
            print(f"Nuclei Error: {e}")
            return None

    def bounty_hunt(self, target):
        """
        The 'Give me Money' command.
        """
        print(f"{Fore.RED}👺 [HUNT] Stalking Target: {target}")
        config.speech_queue.put(f"Starting Bug Bounty recon on {target}.")

        # 1. Subdomains
        subs = self.subdomain_enum(target)
        if len(subs) > 5:
            # Limit to 5 for demo speed
            target_list = list(subs)[:5] 
            config.speech_queue.put(f"Found {len(subs)} subdomains. Probing top 5.")
        else:
            target_list = [target]

        findings = {}
        nuclei_hits = []
        
        # 2. Probe & Nuclei
        for t in target_list:
            print(f"   -> Probing {t}...")
            # A. Basic Probe
            issues = self.web_probe(t)
            if issues: findings[t] = issues
            
            # B. Nuclei Scan (If installed)
            if self.nuclei_path:
                n_res = self.nuclei_scan(t)
                if n_res and len(n_res) > 5:
                    nuclei_hits.append(f"Nuclei found vulnerabilities on {t}.")
            
        # 3. Report
        combined_findings = bool(findings) or bool(nuclei_hits)
        
        if combined_findings:
            print(f"{Fore.YELLOW}⚠️ VULNERABILITIES FOUND!")
            report_text = json.dumps(findings, indent=2)
            nuclei_text = "\n".join(nuclei_hits)
            
            # Ask Brain to make it sound professional
            prompt = f"Write a HackerOne-style vulnerability report.\nTarget: {target}\n\nManual Findings:\n{report_text}\n\nNuclei Findings:\n{nuclei_text}\n\nInclude: Impact, Severity, and Recommended Fix."
            advice = self.brain.think(prompt, system_role="Bug Bounty Hunter")
            
            config.speech_queue.put(f"Potential bounties detected. Report generated.")
            
            # Save Report with Timestamp
            reports_dir = os.path.join(config.BASE_PATH, "reports")
            if not os.path.exists(reports_dir): os.makedirs(reports_dir)
            
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"BountyReport_{target}_{timestamp}.md"
            file_path = os.path.join(reports_dir, filename)
            
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(f"# 🛡️ MIND SECURITY REPORT\n")
                f.write(f"**Target:** {target}\n")
                f.write(f"**Date:** {timestamp}\n\n")
                f.write(advice)
                f.write(f"\n\n---\n**Raw Data:**\n```json\n{report_text}\n```\n")
                f.write(f"**Nuclei Output:**\n```\n{nuclei_text}\n```")
                
            print(f"{Fore.GREEN}📄 [SAVED] Report at: {file_path}")
            # Auto-open the report
            os.startfile(reports_dir)
                
        else:
            config.speech_queue.put("Target seems hardened. No obvious vulnerabilities found.")

    # --- JOHN THE RIPPER INTEGRATION ---
    def crack_hash(self, hash_string):
        """
        Attempts to crack a hash using JtR.
        """
        if not self.john_path:
            return "John the Ripper is not installed. Please download it."

        print(f"{Fore.RED}🔨 [CRACK] Attempting to crack hash...")
        config.speech_queue.put("Starting password cracking sequence.")

        # 1. Save hash to file
        hash_file = os.path.join(config.BASE_PATH, "target_hash.txt")
        with open(hash_file, "w") as f:
            f.write(hash_string)

        # 2. Run John (Auto mode)
        # Timeout set to 60s for demo purposes to avoid hanging
        # cmd: john target_hash.txt
        cmd = [self.john_path, hash_file]
        
        try:
            # Check for potential pot file to see if already cracked
            subprocess.run(cmd, timeout=5, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Show password (john --show target_hash.txt)
            show_cmd = [self.john_path, "--show", hash_file]
            result = subprocess.run(show_cmd, capture_output=True, text=True)
            
            output = result.stdout
            # valid output usually: "password (user)" or "1 password hash cracked"
            if "0 password hashes cracked" in output:
                return "Password not found in dictionary."
            
            # Basic parsing
            # Output format often: hash:password
            lines = output.strip().split('\n')
            for line in lines:
                if ":" in line:
                    return f"Cracked: {line.split(':')[1]}"
            
            return f"Job done. Output: {output}"
            
        except subprocess.TimeoutExpired:
            return "Cracking took too long. Stopping."
        except Exception as e:
            return f"Cracking error: {e}"