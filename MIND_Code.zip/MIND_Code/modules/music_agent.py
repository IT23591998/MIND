try:
    import vlc
    VLC_AVAILABLE = True
except ImportError:
    VLC_AVAILABLE = False

import yt_dlp
import time
import threading
from colorama import Fore

class MusicAgent:
    """
    Plays audio from YouTube using VLC Media Player (Backend).
    Requires: VLC installed on OS, python-vlc, yt-dlp.
    """
    
    def __init__(self):
        if VLC_AVAILABLE:
            try:
                self.instance = vlc.Instance('--no-video')
                self.player = self.instance.media_player_new()
            except Exception as e:
                print(Fore.RED + f"⚠️ [MUSIC] VLC Init Failed: {e}")
                self.player = None
        else:
            self.player = None
            print(Fore.YELLOW + "⚠️ [MUSIC] VLC not found. Music playback disabled.")
            
        self.current_song = None
        self.is_playing = False

    def play(self, query):
        """
        Searches YouTube for 'query' and plays the best audio stream.
        """
        if not VLC_AVAILABLE or not self.player:
            print(Fore.RED + "❌ [MUSIC] VLC not available.")
            return {"error": "VLC not available"}

        print(Fore.MAGENTA + f"🎵 [MUSIC] Searching for: {query}...")
        
        ydl_opts = {
            'format': 'bestaudio/best',
            'noplaylist': True,
            'quiet': True,
            'default_search': 'ytsearch',
            'extract_flat': False,
        }

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(query, download=False)
                
                if 'entries' in info:
                    # It's a search result
                    video = info['entries'][0]
                else:
                    video = info

                url = video['url']
                title = video.get('title', 'Unknown Track')
                duration = video.get('duration', 0)
                
                print(Fore.MAGENTA + f"🎵 [MUSIC] Now Playing: {title}")
                
                # Stop existing playback
                if self.player.is_playing():
                    self.player.stop()

                # Load media
                media = self.instance.media_new(url)
                self.player.set_media(media)
                self.player.play()
                
                self.current_song = title
                self.is_playing = True
                return {"status": "playing", "title": title}

        except Exception as e:
            print(Fore.RED + f"🎵 [MUSIC] Error: {e}")
            return {"error": str(e)}

    def stop(self):
        if self.player:
            self.player.stop()
        self.is_playing = False
        print(Fore.MAGENTA + "🎵 [MUSIC] Stopped.")

    def pause(self):
        if self.player:
            self.player.pause()
        print(Fore.MAGENTA + "🎵 [MUSIC] Paused.")

    def resume(self):
        if self.player:
            self.player.play()
        print(Fore.MAGENTA + "🎵 [MUSIC] Resumed.")

    def set_volume(self, volume):
        # VLC volume is 0-100
        if self.player:
            self.player.audio_set_volume(int(volume))
        print(Fore.MAGENTA + f"🎵 [MUSIC] Volume set to {volume}%")
