import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
import config
from colorama import Fore

class CareerAgent:
    def __init__(self):
        self.ua = UserAgent()

    def scan_github_trending(self, lang="python"):
        """Scrapes GitHub Trending."""
        print(f"{Fore.CYAN}💼 [CAREER] Scouting GitHub Trending ({lang})...")
        config.hud_queue.put(f"MKT: SCOUTING GITHUB ({lang})")
        
        url = f"https://github.com/trending/{lang}?since=daily"
        headers = {'User-Agent': self.ua.random}
        
        try:
            r = requests.get(url, headers=headers)
            if r.status_code != 200:
                print(r.status_code)
                return "Failed to fetch GitHub trending."
            
            soup = BeautifulSoup(r.text, 'html.parser')
            repos = []
            
            # Select repo rows
            articles = soup.select('article.Box-row')
            
            for article in articles[:5]: # Top 5
                try:
                    name = article.select_one('h2 a').get_text(strip=True).replace(" ", "").replace("\n", "")
                    desc_tag = article.select_one('p')
                    desc = desc_tag.get_text(strip=True) if desc_tag else "No description"
                    star_tag = article.select_one('a.Link--muted')
                    stars = star_tag.get_text(strip=True) if star_tag else "?"
                    
                    repos.append(f"⭐ {stars} | {name}: {desc[:50]}...")
                except: continue
                
            report = "\n".join(repos)
            
            # Simple Logic: If popular -> Add to Knowledge Base? (Simulated)
            # config.knowledge_queue.put(report) 
            
            return f"Top Trend:\n{report}"
            
        except Exception as e:
            return f"Scout failed: {e}"
