import os
import requests
import config 
from mind_brain import MindBrain

class IntelligenceAgent:
    def __init__(self):
        # Initialize Brain ONCE here
        self.brain = MindBrain()

    def track_username(self, username):
        config.hud_queue.put(f"OSINT: {username}")
        config.speech_queue.put(f"Hunting for {username}...")
        
        sites = {
            "GitHub": f"https://github.com/{username}",
            "Instagram": f"https://www.instagram.com/{username}/",
            "Reddit": f"https://www.reddit.com/user/{username}",
            "Twitch": f"https://www.twitch.tv/{username}",
            "Medium": f"https://medium.com/@{username}",
            "Patreon": f"https://www.patreon.com/{username}",
            "GitLab": f"https://gitlab.com/{username}",
            "Pinterest": f"https://www.pinterest.com/{username}/"
        }
        
        found = []
        # Use the path from config.py
        filename = os.path.join(config.OSINT_DIR, f"{username}_report.txt")
        
        try:
            with open(filename, "w") as f:
                f.write(f"--- MIND v14.0 OSINT REPORT: {username} ---\n")
                
                # Browser Headers to avoid getting blocked
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
                
                for platform, url in sites.items():
                    try:
                        r = requests.get(url, headers=headers, timeout=5)
                        if r.status_code == 200:
                            f.write(f"[+] FOUND: {platform} -> {url}\n")
                            found.append(platform)
                        else:
                            f.write(f"[-] 404: {platform}\n")
                    except:
                        f.write(f"[!] ERR: {platform}\n")
            
            if found:
                config.speech_queue.put(f"Trace complete. Found accounts on {len(found)} platforms.")
                try:
                    os.startfile(filename)
                except: pass
            else:
                config.speech_queue.put("Trace complete. No public accounts found.")
                
        except Exception as e:
            print(f"OSINT Error: {e}")
            config.speech_queue.put("OSINT write error.")