import os
import requests
from bs4 import BeautifulSoup
from googlesearch import search
from colorama import Fore
import config
from mind_brain import MindBrain

class ResearchAgent:
    def __init__(self):
        self.brain = MindBrain()
        self.reports_dir = os.path.join(config.BASE_PATH, "reports")
        if not os.path.exists(self.reports_dir):
            os.makedirs(self.reports_dir)

    def research_topic(self, topic):
        """
        Conducts deep research on a topic and writes a report.
        """
        print(f"{Fore.CYAN}📚 [RESEARCH] Investigating: {topic}")
        config.speech_queue.put(f"Starting deep research on {topic}. This may take a moment.")
        config.hud_queue.put("RESEARCH: SEARCHING")
        context_data = ""


        # 0. Wikipedia Grounding (New)
        config.hud_queue.put("RESEARCH: WIKI CHECK")
        try:
            from modules.wiki_agent import WikiAgent
            wiki = WikiAgent()
            wiki_hits = wiki.search_wiki(topic)
            print(f"DEBUG: Wiki Hits: {wiki_hits}")
            if wiki_hits:

                top_page = wiki_hits[0]
                print(f"{Fore.CYAN}📖 [RESEARCH] Found Wiki Page: {top_page}")
                
                # Get Summary (Fast)
                summary = wiki.get_page_summary(top_page)
                if summary:
                    context_data += f"\n\n--- SOURCE: WIKIPEDIA ({top_page}) ---\n{summary}\n"
                    
                # Optional: Get Full content if needed? 
                # For now, summary provides excellent grounding definitions.
        except Exception as e:
            print(f"Wiki Error: {e}")

        # 1. Google Search
        urls = []
        try:
            # Get top 3 results
            for url in search(topic, num_results=3, lang='en'):
                urls.append(url)
        except Exception as e:
            print(f"Search Error: {e}")
            config.speech_queue.put("I could not access the search network.")
            return "Search failed."

        if not urls and not context_data:
            config.speech_queue.put("No sources found.")
            return "No sources."
        elif not urls and context_data:
            print("⚠️ [RESEARCH] Google search failed/empty, proceeding with Wikipedia data only.")


        # 2. Scrape & Read
        config.hud_queue.put("RESEARCH: READING")

        
        for i, url in enumerate(urls):
            print(f"   -> Reading source {i+1}: {url}")
            try:
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
                r = requests.get(url, headers=headers, timeout=5)
                soup = BeautifulSoup(r.text, 'html.parser')
                
                # Extract paragraph text
                text_content = ""
                for p in soup.find_all('p'):
                    text_content += p.get_text() + "\n"
                
                # Limit content per source to avoid token overflow
                context_data += f"\n\n--- SOURCE: {url} ---\n{text_content[:2000]}"
                
            except Exception as e:
                print(f"   [!] Failed to read {url}: {e}")

        # 3. Synthesize with Brain
        config.hud_queue.put("RESEARCH: WRITING")
        print(f"{Fore.MAGENTA}🧠 [THEORIST] Synthesizing Report...")
        
        prompt = f"""
        You are an Expert Researcher. Write a comprehensive report on: {topic}.
        
        Use the following gathered context as your primary source material:
        {context_data}
        
        Format: Markdown.
        Structure:
        # Title
        ## Executive Summary
        ## Key Findings
        ## Detailed Analysis
        ## Conclusion
        ## References (List the URLs)
        
        Style: Academic, Insightful, Professional.
        """
        
from modules.trusted_sources import get_knowledge_prompt, FORBIDDEN_SOURCES, TRUSTED_DOMAINS

class ResearchAgent:
    def __init__(self):
        self.brain = MindBrain()
        self.reports_dir = os.path.join(config.BASE_PATH, "reports")
        if not os.path.exists(self.reports_dir):
            os.makedirs(self.reports_dir)

    def research_topic(self, topic):
        """
        Conducts deep research on a topic and writes a report.
        """
        print(f"{Fore.CYAN}📚 [RESEARCH] Investigating: {topic}")
        config.speech_queue.put(f"Starting deep research on {topic}. This may take a moment.")
        config.hud_queue.put("RESEARCH: SEARCHING")
        context_data = ""


        # 0. Wikipedia Grounding (New)
        config.hud_queue.put("RESEARCH: WIKI CHECK")
        try:
            from modules.wiki_agent import WikiAgent
            wiki = WikiAgent()
            wiki_hits = wiki.search_wiki(topic)
            print(f"DEBUG: Wiki Hits: {wiki_hits}")
            if wiki_hits:

                top_page = wiki_hits[0]
                print(f"{Fore.CYAN}📖 [RESEARCH] Found Wiki Page: {top_page}")
                
                # Get Summary (Fast)
                summary = wiki.get_page_summary(top_page)
                if summary:
                    context_data += f"\n\n--- SOURCE: WIKIPEDIA ({top_page}) ---\n{summary}\n"
                    
                # Optional: Get Full content if needed? 
                # For now, summary provides excellent grounding definitions.
        except Exception as e:
            print(f"Wiki Error: {e}")

        # 1. Google Search
        urls = []
        try:
            # Get top results (increased count to allow filtering)
            candidates = list(search(topic, num_results=10, lang='en'))
            
            # Filter Forbidden Sources
            print(f"{Fore.YELLOW}   🕵️ Filtering Social Media & Low-Quality Sources...")
            for url in candidates:
                is_forbidden = any(bad in url for bad in FORBIDDEN_SOURCES)
                if not is_forbidden:
                    urls.append(url)
                else:
                    print(f"   🚫 Blocked: {url}")
            
            # Prioritize Trusted Domains (Bubble up)
            # This is a simple heuristic sorting
            urls.sort(key=lambda u: any(good in u for cat in TRUSTED_DOMAINS.values() for good in cat), reverse=True)
            
            # Limit to top 3 after filtering
            urls = urls[:3]
            
        except Exception as e:
            print(f"Search Error: {e}")
            config.speech_queue.put("I could not access the search network.")
            return "Search failed."

        if not urls and not context_data:
            config.speech_queue.put("No sources found.")
            return "No sources."
        elif not urls and context_data:
            print("⚠️ [RESEARCH] Google search failed/empty, proceeding with Wikipedia data only.")


        # 2. Scrape & Read
        config.hud_queue.put("RESEARCH: READING")

        
        for i, url in enumerate(urls):
            print(f"   -> Reading source {i+1}: {url}")
            try:
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
                r = requests.get(url, headers=headers, timeout=5)
                soup = BeautifulSoup(r.text, 'html.parser')
                
                # Extract paragraph text
                text_content = ""
                for p in soup.find_all('p'):
                    text_content += p.get_text() + "\n"
                
                # Limit content per source to avoid token overflow
                context_data += f"\n\n--- SOURCE: {url} ---\n{text_content[:2000]}"
                
            except Exception as e:
                print(f"   [!] Failed to read {url}: {e}")

        # 3. Synthesize with Brain
        config.hud_queue.put("RESEARCH: WRITING")
        print(f"{Fore.MAGENTA}🧠 [THEORIST] Synthesizing Report...")
        
        # Inject Knowledge Guidelines
        guidelines = get_knowledge_prompt(topic)
        
        prompt = f"""
        You are an Expert Researcher. Write a comprehensive report on: {topic}.
        
        {guidelines}
        
        Use the following gathered context as your primary source material:
        {context_data}
        
        Format: Markdown.
        Structure:
        # Title
        ## Executive Summary
        ## Key Findings
        ## Detailed Analysis
        ## Conclusion
        ## References (List the URLs)
        
        Style: Academic, Insightful, Professional.
        """
        
        report_content = self.brain.think(prompt, system_role="Academic Researcher")
        
        # 4. Save
        safe_title = topic.replace(" ", "_").lower()
        filename = f"{safe_title}_report.md"
        filepath = os.path.join(self.reports_dir, filename)
        
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(report_content)
            
        print(f"{Fore.GREEN}✅ Report Saved: {filepath}")
        config.speech_queue.put(f"Research complete. I have written the report on {topic}.")
        
        # Open it
        os.startfile(filepath)
        return f"Report saved to {filename}"
