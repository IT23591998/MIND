import json
import os
import time
from typing import List, Dict
from colorama import Fore

class MindClone:
    """
    Represents a Project-Specific Mini-MIND.
    It isolates memory and context to a specific JSON file.
    """
    
    def __init__(self, project_name: str, base_persona: str = "Manager"):
        self.project_name = project_name
        self.base_persona = base_persona
        self.memory_file = f"d:/MIND_Project/memory/clones/{project_name.lower().replace(' ', '_')}.json"
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(self.memory_file), exist_ok=True)
        
        self.context = self._load_context()
        
    def _load_context(self) -> List[Dict]:
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []

    def save_context(self):
        with open(self.memory_file, 'w') as f:
            json.dump(self.context, f, indent=2)

    def interact(self, input_text: str, mind_brain_instance) -> str:
        """
        Interacts with the Brain using ONLY this clone's context.
        """
        # 1. Add User Input to Local Context
        self.context.append({"role": "user", "content": input_text, "timestamp": time.time()})
        
        # 2. Construct Prompt with Isolated Context
        # We only pass the last 5 messages from THIS project history
        recent_history = self.context[-5:]
        
        system_prompt = f"You are a Project-Specific Clone of MIND. Project: {self.project_name}. Focus ONLY on this project."
        
        # 3. Call Brain (Using a simple wrapper or the meta-think if accessible)
        # Here we simulate the call to the main brain's LLM logic, but forcing the context
        # In a real integration, we'd pass this prompt to mind_brain.think()
        
        # For V2.2, we utilize the MindBrain instance passed in
        full_prompt = f"SYSTEM: {system_prompt}\n"
        for msg in recent_history:
            full_prompt += f"{msg['role'].upper()}: {msg['content']}\n"
            
        full_prompt += "ASSISTANT:"
        
        # We use the brain's detailed thinking but override context
        log_entry = mind_brain_instance.think_with_meta(full_prompt)
        response = log_entry.final_response
        
        # 4. Save Response to Local Context
        self.context.append({"role": "assistant", "content": response, "timestamp": time.time()})
        self.save_context()
        
        return response

    def get_summary(self):
        return f"Clone '{self.project_name}' has {len(self.context)} interactions stored."
