import os
import shutil
from colorama import Fore
import config

class OrganizerAgent:
    def __init__(self):
        self.downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
        
    def organize_folder(self, target_path=None):
        """Sorts files in the target directory into subfolders."""
        if target_path is None:
            target_path = self.downloads_path
            
        if not os.path.exists(target_path):
            return "Target folder not found."

        print(f"{Fore.CYAN}📂 [SORT] Organizing: {target_path}")
        config.hud_queue.put("SORT: ORGANIZING FILES")
        
        # Categories
        EXTENSIONS = {
            "Images": [".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg"],
            "Documents": [".pdf", ".docx", ".txt", ".xlsx", ".pptx", ".csv"],
            "Installers": [".exe", ".msi", ".apk", ".iso"],
            "Audio": [".mp3", ".wav", ".aac"],
            "Video": [".mp4", ".mkv", ".mov"],
            "Archives": [".zip", ".rar", ".7z", ".tar", ".gz"],
            "Code": [".py", ".js", ".html", ".css", ".cpp", ".cs", ".java"]
        }
        
        moved_count = 0
        
        for filename in os.listdir(target_path):
            file_path = os.path.join(target_path, filename)
            
            if os.path.isdir(file_path):
                continue
                
            _, ext = os.path.splitext(filename)
            ext = ext.lower()
            
            target_folder = None
            for category, exts in EXTENSIONS.items():
                if ext in exts:
                    target_folder = category
                    break
            
            if target_folder:
                folder_path = os.path.join(target_path, target_folder)
                if not os.path.exists(folder_path):
                    os.makedirs(folder_path)
                    
                try:
                    shutil.move(file_path, os.path.join(folder_path, filename))
                    moved_count += 1
                except Exception as e:
                    print(f"Error moving {filename}: {e}")

        msg = f"Organized {moved_count} files."
        config.speech_queue.put(msg)
        return msg
