import cv2
import os
import time
import base64
import requests
import config
from colorama import Fore
import requests
import config
import ollama
import psutil
from colorama import Fore
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

class VisionAgent:
    def __init__(self):
        self.camera_index = 0
        config.speech_queue.put("Initializing Visual Cortex...")
        
        # Configure Gemini directly for Vision (Simpler than wrapping messages sometimes)
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            print(f"{Fore.RED}❌ [VISION] GEMINI_API_KEY not found.")
            return
            
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')
        
        # Local Config
        self.local_model = "gemma3:latest"
        self.fallback_model = "llama3.2"

    def check_vram(self):
        """Returns True if VRAM/RAM pressure is acceptable (<90%)."""
        # Using RAM as proxy for this environment
        return psutil.virtual_memory().percent < 90

    def capture_image(self, path="vision_capture.jpg"):
        """Captures a single frame from the webcam."""
        cap = cv2.VideoCapture(self.camera_index)
        
        # Warmup
        if not cap.isOpened():
            return False
        
        ret, frame = cap.read()
        if ret:
            cv2.imwrite(path, frame)
        
        cap.release()
        return ret

    def analyze_feed(self, prompt="What do you see?", return_image=False):
        """Captures an image and asks Gemini about it. Optionally returns PIL Image."""
        print(f"{Fore.CYAN}👁️ [VISION] Looking...")
        config.hud_queue.put("VISION: ANALYZING")
        config.speech_queue.put("Let me take a look.")
        
        img_path = "vision_temp.jpg"
        success = self.capture_image(img_path)
        
        if not success:
            config.speech_queue.put("I cannot access the camera.")
            return "Camera Error"

        try:
            # Load the image for Gemini
            print(f"{Fore.CYAN}🧠 [VISION] Processing Image...")
            
            # Using standard file upload for Gemini 1.5
            # Or directly passing data if supported by the specific sdk version installed.
            # For 1.5 Flash, passing PIL image or path usually works.
            import PIL.Image
            img = PIL.Image.open(img_path)
            
            response = self.model.generate_content([prompt, img])
            text = response.text
            
            config.speech_queue.put(text)
            
            if return_image:
                return text, img
            return text
            
        except Exception as e:
            print(f"{Fore.RED}Vision Error: {e}")
            config.speech_queue.put(f"My vision is blurry. Error: {e}")
            return str(e)

    def scan_text(self):
        """Dedicated mode for reading text."""
        return self.analyze_feed(prompt="Read all the text in this image. Be precise.")

    def analyze_local(self, prompt="Describe this.", img_path="vision_input.jpg"):
        """
        Uses Local Ollama (Gemma 3) for analysis.
        ASYNCHRONOUSLY called by the Core Loop.
        """
        config.hud_queue.put(f"VISION: GEMMA 3 ({self.local_model})")
        
        # 1. Check Hardware
        if not self.check_vram():
             print(f"{Fore.YELLOW}⚠️ [VISION] VRAM High. Fallback to Text Mode.")
             # Fallback logic: Skip vision or use lighter model? 
             # Request asked to fallback to Llama 3.2 for TEXT ONLY (no image).
             return "VRAM Critical. Vision Module Offline. Switched to Text-Only."

        # 2. Capture if not provided
        if not os.path.exists(img_path):
            self.capture_image(img_path)

        try:
            print(f"{Fore.CYAN}👁️ [VISION] Logic: {self.local_model}...")
            
            # 3. Ollama Call
            response = ollama.chat(
                model=self.local_model,
                messages=[{
                    'role': 'user',
                    'content': prompt,
                    'images': [img_path]
                }]
            )
            
            answer = response['message']['content']
            
            # 4. Return Report (Async usually handles the speaking via callback, or we return text)
            return answer
            
        except Exception as e:
            print(f"{Fore.RED}Local Vision Error: {e}")
            return f"Gemma Blinded: {e}"
