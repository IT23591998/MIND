import os
import torch
import sounddevice as sd
import soundfile as sf
import queue
import threading
import time
from colorama import Fore
import config

try:
    from TTS.api import TTS
    HAS_NEURAL = True
except ImportError:
    HAS_NEURAL = False
    print(f"{Fore.RED}⚠️ [VOICE] Coqui TTS not found. Falling back to System Voice.")

class NeuralVoiceAgent:
    def __init__(self):
        # Force CPU to ensure stability (GPU often OOMs with LLM + Whisper + TTS)
        self.device = "cpu" 
        # Use YourTTS for Zero-Shot Cloning
        self.model_name = "tts_models/multilingual/multi-dataset/your_tts"
        self.speaker_wav = os.path.join(config.ASSETS_DIR, "system_core.wav")
        self.tts = None
        self.is_loaded = False
        
        if HAS_NEURAL:
            threading.Thread(target=self._load_model, daemon=True).start()

    def _load_model(self):
        print(f"{Fore.CYAN}🔊 [VOICE] Loading Cloning Engine ({self.model_name}) on {self.device}...")
        try:
            self.tts = TTS(self.model_name).to(self.device)
            self.is_loaded = True
            print(f"{Fore.GREEN}🔊 [VOICE] Voice Clone Online.")
        except Exception as e:
            print(f"{Fore.RED}⚠️ [VOICE] Load Error: {e}")
            HAS_NEURAL = False

    def wait_until_loaded(self, timeout=120): # Increased timeout for YourTTS
        """Blocks until the model is loaded or timeout is reached."""
        if not HAS_NEURAL:
            return
        
        print(f"{Fore.YELLOW}⏳ [VOICE] Waiting for Neural Engine...")
        start_time = time.time()
        while not self.is_loaded:
            if time.time() - start_time > timeout:
                print(f"{Fore.RED}⚠️ [VOICE] Timeout waiting for model.")
                break
            time.sleep(0.5)

    def speak(self, text, output_file="mind_voice_output.wav"):
        """Generates and plays audio."""
        if not HAS_NEURAL or not self.is_loaded:
            # Fallback to PowerShell
            self._speak_system(text)
            return

        try:
            print(f"{Fore.MAGENTA}🔊 MIND (Neural): {text}")
            
            # Use Cloning if wav exists, else default speaker
            if os.path.exists(self.speaker_wav):
                 self.tts.tts_to_file(text=text, speaker_wav=self.speaker_wav, language="en", file_path=output_file)
            else:
                 print(f"{Fore.YELLOW}⚠️ Voice sample not found at {self.speaker_wav}. Using default.")
                 # Fallback to a default speaker if using multi-speaker model
                 self.tts.tts_to_file(text=text, speaker="p229", language="en", file_path=output_file)  # p229 is common in VCTK
            
            # Play
            data, fs = sf.read(output_file)
            sd.play(data, fs)

            sd.wait()
            
        except Exception as e:
            print(f"{Fore.RED}Voice Generation Error: {e}")
            self._speak_system(text)

    def _speak_system(self, text):
        """Fallback to PowerShell"""
        print(f"🔊 MIND (System): {text}")
        safe_text = text.replace("'", "").replace('"', "").replace("\n", " ")
        cmd = f'PowerShell -Command "Add-Type –AssemblyName System.Speech; ' \
              f'$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; ' \
              f'$speak.Rate = 1; ' \
              f'$speak.Speak(\'{safe_text}\');"'
        import subprocess
        subprocess.run(cmd, shell=True)
