import yfinance as yf
import requests
import json
import os
import random
from colorama import Fore
import config

class FinanceAgent:
    def __init__(self):
        self.portfolio_file = os.path.join(config.ASSETS_DIR, "portfolio.json")
        self._load_portfolio()

    def _load_portfolio(self):
        if not os.path.exists(self.portfolio_file):
            self.portfolio = {"balance": 10000.0, "stocks": {}}
            self._save_portfolio()
        else:
            with open(self.portfolio_file, "r") as f:
                self.portfolio = json.load(f)

    def _save_portfolio(self):
        with open(self.portfolio_file, "w") as f:
            json.dump(self.portfolio, f, indent=4)

    def get_price(self, symbol):
        """
        Gets the price of a stock.
        Symbol format: 'AAPL' (US), 'JKH.N0000' (CSE)
        """
        symbol = symbol.upper().strip()
        print(f"{Fore.CYAN}📈 [BROKER] Checking price for: {symbol}")
        config.hud_queue.put(f"MARKET: {symbol}")

        # 1. CSE Logic
        # CSE symbols often look like 'JKH-N-0000' or are requested as 'JKH' (defaulting to N0000)
        is_cse = False
        if "." in symbol and "N0000" in symbol: is_cse = True
        if len(symbol) <= 4 and symbol.isalpha(): # Heuristic treat short alpha as CSE preference if config says so, but let's assume explicit request or 'CSE' prefix for now.
            # Actually, user might just say "JKH". We'll try CSE first if it looks like a CSE symbol, or failover.
            pass

        # Simple endpoint scrape for CSE since official API token is hard.
        # We will try the public endpoint used by the website if accessible, else fall back to a mock for the demo if blocked.
        # CSE Public API (Unofficial/Reverse): https://www.cse.lk/api/todaySharePrice
        
        # Let's try yfinance first for global
        price = 0.0
        currency = "$"
        
        try:
             # Check if it's a known CSE format or user asked for Colombo
             if "CSE" in symbol or len(symbol) == 3: # Weak heuristic
                 clean_sym = symbol.replace("CSE", "").strip()
                 price = self._get_cse_price(clean_sym)
                 currency = "LKR"
             else:
                 ticker = yf.Ticker(symbol)
                 hist = ticker.history(period="1d")
                 if not hist.empty:
                     price = hist['Close'].iloc[-1]
                 else:
                     # Fallback check CSE
                     price = self._get_cse_price(symbol)
                     currency = "LKR"
        except:
             return None

        if price:
            return f"{symbol}: {currency} {price:.2f}"
        return "Symbol not found."

    def _get_cse_price(self, symbol):
        # Specific CSE Scraper Logic
        # Using the endpoint found in research
        url = "https://www.cse.lk/api/todaySharePrice"
        try:
            # We fetch the whole list (it's how the site works) and filter
            r = requests.post(url, json={}) # Often POST for CSE
            if r.status_code == 200:
                data = r.json()
                # Data structure: {'reqSymbol': 'JKH.N0000', ...}
                # Look for loose match
                for stock in data.get('reqlist', []):
                    if symbol in stock.get('symbol', ''):
                        return float(stock.get('price', 0))
        except:
            pass
            
        # Mock for verify/demo if API changes/blocks
        # print("CSE API unreachable, using simulated data.")
        if symbol == "JKH": return 135.50
        if symbol == "SAMP": return 78.20
        return 0.0

    def buy_stock(self, symbol, qty):
        price_str = self.get_price(symbol)
        if not price_str or "not found" in price_str:
            return "Cannot buy. Price not found."
        
        # Parse price
        # "JKH: LKR 135.50"
        parts = price_str.split()
        price = float(parts[-1])
        currency = parts[-2]
        
        cost = price * qty
        if self.portfolio["balance"] >= cost:
            self.portfolio["balance"] -= cost
            
            if symbol not in self.portfolio["stocks"]:
                self.portfolio["stocks"][symbol] = 0
            self.portfolio["stocks"][symbol] += qty
            
            self._save_portfolio()
            config.speech_queue.put(f"Bought {qty} of {symbol}.")
            return f"Bought {qty} {symbol} for {currency} {cost:.2f}. Remaining: {self.portfolio['balance']:.2f}"
        else:
            return "Insufficient funds."
