import os
import json
from colorama import Fore
import config

class HomeAutomationAgent:
    def __init__(self):
        self.state_file = os.path.join(config.ASSETS_DIR, "home_state.json")
        self.devices = self._load_state()
        
    def _load_state(self):
        """Loads the virtual home state."""
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, "r") as f:
                    return json.load(f)
            except:
                pass
        
        # Default State
        return {
            "living_room": {"lights": "off", "ac": "off", "color": "white"},
            "bedroom": {"lights": "off", "ac": "off", "color": "white"},
            "kitchen": {"lights": "off", "coffee_maker": "off"},
            "fans": "off"
        }

    def _save_state(self):
        with open(self.state_file, "w") as f:
            json.dump(self.devices, f, indent=4)

    def control_device(self, device_name, action):
        """
        Controls a device using fuzzy matching for simulation.
        """
        device_name = device_name.lower()
        action = action.lower()
        
        print(f"{Fore.CYAN}🏠 [HOME] Command: {device_name} -> {action}")
        config.hud_queue.put(f"HOME: {device_name.upper()} {action.upper()}")

        # Simulation Logic
        found = False
        
        # 1. Global/Broad Search
        if "light" in device_name:
            for room in self.devices:
                if isinstance(self.devices[room], dict) and "lights" in self.devices[room]:
                    self.devices[room]["lights"] = action
            msg = f"All lights turned {action}."
            found = True
            
        elif "fan" in device_name:
            self.devices["fans"] = action
            msg = f"Fans turned {action}."
            found = True
            
        else:
            # 2. Room Specific
            target_room = None
            if "bed" in device_name: target_room = "bedroom"
            elif "living" in device_name: target_room = "living_room"
            elif "kitchen" in device_name: target_room = "kitchen"
            
            if target_room:
                 # Assume lights if not specified, or match specific key
                 key = "lights"
                 if "ac" in device_name: key = "ac"
                 if "coffee" in device_name: key = "coffee_maker"
                 
                 if key in self.devices[target_room]:
                     self.devices[target_room][key] = action
                     msg = f"{target_room} {key} turned {action}."
                     found = True

        self._save_state()
        
        if found:
            config.speech_queue.put(msg)
            return msg
        else:
            return "Device not found in simulation."

    def set_environment(self, room, mode):
        """
        Sets a specific mood/color for a room.
        """
        room = room.lower()
        mode = mode.lower()
        
        target_room = None
        if "bed" in room: target_room = "bedroom"
        if "living" in room: target_room = "living_room"
        
        if target_room:
            self.devices[target_room]["color"] = mode
            self.devices[target_room]["lights"] = "on"
            self._save_state()
            
            msg = f"Set {target_room} to {mode} mode."
            print(f"{Fore.CYAN}🏠 [HOME] {msg}")
            config.speech_queue.put(msg)
            return msg
            
        return "I can't change the environment for that room."
