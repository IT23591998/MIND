import os
from colorama import Fore
import config
from mind_brain import MindBrain

class GameDevAgent:
    def __init__(self):
        self.brain = MindBrain()
        self.assets_dir = os.path.join(config.BASE_PATH, "game_assets")
        if not os.path.exists(self.assets_dir):
            os.makedirs(self.assets_dir)

    def generate_script(self, mechanic, engine="unity"):
        """
        Generates a game script (C# for Unity, C++ for Unreal).
        """
        engine = engine.lower()
        if "unreal" in engine:
            lang = "C++"
            ext = ".cpp"
            role = "Unreal Engine C++ Expert"
        else:
            lang = "C# (Unity Monobehaviour)"
            ext = ".cs"
            role = "Unity C# Expert"

        print(f"{Fore.MAGENTA}[GAME DEV] Generating {lang} script for: {mechanic}")
        config.speech_queue.put(f"Drafting {engine} script for {mechanic}...")
        config.hud_queue.put(f"GAMEDEV: CODING {lang.upper()}")

        prompt = f"""
        Write a robust, production-ready {lang} script for: {mechanic}.
        
        Requirements:
        1. Include all necessary imports/using statements.
        2. Use best practices (serialization, comments).
        3. CODE ONLY. No markdown.
        """
        
        try:
            code = self.brain.think(prompt, system_role=role)
            clean_code = code.replace(f"```{lang.lower()}", "").replace("```c#", "").replace("```cpp", "").replace("```", "").strip()
            
            # Naming
            safe_name = mechanic.split()[0].title() + "Controller" # Heuristic name
            if "manager" in mechanic.lower(): safe_name = "GameManager"
            
            filename = f"{safe_name}{ext}"
            filepath = os.path.join(self.assets_dir, filename)
            
            with open(filepath, "w") as f:
                f.write(clean_code)
                
            print(f"{Fore.GREEN}✅ Script Saved: {filepath}")
            config.speech_queue.put(f"Script {filename} created.")
            
            # Show it
            os.startfile(self.assets_dir)
            
            return f"Generated {filename}"
            
        except Exception as e:
            print(f"GameDev Error: {e}")
            return f"Failed: {e}"
