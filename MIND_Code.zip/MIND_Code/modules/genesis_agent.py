import os
import importlib
from colorama import Fore
import config

# Import Core Components (We need Brain for generation, Shield for safety)
# Assuming mind_core_loop passes these or we instantiate.
# Ideally Genesis should be instantiated with references.

class GenesisAgent:
    def __init__(self, brain_ref, shield_ref):
        self.brain = brain_ref
        self.shield = shield_ref
        self.modules_path = "D:/MIND_Project/modules"

    def evolve(self, skill_name, goal_description):
        """
        The Evolution Loop:
        1. Research (LLM)
        2. Draft Code
        3. Shield Validation
        4. Deployment
        """
        print(f"{Fore.MAGENTA}[Genesis] Initiating Evolution: {skill_name}")
        
        # 1. Draft
        system_prompt = (
            "You are the Genesis Core of MIND. "
            "Your goal is to write a Python 3 class for a new agent. "
            "Use standard libraries where possible. "
            "The class name must be based on skill_name + 'Agent'. "
            "OUTPUT ONLY THE CODE. NO MARKDOWN."
        )
        user_prompt = f"Write a module to achieve: {goal_description}. Filename should be {skill_name.lower()}_agent.py"
        
        print(f"{Fore.MAGENTA}[Genesis] Synthesizing Neural pathways...")
        code = self.brain.think(user_prompt, system_role=system_prompt, temperature=0.2)
        
        # Clean Markdown
        code = code.replace("```python", "").replace("```", "").strip()
        
        # 2. Judge (Shield)
        valid, msg = self.shield.validate_code(code)
        if not valid:
            return f"Evolution Halted by Shield: {msg}"
        
        # 3. Deploy
        filename = f"{skill_name.lower()}_agent.py"
        filepath = os.path.join(self.modules_path, filename)
        
        try:
            with open(filepath, "w") as f:
                f.write(code)
            
            print(f"{Fore.GREEN}[Genesis] New Organ Grow: {filename}")
            
            # 4. Integrate (Hot Load attempt)
            # This is complex in Python. We can just say "Restart Required" for safety,
            # or try to import it.
            # importlib.import_module(f"modules.{skill_name.lower()}_agent")
            
            return f"Evolution Complete. Created {filename}. Please restart MIND to activate {skill_name}."
            
        except Exception as e:
            return f"Evolution Failed: {e}"
