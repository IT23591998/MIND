import pyperclip
import config
from mind_brain import MindBrain
from colorama import Fore

class BoostAgent:
    def __init__(self):
        self.brain = MindBrain()

    def optimize_code(self):
        """Refactors code currently in clipboard."""
        code = pyperclip.paste()
        if not code or len(code) < 5:
            return "Clipboard is empty."

        print(f"{Fore.CYAN}⚡ [BOOST] Optimizing Code...")
        config.hud_queue.put("DEV: OPTIMIZING CODE")
        
        prompt = f"""
        Act as a Senior Software Engineer.
        Refactor the following code for performance, readability, and PEP8/Standard compliance.
        Provide ONLY the code block.
        
        Code:
        {code[:2000]}
        """
        
        optimized = self.brain.think(prompt, temperature=0.1)
        # Strip markdown
        optimized = optimized.replace("```python", "").replace("```", "").strip()
        
        pyperclip.copy(optimized)
        return "Optimized code copied to clipboard."

    def generate_snippet(self, description):
        """Generates boilerplate."""
        print(f"{Fore.CYAN}⚡ [BOOST] Generating Snippet: {description}")
        
        prompt = f"""
        Generate a robust, production-ready code snippet for: {description}.
        Language: Python/C++/JS (Infer from context or default to Python).
        Provide ONLY the code.
        """
        
        snippet = self.brain.think(prompt, temperature=0.1)
        snippet = snippet.replace("```python", "").replace("```", "").strip()
        
        pyperclip.copy(snippet)
        return "Snippet copied to clipboard."

    def debug_error(self, error_msg):
        """Explains an error message."""
        explanation = self.brain.think(f"Explain this error and how to fix it briefly:\n{error_msg}")
        return explanation
