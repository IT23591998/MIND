import os
import json
import subprocess
import threading
import time
from colorama import Fore
import config

# Import your Brain
from mind_brain import MindBrain

class WebAutomator:
    def __init__(self):
        self.brain = MindBrain()
        self.projects_root = "D:/MyProjects/"  # Consistent with Android Agent

    def step_1_scaffold_project(self, app_name, stack):
        """
        Dynamically determines the scaffold command using Brain.
        """
        print(f"{Fore.CYAN}🌐 [WEB AGENT] Analyzing Stack: {stack}...")
        config.speech_queue.put(f"Designing {app_name} with {stack}.")
        
        safe_name = app_name.lower().replace(" ", "-")
        project_path = os.path.join(self.projects_root, safe_name)
        
        if not os.path.exists(self.projects_root):
            os.makedirs(self.projects_root)
            
        # Ask Brain for the Best Initiation Command
        prompt = f"""
        I need to create a new web project named '{safe_name}' using '{stack}'.
        Provide the SINGLE best terminal command to scaffold this project non-interactively if possible.
        Examples: 
        - 'npx create-next-app@latest {safe_name} --yes'
        - 'npm create vite@latest {safe_name} -- --template react'
        - 'django-admin startproject {safe_name}'
        
        Output ONLY the command string.
        """
        
        try:
            cmd = self.brain.think(prompt, temperature=0.1).strip().replace("`", "")
            print(f"{Fore.YELLOW}   🖥️ Executing: {cmd}")
            
            # If it's pure HTML/CSS, manually create
            if "html" in stack.lower() or "vanilla" in stack.lower():
                os.makedirs(project_path, exist_ok=True)
            else:
                self._run_shell(cmd, self.projects_root)
                
            print(f"{Fore.GREEN}✅ [SUCCESS] Scaffold complete.")
            return project_path
        except Exception as e:
            print(f"{Fore.RED}❌ [ERROR] Scaffold logic failed: {e}")
            return None

    def step_2_generate_code(self, app_name, stack, project_path):
        """
        Populates the project with code based on the app description.
        """
        if not project_path: return

        print(f"{Fore.MAGENTA}⚡ [WEB AGENT] Writing Code for {app_name}...")
        config.speech_queue.put("Writing website code now.")

        # Define files to edit based on stack
        # Ask Brain for File Structure
        struct_prompt = f"""
        For a '{stack}' project named '{app_name}', list the top 3-4 most critical files to edit to make a "Hello World" or basic landing page.
        Return in JSON format: 
        [
            {{"path": "src/App.js", "desc": "Main component"}}, 
            {{"path": "public/index.html", "desc": "Entry HTML"}}
        ]
        ONLY JSON.
        """
        
        try:
            files_json = self.brain.think(struct_prompt, temperature=0.1).replace("```json", "").replace("```", "").strip()
            files_to_edit = json.loads(files_json)
        except:
            # Fallback
            files_to_edit = [{"path": "README.md", "desc": "Project Documentation"}]

        # --- GENERATION LOOP ---
        for file_info in files_to_edit:
            rel_path = file_info['path']
            desc = file_info['desc']
            full_path = os.path.join(project_path, rel_path)
            
            print(f"{Fore.YELLOW}   ✍️ Coding: {rel_path}...")
            
            prompt = f"""
            Act as an Expert Web Developer using {stack}.
            Project: {app_name}
            File: {rel_path} ({desc})
            
            Write the FULL code for this file. 
            Make it look modern, premium, and functional.
            If using Tailwind, use standard utility classes.
            
            Output ONLY the code. No markdown.
            """
            
            try:
                code = self.brain.think(prompt, temperature=0.5)
                clean_code = code.replace("```html", "").replace("```css", "").replace("```javascript", "").replace("```jsx", "").replace("```tsx", "").replace("```", "").strip()
                
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(clean_code)
                    
            except Exception as e:
                print(f"{Fore.RED}   ❌ Failed to write {rel_path}: {e}")

        config.speech_queue.put(f"Website {app_name} is ready.")
        self.open_in_browser(project_path, stack)

    def open_in_browser(self, project_path, stack):
        """
        Opens the project. for Vanilla, opens index.html.
        For others, potentially runs dev server (but we'll just open folder for now to be safe).
        """
        print(f"{Fore.GREEN}🚀 [LAUNCH] Opening Project Folder...")
        os.startfile(project_path)
        
        # If vanilla, open the HTML file directly
        if "html" in stack.lower() or "vanilla" in stack.lower():
            index_path = os.path.join(project_path, "index.html")
            if os.path.exists(index_path):
                os.startfile(index_path)

    def _run_shell(self, cmd, cwd):
        """Helper to run shell commands synchronously."""
        subprocess.run(cmd, shell=True, cwd=cwd, check=True)

    def create_website(self, app_name, stack):
        """
        Main entry point.
        """
        path = self.step_1_scaffold_project(app_name, stack)
        if path:
            self.step_2_generate_code(app_name, stack, path)
