
import os
import requests
import json
import webbrowser
import urllib.parse
from googlesearch import search
from bs4 import BeautifulSoup
from colorama import Fore
import config
from mind_brain import MindBrain

class ShoppingAgent:
    def __init__(self):
        self.brain = MindBrain()
        self.markets = [
            "daraz.lk",
            "eshop.lk",
            "targetonline.lk",
            "myfair.lk",
            "zigzag.lk",
            "kapruka.com",
            "takas.lk",
            "wasi.lk",
            "ideabeam.com", # Price comparison specific
            "facebook.com" # Often used for marketplace in SL
        ]
        print(f"{Fore.GREEN}🛒 [SHOPPING] Sri Lankan Market Agent Online.")

    def search_product(self, product_name):
        """
        Searches for a product across known Sri Lankan marketplaces, 
        synthesizes a report, and opens links.
        """
        print(f"{Fore.CYAN}🛒 [SHOPPING] Hunting for: {product_name}...")
        config.speech_queue.put(f"Searching Sri Lankan markets for {product_name}. Please wait.")
        config.hud_queue.put("SHOPPING: SCANNING")

        # 1. Search Logic
        # We will perform a targeted Google Search: "[product] site:daraz.lk OR site:eshop.lk..."
        # Due to query limits, we might split or just search broad + "sri lanka price"
        
        # Strategy: "product name price sri lanka" generic search first to get best hits
        search_query = f"{product_name} price sri lanka buy online"
        
        found_links = []
        context_data = ""
        
        try:
            # Get top 10 results
            results = list(search(search_query, num_results=10, lang='en'))
            
            # Filter for our preferred domains or general SL domains
            for url in results:
                # Basic check if it's a shop
                if any(m in url for m in self.markets) or ".lk" in url:
                    found_links.append(url)
                    
        except Exception as e:
            print(f"Search Error: {e}")
            return "I could not access the search network."

        if not found_links:
            # Fallback to direct Daraz search
            daraz_url = f"https://www.daraz.lk/catalog/?q={urllib.parse.quote(product_name)}"
            webbrowser.open(daraz_url)
            return f"I couldn't find specific product pages, so I opened a search on Daraz for {product_name}."

        # 2. Scrape Context (Limit to top 3 to be fast)
        top_links = found_links[:4]
        config.hud_queue.put("SHOPPING: COMPARING")
        
        print(f"{Fore.YELLOW}   🔍 Analyzing {len(top_links)} sources...")
        
        for i, url in enumerate(top_links):
            try:
                # Fast Timeout, we just want title/price metadata if possible
                headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
                r = requests.get(url, headers=headers, timeout=3)
                soup = BeautifulSoup(r.text, 'html.parser')
                
                title = soup.title.string.strip() if soup.title else "No Title"
                # Naive text extraction
                text = soup.get_text()[:1000].replace("\n", " ") # First 1000 chars roughly
                
                context_data += f"\nSOURCE {i+1}: {url}\nTITLE: {title}\nCONTENT_SNIPPET: {text}\n"
                
            except:
                pass

        # 3. LLM Synthesis
        print(f"{Fore.MAGENTA}🧠 [SHOPPING] Synthesizing Deal Report...")
        
        prompt = f"""
        You are a Shopping Assistant for Sri Lanka.
        User wants: {product_name}
        
        Based on these search results:
        {context_data}
        
        1. Identify the likely price range (in LKR).
        2. Identify the best store options mentioned.
        3. Recommend where to buy based on the snippets (or say information is limited).
        
        Output a concise spoken summary (2-3 sentences max). 
        Do not read URLs.
        """
        
        summary = self.brain.think(prompt, system_role="Shopping Assistant", temperature=0.3)
        
        # 4. Open Tabs
        for url in top_links:
            webbrowser.open_new_tab(url)
            
        return summary
