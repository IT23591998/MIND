import time
import random
from colorama import Fore
import config

class GrantAgent:
    def scan_grants(self, keyword="AI"):
        """
        Simulates scanning grant databases.
        In production, this would scrape usage grants.gov or similar.
        """
        print(f"{Fore.GREEN}💰 [GRANT] Scanning databases for '{keyword}'...")
        config.hud_queue.put(f"FUND: SCANNING FOR {keyword.upper()}")
        config.speech_queue.put(f"Searching for funding opportunities related to {keyword}.")
        
        # Simulated Network Delay
        time.sleep(2)
        
        # Simulated Results
        results = [
            "OpenAI Research Grant ($100k) - Focus: AGI Alignment",
            "NSF Innovation Fund ($50k) - Focus: STEM Education",
            "Sri Lanka Tech Startup Fund (LKR 5M) - Focus: Local SaaS",
            "Google for Startups Cloud Credits ($20k)"
        ]
        
        found = [r for r in results if keyword.lower() in r.lower() or "Fund" in r or "Grant" in r]
        
        if not found:
            return "No matching grants found."
            
        report = "\n".join(found)
        return f"Found Opportunities:\n{report}"

    def match_profile(self, project_desc):
        """Checks if a project fits known grants."""
        return "Your project fits the 'Tech Startup Fund'. Eligibility: 85%."
