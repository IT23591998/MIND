import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import config
from mind_brain import MindBrain

class DataAgent:
    def __init__(self):
        self.brain = MindBrain()
        self.df = None
        self.current_file = None
        # Directory to save plots
        self.plot_dir = os.path.join("D:/MIND_Project", "assets", "plots")
        if not os.path.exists(self.plot_dir):
            os.makedirs(self.plot_dir)

    def load_data(self, filepath):
        """Loads a dataset (CSV, Excel, JSON)."""
        if not os.path.exists(filepath):
            return f"Error: File not found at {filepath}"

        try:
            if filepath.endswith('.csv'):
                self.df = pd.read_csv(filepath)
            elif filepath.endswith('.xlsx') or filepath.endswith('.xls'):
                self.df = pd.read_excel(filepath)
            elif filepath.endswith('.json'):
                self.df = pd.read_json(filepath)
            else:
                return "Unsupported file format. Please use CSV, Excel, or JSON."
            
            self.current_file = filepath
            rows, cols = self.df.shape
            cols_summary = ", ".join(self.df.columns[:5])
            if len(self.df.columns) > 5:
                cols_summary += ", ..."
                
            return f"Successfully loaded {os.path.basename(filepath)}. Dataset has {rows} rows and {cols} columns. Columns: {cols_summary}"
        except Exception as e:
            return f"Failed to load data: {str(e)}"

    def basic_summary(self):
        """Returns a string summary of the dataframe."""
        if self.df is None:
            return "No data loaded."
        
        desc = self.df.describe().to_string()
        info = f"Rows: {self.df.shape[0]}, Columns: {self.df.shape[1]}\n"
        info += f"Columns: {', '.join(self.df.columns)}\n"
        return info

    def analyze_query(self, query):
        """
        Uses the LLM to analyze the data or generate a plot based on the query.
        """
        if self.df is None:
            return "Please load a dataset first."

        # check for plot request
        if "plot" in query.lower() or "graph" in query.lower() or "chart" in query.lower():
            return self._generate_plot(query)
        
        # Otherwise, ask the brain to analyze the data context
        # We pass a sample of the data to the brain
        sample_data = self.df.head(5).to_string()
        columns = self.df.columns.tolist()
        
        prompt = f"""
        You are a Data Analysis Assistant.
        User Query: "{query}"
        
        Current Dataset Context:
        Columns: {columns}
        Sample Data:
        {sample_data}
        
        Provide a concise answer to the user's question based on the structure of the data. 
        If you need to calculate something specific that you can't see, describe how you would do it or give a general answer.
        Keep the answer short and spoken-friendly.
        """
        
        response = self.brain.think(prompt, system_role="You are a helpful Data Analyst.")
        return response

    def _generate_plot(self, query):
        """
        Generates code to plot data, executes it, and saves the image.
        """
        columns = self.df.columns.tolist()
        
        prompt = f"""
        Act as a Python Data Visualization Expert.
        User Query: "{query}"
        Dataset Columns: {columns}
        
        Write a Python script using matplotlib/seaborn to generate this plot.
        - Assume the dataframe is already loaded as `df`.
        - Use `plt.savefig('output_plot.png')` to save the plot.
        - Do NOT use `plt.show()`.
        - Do NOT read the file again. Use existing `df`.
        - Output ONLY the python code. No markdown formatting.
        """
        
        code = self.brain.think(prompt, temperature=0.2)
        
        # cleaning code
        code = code.replace("```python", "").replace("```", "").strip()
        
        # Execution context
        local_scope = {'df': self.df, 'plt': plt, 'sns': sns, 'pd': pd}
        
        try:
            # We need to render it to a specific path
            timestamp = int(os.path.getmtime(self.current_file) if self.current_file else 0)
            img_name = f"plot_{len(os.listdir(self.plot_dir))}.png"
            save_path = os.path.join(self.plot_dir, img_name)
            
            # Inject save path into code if the LLM followed instructions or not
            # We force the savefig call at the end to be sure
            code += f"\nplt.savefig(r'{save_path}')\nplt.close()"
            
            exec(code, {}, local_scope)
            
            if os.path.exists(save_path):
                os.startfile(save_path)
                return f"I've generated the plot and opened it."
            else:
                return "I tried to generate the plot, but the file wasn't saved."
                
        except Exception as e:
            return f"Failed to generate plot: {e}"
