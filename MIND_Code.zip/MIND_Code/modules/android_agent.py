import os
import sys
import json
import subprocess
import threading
import time
import pyperclip
from colorama import Fore
import config

# Import your Brain
from mind_brain import MindBrain

class AndroidAutomator:
    def __init__(self):
        # Enforce UTF-8 for Windows Consoles
        # Enforce UTF-8 for Windows Consoles
        if sys.stdout and getattr(sys.stdout, 'encoding', None) and sys.stdout.encoding.lower() != 'utf-8':
            try:
                sys.stdout.reconfigure(encoding='utf-8')
                if sys.stderr:
                    sys.stderr.reconfigure(encoding='utf-8')
            except: pass
            
        self.brain = MindBrain()
        self.config_file = os.path.join(config.BASE_PATH, "project_config.json")
        self.projects_root = "D:/MyProjects/"  # Change if needed
        
        # PERMANENT FIX: Force Gradle to use D: Drive to avoid C: Full errors
        self.gradle_home = "D:\\Gradle_User_Home"
        if not os.path.exists(self.gradle_home):
            os.makedirs(self.gradle_home, exist_ok=True)
        os.environ["GRADLE_USER_HOME"] = self.gradle_home

    # --- PHASE 0: PRE-FLIGHT CHECKS ---
    def diagnose_environment(self):
        """Checks if the environment is actually capable of building Android apps."""
        print(f"{Fore.CYAN}🔍 [ANDROID AGENT] Diagnosing Environment...")
        
        # 1. Java Check
        try:
            java_ver = subprocess.check_output("java -version", stderr=subprocess.STDOUT, shell=True).decode()
            print(f"{Fore.GREEN}   ✅ Java found: {java_ver.splitlines()[0]}")
        except:
            print(f"{Fore.RED}   ❌ Java NOT found. Gradle will fail.")

        # 2. Android Home
        if os.environ.get("ANDROID_HOME"):
             print(f"{Fore.GREEN}   ✅ ANDROID_HOME: {os.environ['ANDROID_HOME']}")
        else:
             print(f"{Fore.YELLOW}   ⚠️ ANDROID_HOME not set. Might rely on local.properties.")

        # 3. Gradle (Global)
        try:
            gradle_ver = subprocess.check_output("gradle -v", shell=True).decode()
            print(f"{Fore.GREEN}   ✅ Global Gradle found.")
        except:
            print(f"{Fore.YELLOW}   ⚠️ Global Gradle not found (Standard for Wrapper projects).")


    # --- CORE: FILE SYSTEM HELPERS ---
    def save_project_metadata(self, app_name, path):
        """Remembers the last project we worked on."""
        try:
            with open(self.config_file, "w") as f:
                json.dump({"current_project": app_name, "path": path}, f)
        except: pass

    def check_flutter_installed(self):
        try:
            subprocess.run(["flutter", "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return True
        except:
            return False

    def find_android_studio(self):
        """Smart detection of Android Studio executable."""
        paths = [
            r"C:\Program Files\Android\Android Studio\bin\studio64.exe",
            r"D:\Android Studio\bin\studio64.exe",
            os.path.expanduser("~/AppData/Local/Android/android-studio/bin/studio64.exe")
        ]
        for p in paths:
            if os.path.exists(p): return p
        return None

    # --- PHASE 1: GENESIS ARCHITECT (The Structure) ---
    # --- PHASE 1: GENESIS ARCHITECT (The Structure) ---
    def step_2_create_project_wizard(self, app_name):
        """
        Creates full project structure with a guaranteed 'Golden Path' to a compilable app.
        """
        print(f"{Fore.CYAN}🏗️ [ANDROID AGENT] Architecting '{app_name}'...")
        config.speech_queue.put(f"Designing architecture for {app_name}...")

        safe_name = app_name.lower().replace(" ", "")
        self.package_name = f"com.example.{safe_name}" # Store for later use
        project_path = os.path.join(self.projects_root, app_name.replace(" ", ""))

        # --- 1️⃣ Essential File Skeleton (The Golden Path) ---
        # These files are REQUIRED for the app to build. We don't guess these.
        files_to_create = [
            # Root Gradle
            {"path": "build.gradle.kts", "type": "gradle_root"},
            {"path": "settings.gradle.kts", "type": "gradle_settings"},
            {"path": "gradle.properties", "type": "gradle_props"},
            
            # App Gradle
            {"path": "app/build.gradle.kts", "type": "gradle_app"},
            {"path": "app/src/main/AndroidManifest.xml", "type": "manifest"},
            
            # Code (Kotlin + Compose)
            {"path": f"app/src/main/java/com/example/{safe_name}/MainActivity.kt", "type": "kotlin_main"},
            {"path": f"app/src/main/java/com/example/{safe_name}/ui/theme/Theme.kt", "type": "kotlin_theme"},
            {"path": f"app/src/main/java/com/example/{safe_name}/ui/theme/Color.kt", "type": "kotlin_color"},
            {"path": f"app/src/main/java/com/example/{safe_name}/ui/theme/Type.kt", "type": "kotlin_type"},
        ]

        # --- 2️⃣ Ask AI for Feature Files (The "Smart" Part) ---
        # We only ask AI for *extra* files needed for this specific app idea.
        prompt = f"""
        Act as a Senior Android Architect.
        We have a base Jetpack Compose project.
        App Name: "{app_name}"
        Package: "{self.package_name}"
        
        We ALREADY have: MainActivity, Theme, Color, Type, Manifest, Gradle files.
        
        List ONLY the ADDITIONAL separate files needed for this specific app (e.g., specific Screens, ViewModels, Data Classes, Repository).
        Do NOT list files that already exist.
        
        Output STRICT JSON:
        {{
            "files": [
                {{"path": "app/src/main/java/com/example/{safe_name}/ui/screens/HomeScreen.kt", "type": "kotlin"}},
                {{"path": "app/src/main/java/com/example/{safe_name}/data/AppModel.kt", "type": "kotlin"}}
            ]
        }}
        """

        try:
            response = self.brain.think(prompt, temperature=0.2)
            clean_json = response.replace("```json", "").replace("```", "").strip()
            # Try to catch common JSON errors (like trailing commas) if possible, or just exact try
            extra_structure = json.loads(clean_json)
            extra_files = extra_structure.get("files", [])
            
            print(f"{Fore.CYAN}   + AI suggested {len(extra_files)} additional component files.")
            files_to_create.extend(extra_files)
            
        except Exception as e:
            print(f"{Fore.RED}⚠️ [WARN] AI Architecture suggestions failed ({e}). Proceeding with Golden Path only.")

        # --- 3️⃣ Create Directories & Placeholders ---
        for file_info in files_to_create:
            full_path = os.path.join(project_path, file_info['path'])
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            if not os.path.exists(full_path):
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write("// Generating...")

        self.save_project_metadata(app_name, project_path)
        return project_path, files_to_create

    # --- PHASE 2: GHOST CODER (The Writing) ---
    def step_3_to_7_generate_and_code(self, app_name):
        """
        Loops through the empty files and fills them with AI-generated code.
        """
        project_path, files_list = self.step_2_create_project_wizard(app_name)
        
        print(f"{Fore.MAGENTA}⚡ [ANDROID AGENT] Writing Code for {len(files_list)} files...")
        config.speech_queue.put(f"Generating code for {len(files_list)} files. This may take a moment.")

        safe_name = app_name.lower().replace(" ", "")
        
        for file_info in files_list:
            rel_path = file_info['path']
            file_type = file_info.get('type', 'code')
            full_path = os.path.join(project_path, rel_path)
            
            print(f"{Fore.YELLOW}   ✍️ Coding: {rel_path}...")
            
            # --- CONTEXT CONSTRUCTION ---
            # We explicitly tell the AI about the file's purpose to guide the content
            
            system_instruction = f"You are an Expert Android Developer writing for Package: {self.package_name}."
            
            if "gradle_root" in file_type:
                prompt_content = """
                Write the root 'build.gradle.kts'.
                Include the 'com.android.application' and 'org.jetbrains.kotlin.android' plugins, versions '8.2.0' and '1.9.0' respectively.
                Output ONLY the code.
                """
            elif "gradle_props" in file_type:
                 prompt_content = """
                 Write 'gradle.properties'.
                 Inlcude:
                 org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
                 android.useAndroidX=true
                 # OPTIMIZATION: Enable Build Cache
                 org.gradle.caching=true
                 org.gradle.parallel=true
                 
                 Output ONLY the code.
                 """
            elif "gradle_settings" in file_type:
                prompt_content = f"""
                Write 'settings.gradle.kts'.
                Project name: "{app_name.replace(" ", "")}".
                Includes: ":app".
                
                CRITICAL: You MUST include this generic block at the top:
                pluginManagement {{
                    repositories {{
                        google()
                        mavenCentral()
                        gradlePluginPortal()
                    }}
                }}
                dependencyResolutionManagement {{
                    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                    repositories {{
                        google()
                        mavenCentral()
                    }}
                }}
                
                Output ONLY the code.
                """
            elif "gradle_app" in file_type:
                prompt_content = f"""
                Write 'app/build.gradle.kts' for a Jetpack Compose app.
                Namespace: "{self.package_name}"
                Plugins: android-application, kotlin-android.
                Dependencies: 
                - androidx.core:core-ktx:1.12.0
                - androidx.activity:activity-compose:1.8.2
                - androidx.compose:compose-bom:2023.08.00 (platform)
                - androidx.compose.ui:ui
                - androidx.compose.material3:material3
                - androidx.compose.ui:ui-tooling-preview
                
                Set minSdk 24, targetSdk 34.
                Output ONLY the code.
                """
            elif "manifest" in file_type:
                prompt_content = f"""
                Write 'AndroidManifest.xml'.
                Package: "{self.package_name}"
                Label: "{app_name}"
                Activity: .MainActivity (exported=true).
                Output ONLY the code.
                """
            elif "kotlin_main" in file_type:
                prompt_content = f"""
                Write 'MainActivity.kt'.
                Package: {self.package_name}
                Imports: androidx.activity.ComponentActivity, androidx.activity.compose.setContent, androidx.compose.material3.*, {self.package_name}.ui.theme.*
                
                Code:
                - Class MainActivity : ComponentActivity()
                - onCreate calls setContent {{ {app_name.replace(" ","")}Theme {{ Surface {{ ... }} }} }}
                - Inside Surface, call a Composable function named '{app_name.replace(" ","")}App' (which you should define in this file or assume exists).
                
                Make it look nice.
                Output ONLY the code.
                """
            else:
                # Generic Code Fallback
                prompt_content = f"""
                Write the code for file: {rel_path}
                App Name: {app_name}
                Package: {self.package_name}
                Tech Stack: Kotlin, Jetpack Compose, Material3.
                
                If this is a Theme/Color file, provide standard modern Material3 values.
                If this is a Screen, make it interactive.
                
                Output ONLY the raw code.
                """

            full_prompt = f"{system_instruction}\n{prompt_content}"

            try:
                # Temperature low for config files, higher for creative code
                temp = 0.1 if "gradle" in file_type or "xml" in file_type else 0.4
                code = self.brain.think(full_prompt, temperature=temp)
                
                # Clean Markdown
                clean_code = code.replace("```kotlin", "").replace("```xml", "").replace("```kts", "").replace("```groovy", "").replace("```", "").strip()
                
                # Write to Disk
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(clean_code)
                    
            except Exception as e:
                print(f"{Fore.RED}   ❌ Failed to write {rel_path}: {e}")

        print(f"{Fore.GREEN}✅ [SUCCESS] {app_name} is ready at {project_path}")
        config.speech_queue.put(f"{app_name} is complete. You can open it now.")

        # Optional: Auto-Open
        self.open_in_studio(project_path)

    def open_in_studio(self, project_path):
        studio = self.find_android_studio()
        if studio:
            print(f"{Fore.GREEN}🚀 [LAUNCH] Opening Android Studio...")
            subprocess.Popen([studio, project_path])
        else:
            print(f"{Fore.RED}⚠️ [WARN] Android Studio not found. Opening folder.")
            os.startfile(project_path)

    # --- FLUTTER MODULE ---
    def create_flutter_app(self, app_name):
        print(f"{Fore.CYAN}🐦 [FLUTTER AGENT] Creating Cross-Platform App '{app_name}'...")
        config.speech_queue.put(f"Initializing Flutter engine for {app_name}.")
        
        if not self.check_flutter_installed():
             print(f"{Fore.RED}❌ Flutter not found in PATH.")
             config.speech_queue.put("Flutter SDK is missing. Please install it first.")
             return

        safe_name = app_name.lower().replace(" ", "_")
        project_path = os.path.join(self.projects_root, safe_name)
        
        # Run 'flutter create'
        try:
            cmd = f"flutter create --org com.example {safe_name}"
            subprocess.run(cmd, shell=True, cwd=self.projects_root, check=True)
            
            print(f"{Fore.GREEN}✅ [SUCCESS] Flutter Project Created: {project_path}")
            config.speech_queue.put(f"Flutter project created successfully.")
            
            # Open in VS Code (Preferred for Flutter) or Studio
            try:
                subprocess.run("code .", shell=True, cwd=project_path)
            except:
                self.open_in_studio(project_path)
                
            self.save_project_metadata(app_name, project_path)
            
        except subprocess.CalledProcessError as e:
            print(f"{Fore.RED}❌ Flutter Create Failed: {e}")
            config.speech_queue.put("Flutter creation failed.")

    # --- PHASE 3: BUILD & HEAL (The Loop) ---
    def run_build(self, project_path):
        """Runs the Gradle build and returns (success, output)."""
        print(f"{Fore.CYAN}🔨 [BUILD] Starting Gradle Assemblage in {project_path}...")
        
        gradlew = "gradlew.bat" if os.name == 'nt' else "./gradlew"
        cmd = f"{gradlew} assembleDebug"
        
        try:
            # increasing timeout to 5 mins for first build
            result = subprocess.run(
                cmd, 
                cwd=project_path, 
                shell=True, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE,
                text=True,
                timeout=300 
            )
            
            output = result.stdout + "\n" + result.stderr
            if result.returncode == 0:
                print(f"{Fore.GREEN}✅ [BUILD] Build Successful!")
                return True, output
            else:
                print(f"{Fore.RED}❌ [BUILD] Build Failed.")
                return False, output
                
        except subprocess.TimeoutExpired:
            return False, "Build Timed Out."
        except Exception as e:
            return False, str(e)

    def analyze_and_fix(self, project_path, error_log):
        """Sends error to Brain, gets JSON fix, applies it."""
        print(f"{Fore.MAGENTA}🚑 [HEAL] Analyzing Build Error (Size: {len(error_log)} chars)...")
        config.speech_queue.put("Build failed. Analyzing error for fixes.")

        # Truncate log if too huge, keep end where errors usually are
        if len(error_log) > 8000:
            error_log = "..." + error_log[-8000:]

        prompt = f"""
        Act as a Senior Android Debugger.
        The Gradle build failed. Here is the output:
        
        {error_log}
        
        ERROR ANALYSIS:
        1. Identify the specific file and line causing the error.
        2. If it's a version mismatch (e.g. Java 17 vs 1.8), fix 'build.gradle.kts' (app or root).
        3. If it's a code error, fix the Kotlin file.
        
        OUTPUT STRICT VALID JSON ONLY (No Markdown, No Explanations):
        {{
            "file_path": "app/src/main/java/.../MainActivity.kt", 
            "fixed_content": "The COMPLETE replacement content of the file."
        }}
        
        If multiple files need fixing, just fix the most critical one.
        If the file path is relative, assume it's relative to project root.
        """
        
        try:
            response = self.brain.think(prompt, temperature=0.1)
            
            # IMPROVED JSON PARSING
            import re
            # Find first { and last }
            match = re.search(r'\{.*\}', response, re.DOTALL)
            if match:
                clean_json = match.group(0)
            else:
                clean_json = response.replace("```json", "").replace("```", "").strip()
            
            fix_data = json.loads(clean_json)
            rel_path = fix_data["file_path"]
            new_content = fix_data["fixed_content"]
            
            # Apply Fix
            full_path = os.path.join(project_path, rel_path)
            
            if os.path.exists(full_path):
                # Backup first? Maybe later.
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(new_content)
                print(f"{Fore.GREEN}✅ [HEAL] Applied fix to {rel_path}")
                config.speech_queue.put("I have applied a fix to the code.")
                return True
            else:
                print(f"{Fore.RED}❌ [HEAL] AI suggested non-existent file: {rel_path}")
                return False
                
        except json.JSONDecodeError:
            print(f"{Fore.RED}❌ [HEAL] AI did not return valid JSON.")
            return False
        except Exception as e:
            print(f"{Fore.RED}❌ [HEAL] Heal Error: {e}")
            return False

    def build_and_heal(self, app_name, max_retries=3):
        """The Main Loop: Build -> Fail -> Heal -> Retry."""
        safe_name = app_name.lower().replace(" ", "")
        project_path = os.path.join(self.projects_root, app_name.replace(" ", "")) # Using the space-removed folder name convention from wizard
        
        # Check Project Exists
        if not os.path.exists(project_path):
            # Try finding it in config
            project_path = os.path.join(self.projects_root, safe_name) # Try strict safe name
            if not os.path.exists(project_path):
                print(f"{Fore.RED}❌ Project {app_name} not found.")
                return

        print(f"{Fore.CYAN}🔄 [LOOP] Starting Build & Heal Loop for {app_name}")
        
        for attempt in range(1, max_retries + 1):
            print(f"\n--- Attempt {attempt}/{max_retries} ---")
            success, log = self.run_build(project_path)
            
            if success:
                print(f"{Fore.GREEN}🏆 [SUCCESS] App Built Successfully!")
                config.speech_queue.put(f"{app_name} build complete and successful.")
                # Optional: install
                return
            
            # If failed, Try to Heal
            if attempt < max_retries:
                healed = self.analyze_and_fix(project_path, log)
                if not healed:
                    print(f"{Fore.RED}🛑 [STOP] Could not apply fix. Stopping loop.")
                    break
            else:
                print(f"{Fore.RED}💀 [FAIL] Max retries reached. Build Failed.")
                config.speech_queue.put("I could not fix the build errors automatically.")

    # --- PHASE 3: LEGACY DEBUGGER (The Fixer) ---
    def fix_code_from_clipboard(self):
        """
        Reads error from clipboard -> Asks AI -> Pastes Fix back to clipboard.
        """
        print(f"{Fore.MAGENTA}🔧 [DEBUG] Reading Clipboard Error...")
        
        error_msg = pyperclip.paste()
        if not error_msg or len(error_msg) < 5:
            config.speech_queue.put("Clipboard is empty. Copy the error first.")
            return

        print(f"{Fore.CYAN}🕵️ [DEBUG] Analyzing: {error_msg[:60]}...")
        config.speech_queue.put("Analyzing error...")

        prompt = f"""
        Act as an Expert Android Architect.
        Fix this Android Build Error.
        Error: {error_msg}
        
        RULES:
        1. If the error is "Plugin not found", the FIX is usually missing repositories in 'settings.gradle.kts'.
           In that case, output the FULL 'settings.gradle.kts' with:
           pluginManagement {{ repositories {{ google(); mavenCentral(); gradlePluginPortal() }} }}
           
        2. If it's a syntax error, fix the specific code.
        
        Output ONLY the raw code for the file that needs fixing.
        """
        
        fix = self.brain.think(prompt, temperature=0.1)
        clean_fix = fix.replace("```kotlin", "").replace("```", "").strip()
        
        pyperclip.copy(clean_fix)
        
        print(f"{Fore.GREEN}✅ [FIX] Solution copied to clipboard!")
        config.speech_queue.put("Fix is in your clipboard. Paste it now.")

    # --- PHASE 4: MIND REMOTE CORTEX (Mobile Client) ---
    def generate_mind_client(self):
        """
        Generates the specialized 'MIND Client' App for USB Tethering.
        """
        app_name = "MIND Client"
        print(f"{Fore.CYAN}📱 [ANDROID AGENT] Building MIND Remote Cortex Client...")
        config.speech_queue.put("Constructing the Mobile Interface. Stand by.")

        # 1. Scaffold Base Project
        project_path, files = self.step_2_create_project_wizard(app_name)
        
        # 2. Overwrite MainActivity with Client Logic
        main_activity_path = f"{project_path}/app/src/main/java/com/example/mindclient/MainActivity.kt"
        
        # Ensure path exists (wizard uses safe name)
        os.makedirs(os.path.dirname(main_activity_path), exist_ok=True)

        client_code = r"""
package com.example.mindclient

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MINDClientApp()
        }
    }
}

@Composable
fun MINDClientApp() {
    var serverIp by remember { mutableStateOf("192.168.1.1") } // Default Gateway
    var statusText by remember { mutableStateOf("Offline") }
    var detectedState by remember { mutableStateOf("IDLE") }
    var commandInput by remember { mutableStateOf("") }
    var responseLog by remember { mutableStateOf("Log:\n") }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp).background(Color.Black),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("MIND REMOTE CORTEX", color = Color.Green, style = MaterialTheme.typography.headlineMedium)
        
        Spacer(modifier = Modifier.height(20.dp))

        // IP Config
        OutlinedTextField(
            value = serverIp,
            onValueChange = { serverIp = it },
            label = { Text("Server IP (USB)") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.Gray
            )
        )

        Spacer(modifier = Modifier.height(10.dp))
        
        // Status Display
        Text("Status: $statusText", color = Color.Cyan)
        Text("Brain State: $detectedState", color = if(detectedState=="THINKING") Color.Yellow else Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        // HUD Poll Button
        Button(onClick = {
            scope.launch(Dispatchers.IO) {
                try {
                    val url = URL("http://$serverIp:8000/status")
                    val conn = url.openConnection() as HttpURLConnection
                    conn.readTimeout = 2000
                    val jsonStr = conn.inputStream.bufferedReader().readText()
                    val json = JSONObject(jsonStr)
                    
                    withContext(Dispatchers.Main) {
                        statusText = json.optString("status_text")
                        detectedState = json.optString("state")
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { statusText = "Error: ${e.message}" }
                }
            }
        }) {
            Text("SYNC HUD")
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Command Input
        OutlinedTextField(
            value = commandInput,
            onValueChange = { commandInput = it },
            label = { Text("Command") },
             colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.Gray
            )
        )

        Button(onClick = {
            val cmd = commandInput
            responseLog += "> $cmd\n"
            scope.launch(Dispatchers.IO) {
                try {
                    val url = URL("http://$serverIp:8000/command")
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json")
                    
                    val payload = "{\"text\": \"$cmd\"}"
                    conn.outputStream.use { it.write(payload.toByteArray()) }
                    
                    val resp = conn.inputStream.bufferedReader().readText()
                    val respJson = JSONObject(resp)
                    val reply = respJson.optString("response")
                    
                    withContext(Dispatchers.Main) {
                        responseLog += "MIND: $reply\n\n"
                        commandInput = ""
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { responseLog += "Error: ${e.message}\n" }
                }
            }
        }) {
            Text("SEND COMMAND")
        }
        
        Spacer(modifier = Modifier.height(10.dp))
        
        Text(responseLog, color = Color.Green, modifier = Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()))
    }
}
"""
        with open(main_activity_path, "w", encoding="utf-8") as f:
            f.write(client_code)

        # 3. Add INTERNET Permission to Manifest
        manifest_path = f"{project_path}/app/src/main/AndroidManifest.xml"
        manifest_code = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="MIND Client"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MINDClient">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.MINDClient">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>"""
        with open(manifest_path, "w", encoding="utf-8") as f:
            f.write(manifest_code)
            
        print(f"{Fore.GREEN}✅ [SUCCESS] MIND Client ready at {project_path}")
        print(f"{Fore.GREEN}👉 Open in Android Studio and Run on Device!")
        
        self.open_in_studio(project_path)