import os
import subprocess
from colorama import Fore
import config

class QtAgent:
    def __init__(self):
        self.projects_root = os.path.join(config.DEFAULT_PROJECTS_DIR, "QtProjects")
        self.qt_creator_path = config.APP_LIBRARY.get("qt creator")
        
        if not os.path.exists(self.projects_root):
            os.makedirs(self.projects_root)

    def create_project(self, app_name, project_type="widget"):
        """
        Generates a standard Qt Widgets C++ project.
        """
        print(f"{Fore.CYAN}🛠️ [QT] Forging Project: {app_name}...")
        config.hud_queue.put(f"QT: CREATING {app_name.upper()}")
        config.speech_queue.put(f"Forging C++ architecture for {app_name}.")

        safe_name = app_name.replace(" ", "")
        project_dir = os.path.join(self.projects_root, safe_name)
        
        if not os.path.exists(project_dir):
            os.makedirs(project_dir)

        # 1. Generate .pro file
        pro_content = f"""
QT       += core gui
greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# Optimization Flags
CONFIG += release
QMAKE_CXXFLAGS += -O2

# REFACTOR: Pre-Compiled Headers (PCH) for 40% faster builds
PRECOMPILED_HEADER = stable.h

# The following define makes your compiler emit warnings if you use
# any Qt feature that has been marked as deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

SOURCES += \\
    main.cpp \\
    mainwindow.cpp

HEADERS += \\
    mainwindow.h

# Default rules for deployment.
qnx: target.path = /tmp/$${{TARGET}}/bin
else: unix:!android: target.path = /opt/$${{TARGET}}/bin
!isEmpty(target.path): INSTALLS += target
"""
        with open(os.path.join(project_dir, f"{safe_name}.pro"), "w") as f:
            f.write(pro_content)

        # 1.5 Generate PCH
        pch_content = """
#if defined __cplusplus
#include <vector>
#include <string>
#include <QMainWindow>
#include <QApplication>
#include <QWidget>
#endif
"""
        with open(os.path.join(project_dir, "stable.h"), "w") as f:
            f.write(pch_content)

        # 2. Generate main.cpp
        main_cpp = """
#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
"""
        with open(os.path.join(project_dir, "main.cpp"), "w") as f:
            f.write(main_cpp)

        # 3. Generate mainwindow.h
        header_content = """
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
};
#endif // MAINWINDOW_H
"""
        with open(os.path.join(project_dir, "mainwindow.h"), "w") as f:
            f.write(header_content)

        # 4. Generate mainwindow.cpp
        cpp_content = """
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    // Setup UI
    resize(800, 600);
    setWindowTitle("MIND Generated App");
}

MainWindow::~MainWindow()
{
}
"""
        with open(os.path.join(project_dir, "mainwindow.cpp"), "w") as f:
            f.write(cpp_content)

        print(f"{Fore.GREEN}✅ [QT] Project Created: {project_dir}")
        config.speech_queue.put(f"Qt project {app_name} is ready.")
        
        # Launch
        self.launch_ide(os.path.join(project_dir, f"{safe_name}.pro"))
        return f"Created {app_name} at {project_dir}"

    def launch_ide(self, project_file):
        if self.qt_creator_path and os.path.exists(self.qt_creator_path):
            print(f"{Fore.GREEN}🚀 [QT] Launching IDE...")
            subprocess.Popen([self.qt_creator_path, project_file])
            config.speech_queue.put("Opening Qt Creator.")
        else:
            print(f"{Fore.RED}⚠️ [QT] Qt Creator not found at configured path.")
            config.speech_queue.put("I cannot find Qt Creator executable.")
