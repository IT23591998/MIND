import json
import os
import time
import config
from colorama import Fore

class EgoAgent:
    def __init__(self):
        self.stats_file = os.path.join(config.ASSETS_DIR, "mind_ego_stats.json")
        self._load_stats()
        
    def _load_stats(self):
        if os.path.exists(self.stats_file):
            with open(self.stats_file, 'r') as f:
                self.stats = json.load(f)
        else:
            self.stats = {"commands_executed": 0, "errors": 0, "startTime": time.time()}

    def _save_stats(self):
        with open(self.stats_file, 'w') as f:
            json.dump(self.stats, f, indent=4)

    def log_event(self, success=True):
        self.stats["commands_executed"] += 1
        if not success:
            self.stats["errors"] += 1
        self._save_stats()

    def generate_report(self):
        """Generates a Markdown report of performance."""
        uptime = (time.time() - self.stats["startTime"]) / 3600
        cmds = self.stats["commands_executed"]
        errs = self.stats["errors"]
        rate = (errs / cmds * 100) if cmds > 0 else 0
        
        report = f"""
# MIND Ego Report 🧠
**Uptime**: {uptime:.2f} hours
**Commands**: {cmds}
**Errors**: {errs} ({rate:.1f}%)

## Recommendations
- [ ] Optimization: Error rate is {'High' if rate > 5 else 'Acceptable'}.
- [ ] Skill Gap: Consider updating Llama model if Code Generation latency > 5s.
        """
        
        report_path = os.path.join(config.WORKSPACE, "Ego_Report.md")
        with open(report_path, "w") as f:
            f.write(report)
            
        return f"Self-Report generated at {report_path}"
