import requests
from colorama import Fore

class WikiAgent:
    def __init__(self):
        self.api_url = "https://en.wikipedia.org/w/api.php"
        self.headers = {
            'User-Agent': 'MIND_AI_Assistant/1.0 (contact@mind_project.local)'
        }

    def search_wiki(self, query, limit=3):
        """Searches Wikipedia for the given query."""
        params = {
            "action": "opensearch",
            "search": query,
            "limit": limit,
            "namespace": 0,
            "format": "json"
        }
        try:
            r = requests.get(self.api_url, params=params, headers=self.headers, timeout=5)
            data = r.json()
            # data format: [query, [titles], [descriptions], [urls]]
            if len(data) >= 2 and data[1]:
                return data[1] # Return list of titles
            return []
        except Exception as e:
            print(f"{Fore.RED}⚠️ [WIKI] Search Error: {e}")
            return []

    def get_page_summary(self, title):
        """Fetches the introductory summary of a page."""
        params = {
            "action": "query",
            "format": "json",
            "prop": "extracts",
            "exintro": True,
            "explaintext": True,
            "titles": title
        }
        try:
            r = requests.get(self.api_url, params=params, headers=self.headers, timeout=5)
            data = r.json()
            pages = data[str("query")][str("pages")]
            for page_id in pages:
                # Return the first found page
                return pages[page_id].get("extract", "No summary available.")
        except Exception as e:
            print(f"{Fore.RED}⚠️ [WIKI] Summary Error: {e}")
            return None

    def get_page_content(self, title):
        """Fetches the full plain text content of a page (limited)."""
        params = {
            "action": "query",
            "format": "json",
            "prop": "extracts",
            "explaintext": True,
            "titles": title
        }
        try:
            r = requests.get(self.api_url, params=params, headers=self.headers, timeout=8)
            data = r.json()
            pages = data["query"]["pages"]
            for page_id in pages:
                return pages[page_id].get("extract", "")
        except Exception as e:
            print(f"{Fore.RED}⚠️ [WIKI] Content Error: {e}")
            return None
