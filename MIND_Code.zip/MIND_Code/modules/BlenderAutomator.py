import time
import pyautogui
import pyperclip
import pygetwindow as gw
import config
from mind_brain import MindBrain

class BlenderAutomator:
    def __init__(self):
        # Initialize the Brain ONCE
        self.brain = MindBrain()

    def generate_asset(self, description, complexity="simple"):
        config.hud_queue.put(f"BLENDER: DESIGNING ({complexity.upper()})")
        config.speech_queue.put(f"Designing {description} ({complexity} mode)...")
        
        if complexity == "high_poly":
            # --- ADVANCED PROMPT: REALISM ---
            prompt = (
                f"Write a Python script for Blender (bpy) to create a REALISTIC HIGH-POLY: {description}.\n"
                "RULES:\n"
                "1. Start with: import bpy, bmesh, math\n"
                "2. CLEAR SCENE: bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete()\n"
                "3. USE MODIFIERS: Apply 'Subdivision Surface' (levels=2) or 'Bevel' for realism.\n"
                "4. SMOOTHING: Use bpy.ops.object.shade_smooth() on curved surfaces.\n"
                "5. GEOMETRY: You can use bmesh or intricate primitive combinations.\n"
                "6. MATERIALS: Create a simple Principled BSDF material with appropriate color/roughness.\n"
                "7. OUTPUT: A single joining mesh or logical hierarchy.\n"
                "8. NO COMMENTS. CODE ONLY.\n"
            )
            role = "Expert Technical Artist"
        else:
            # --- ROBUST PROMPT: LEGO STYLE (Default) ---
            # Forces the AI to use simple primitives to avoid complex math errors
            prompt = (
                f"Write a Python script for Blender (bpy) to create: {description}.\n"
                "RULES:\n"
                "1. Start with: import bpy\n"
                "2. CLEAR SCENE FIRST: bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete()\n"
                "3. USE ONLY PRIMITIVES: bpy.ops.mesh.primitive_cube_add, primitive_cone_add, etc.\n"
                "4. Combine shapes to make the object (e.g., Tree = Cylinder Trunk + Cone Leaves).\n"
                "5. NO BMESH. NO COMPLEX MATH. NO COMMENTS.\n"
                "6. CODE ONLY.\n"
            )
            role = "Blender Python Expert"
        
        try:
            # 🧠 USE CLOUD BRAIN
            script = self.brain.think(prompt, system_role=role)
            clean_code = script.replace("```python", "").replace("```", "").strip()
            
            self.execute_in_blender(clean_code)
            
        except Exception as e:
            print(f"Blender Brain Error: {e}")
            config.speech_queue.put("Design generation failed.")

    def execute_in_blender(self, code):
        config.hud_queue.put("BLENDER: RENDERING")
        config.speech_queue.put("Sending to Blender...")
        
        try:
            # 1. Focus Blender Window
            try:
                blender_window = gw.getWindowsWithTitle("Blender")[0]
                blender_window.activate()
            except IndexError:
                config.speech_queue.put("I can't find Blender open. I copied the code to your clipboard.")
                pyperclip.copy(code)
                return
            except Exception:
                pass # Continue blindly if window focus fails

            time.sleep(1) 
            
            # 2. CLEAR & PASTE (Assumes Scripting Tab is open)
            pyautogui.hotkey('ctrl', 'a')
            pyautogui.press('backspace')
            
            pyperclip.copy(code) 
            pyautogui.hotkey('ctrl', 'v') 
            
            time.sleep(0.5)
            config.speech_queue.put("Building object...")
            
            # 3. RUN SCRIPT (Alt + P is standard Blender run shortcut)
            pyautogui.hotkey('alt', 'p') 
            
        except Exception as e:
            print(f"Blender Execution Error: {e}")
            config.speech_queue.put("I couldn't run the script.")