import psutil
import config

class MonitorAgent:
    def get_system_report(self):
        """Returns a string summarizing system health."""
        cpu = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        battery = psutil.sensors_battery()
        
        report = f"CPU usage is at {cpu}%. Memory usage is at {mem.percent}%."
        
        if battery:
            plugged = "charging" if battery.power_plugged else "on battery"
            report += f" Battery is at {battery.percent}% and {plugged}."
            
        # Check Thermals
        thermal_warning, is_throttled = self.check_thermals()
        if is_throttled:
            report += f" [THROTTLED] {thermal_warning}"
            
        return report

    def check_thermals(self):
        """Checks if CPU/GPU is running too hot > 85C."""
        try:
            temps = psutil.sensors_temperatures()
            for name, entries in temps.items():
                for entry in entries:
                    if entry.current > 85:
                        return f"CRITICAL TEMP: {name} at {entry.current}°C", True
        except:
            pass # Sensors not available on all Windows configs
        return "Normal", False
