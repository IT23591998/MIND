import os
import time
import pyautogui
import pygetwindow as gw
import config  # Needed for exit_event

class HybridTyper:
    def __init__(self):
        # Broader keywords to detect coding environments
        self.targets = ["Android Studio", "Visual Studio Code", "Code", "JetBrains", "MainActivity", ".kt", "IntelliJ"]

    def smart_type(self, filepath, code_content, force_visual=False):
        """
        Intelligently decides whether to type visually or save to disk.
        """
        
        # 1. INITIAL CHECK: Are we already in the right window?
        try:
            active_window = gw.getActiveWindow()
            active_title = active_window.title if active_window else ""
            in_ide = any(t.lower() in active_title.lower() for t in self.targets)
        except:
            in_ide = False

        # If we are NOT in the IDE and not forced, just write to disk immediately (Speed boost)
        if not in_ide and not force_visual:
            print(f"[BACKGROUND] Instant write for {os.path.basename(filepath)}")
            self._write_to_disk(filepath, code_content)
            return

        # 2. GHOST TYPING LOOP
        print(f"[HYBRID] Ghost typing {os.path.basename(filepath)}...")
        lines = code_content.split('\n')

        for i, line in enumerate(lines):
            if config.exit_event.is_set(): return

            # Continuous Check: Did the user tab away?
            try:
                active_window = gw.getActiveWindow()
                active_title = active_window.title if active_window else ""
                still_in_ide = any(t.lower() in active_title.lower() for t in self.targets)
            except:
                still_in_ide = False

            # If user tabs away, ABORT typing and dump everything to disk
            if not still_in_ide and not force_visual:
                print(f"[BACKGROUND] Focus lost. Switching to silent write for {os.path.basename(filepath)}...")
                self._write_to_disk(filepath, code_content) # Write EVERYTHING, not just remaining
                return

            # Type the line
            pyautogui.write(line)
            pyautogui.press('enter')
            
            # Dynamic Sleep: Type faster on indented lines, slower on complex ones
            sleep_time = 0.002 if line.strip() == "" else 0.01
            time.sleep(sleep_time)

    def _write_to_disk(self, filepath, content):
        """Helper to safely write file to disk."""
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            with open(filepath, "w", encoding="utf-8") as f: 
                f.write(content)
            # Notify user to reload
            config.hud_queue.put("FILE SAVED SILENTLY")
        except Exception as e:
            print(f"Disk Write Error: {e}")