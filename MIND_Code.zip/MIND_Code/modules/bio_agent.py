import json
import os
import time
import config
from colorama import Fore

class BioAgent:
    def __init__(self):
        self.bio_db = os.path.join(config.ASSETS_DIR, "bio_stats.json")
        self._load_db()
        self.session_start = time.time()

    def _load_db(self):
        if os.path.exists(self.bio_db):
            with open(self.bio_db, 'r') as f:
                self.data = json.load(f)
        else:
            self.data = {"calories": 0, "target": 2000, "log": []}

    def _save_db(self):
        with open(self.bio_db, 'w') as f:
            json.dump(self.data, f, indent=4)

    def log_calories(self, item, kcal):
        """Logs food intake."""
        self.data["calories"] += kcal
        entry = {"time": time.time(), "item": item, "kcal": kcal}
        self.data["log"].append(entry)
        self._save_db()
        
        deficit = self.data["target"] - self.data["calories"]
        return f"Logged {item}. Deficit: {deficit} kcal."

    def check_health_status(self):
        """
        Logic: If (Hours_Coded > 6) AND (Kcal_Deficit > 500), alert.
        """
        hours_coded = (time.time() - self.session_start) / 3600
        deficit = self.data["target"] - self.data["calories"]
        
        stats = f"Session: {hours_coded:.1f}h | Deficit: {deficit} kcal"
        
        if hours_coded > 6 and deficit > 500:
            alert = "⚠️ BOSS, COGNITIVE LAG DETECTED. 20min REST + PROTEIN SNACK REQUIRED."
            config.speech_queue.put(alert)
            return f"{stats}\n{alert}"
            
        return stats
