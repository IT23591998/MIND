import sys
import os
import time
from colorama import Fore, Style, init

# Initialize Dashboard Colors
init(autoreset=True)

def print_status(component, status, message=""):
    if status:
        print(f"{Fore.GREEN}✅ [ONLINE]  {component:<20} {Fore.WHITE}{message}")
    else:
        print(f"{Fore.RED}❌ [OFFLINE] {component:<20} {Fore.YELLOW}{message}")

print(Fore.CYAN + "\n=================================================")
print(Fore.CYAN + "   MIND PROTOCOL: SYSTEM INTEGRITY CHECK (v2.0)  ")
print(Fore.CYAN + "=================================================\n")

# 1. CHECK MATH CORE (Numpy)
try:
    import numpy
    # We want 1.23.5 ideally, but as long as it imports, we are good.
    print_status("Math Core (Numpy)", True, f"v{numpy.__version__}")
except ImportError as e:
    print_status("Math Core", False, str(e))

# 2. CHECK BRAIN (LiteLLM)
try:
    from litellm import completion
    print_status("Neural Net (LiteLLM)", True, "Ready for GitHub Models")
except ImportError as e:
    print_status("Neural Net", False, str(e))

# 3. CHECK MEMORY (ChromaDB)
try:
    import chromadb
    print_status("LTM Memory (Chroma)", True, "Database Driver Loaded")
except ImportError as e:
    print_status("LTM Memory", False, str(e))

# 4. CHECK EARS (Speech Recognition)
try:
    import speech_recognition as sr
    # Quick mic check object creation
    r = sr.Recognizer()
    print_status("Auditory (SpeechRec)", True, "Microphone Access Ready")
except ImportError as e:
    print_status("Auditory", False, str(e))

# 5. CHECK VOICE (TTS Engine)
print(Fore.YELLOW + "⏳ Initializing Vocal Core (This may take 10s)...")
try:
    # We suppress the loud logs from TTS for this check
    import sys, io
    old_stdout = sys.stdout
    # sys.stdout = io.StringIO() # Uncomment to silence logs if you want
    
    from TTS.api import TTS
    
    # Restore print capability
    sys.stdout = old_stdout
    print_status("Vocal Core (Coqui)", True, "TTS Engine Initialized")
except ImportError as e:
    sys.stdout = old_stdout
    print_status("Vocal Core", False, f"CRITICAL: {e}")
except Exception as e:
    sys.stdout = old_stdout
    print_status("Vocal Core", False, f"CRITICAL: {e}")

print(Fore.CYAN + "\n=================================================")
print(Fore.CYAN + "           DIAGNOSTIC COMPLETE                   ")
print(Fore.CYAN + "=================================================\n")