
import sys
import os
sys.path.append("d:/MIND_Project")
from modules.datacore_agent import DataCoreAgent
from colorama import init, Fore
init(autoreset=True)

def analyze_biogas():
    agent = DataCoreAgent()
    file_path = "d:/MIND_Project/Farm-scale Biodigester 2024_Performance.xlsx"
    
    # Target column identified from inspection
    target = "Daily CH4 at STP (mL)"
    
    print(f"Running Diagnostic on {file_path}...")
    try:
        report = agent.analyze_diagnostic(file_path)
        print("\n--- FINAL REPORT ---")
        print(report)
    except Exception as e:
        print(f"Diagnostic failed: {e}")

if __name__ == "__main__":
    analyze_biogas()
