import os
import time
import json
import uvicorn
from fastapi import FastAPI, HTTPException, UploadFile, File
from pydantic import BaseModel
from colorama import Fore, init

# Import MIND Core
from mind_brain import MindBrain
import config

init(autoreset=True)

app = FastAPI(title="MIND Remote Cortex API")

# Initialize Brain
print(f"{Fore.CYAN}🚀 [SERVER] Initializing MIND Brain...")
brain = MindBrain()

# Models
class CommandRequest(BaseModel):
    text: str
    user_id: str = "admin"

class TextResponse(BaseModel):
    response: str
    action_taken: str = "none"

# --- ENDPOINTS ---

@app.get("/")
def health_check():
    return {"status": "online", "system": "MIND Remote Cortex"}

@app.get("/status")
def get_status():
    """Reads the HUD status file."""
    try:
        if os.path.exists("D:/MIND_Project/hud_status.json"):
            with open("D:/MIND_Project/hud_status.json", "r") as f:
                return json.load(f)
    except Exception as e:
        return {"error": str(e)}
    return {"status_text": "Unknown", "state": "OFFLINE"}

@app.post("/command", response_model=TextResponse)
def process_command(cmd: CommandRequest):
    """Processes text command via MIND Brain."""
    print(f"{Fore.YELLOW}📲 [MOBILE] Command: {cmd.text}")
    
    # Logic similar to mind_core_loop but simplified for API
    try:
        response = brain.think(cmd.text)
        
        # Check for Actions (simple implementation)
        action = "chat"
        # We could parse the response or usage logic from mind_full.py routing here
        # For now, we return the thinking result.
        
        return TextResponse(response=response, action_taken=action)
    except Exception as e:
        print(f"{Fore.RED}❌ Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/listen")
async def upload_audio(file: UploadFile = File(...)):
    """Receives audio file, transcribes, and executes."""
    # Save temp
    temp_path = "D:/MIND_Project/mobile_input.wav"
    with open(temp_path, "wb") as f:
        f.write(await file.read())
    
    # We need to transcribe. 
    # Option 1: Load Whisper here (Memory heavy?)
    # Option 2: Use the main loop's capability?
    # For now, let's assume we load a lightweight model or delegate.
    # To keep this file simple, we might skip STT here and rely on text commands 
    # OR we implement it if the user wants voice-to-voice on phone.
    # Given mobile storage constraints, STT on Server is better.
    
    return {"msg": "Audio received (STT pending implementation in server)"}

if __name__ == "__main__":
    import socket
    # Get USB IP usually starts with 192.168...
    hostname = socket.gethostname()
    local_ip = socket.gethostbyname(hostname)
    
    print(f"{Fore.GREEN}🌍 [SERVER] MIND Remote Cortex running on {local_ip}:8000")
    print(f"{Fore.GREEN}👉 Point your Mobile Client to: http://{local_ip}:8000")
    
    uvicorn.run(app, host="0.0.0.0", port=8000)
