class TestAgent:
    def run(self): print('Hello')