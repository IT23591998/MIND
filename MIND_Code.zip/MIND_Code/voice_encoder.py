from resemblyzer import VoiceEncoder, preprocess_wav
from pathlib import Path
import numpy as np

# 1. Initialize Encoder
encoder = VoiceEncoder()

# 2. Path to your ElevenLabs-quality sample
# Make sure this file is in your assets folder!
fpath = Path("D:/MIND_Project/assets/system_core.wav")
wav = preprocess_wav(fpath)

# 3. Create the 256-value "System Core" Fingerprint
fingerprint = encoder.embed_utterance(wav)

# 4. Save it as the permanent ID
np.save("D:/MIND_Project/assets/mind_identity.npy", fingerprint)

print("--- [SYSTEM CORE] IDENTITY LOCKED ---")
print(f"MIND's permanent voice DNA is now secured from: {fpath.name}")