# MIND: Local-First AI Assistant

MIND is a comprehensive, local-first artificial intelligence system designed to integrate voice commands, automation, and specialized agentic capabilities into a cohesive personal assistant.

## System Architecture

The system operates on a "shattered" architecture where specialized components work seamlessly together:

### 1. The Core (Brain)
*   **`mind_brain.py` & `mind_core_loop.py`**: The central nervous system. It processes inputs (Text, Voice) and routes them to the appropriate specialized agents using a Neural Router (powered by local LLMs or DeepSeek).
*   **Decentralized Intelligence**: Instead of one massive model, MIND uses multiple specialized agents (`modules/`) for tasks like coding, media control, and home automation.

### 2. Mobile Integration
*   The system bridges the desktop environment with mobile devices via the **Mobile Agent** (`modules/android_agent.py`) and companion apps in `mobile_projects/`.
*   Communication happens via a local HTTP/WebSocket server (`mind_server.py`), allowing MIND to push notifications, trigger app generation on the phone, or receive voice commands remotely.

### 3. OSINT & Reconnaissance
*   Specialized agents perform Open Source Intelligence gathering.
*   **Face Hunter**: Integrates facial recognition to link online identities with real-world faces.
*   **Data Analysis**: Tools in `osint_reports` provide actionable insights from gathered data.

### 4. Knowledge & Memory
*   **`modules/memory_agent.py`**: Manages context and long-term memory, ensuring MIND remembers user preferences and past interactions.
*   **Offline First**: All critical documentation and "skills" are indexed locally to function without consistent internet access.

## Core Workflows

### 1. The Voice Interaction Loop
1.  **Wake Word Detection**: `openwakeword` listens locally for "Hey MIND".
2.  **Speech-to-Text (STT)**: `Faster-Whisper` converts audio to text instantly on the GPU.
3.  **Intent Classification**: The Neural Router analyzes the text to decide which module handles the request (e.g., "Play music" -> Media Agent).
4.  **Action Execution**: The selected agent performs the task (e.g., opens Spotify, writes code, scans network).
5.  **Text-to-Speech (TTS)**: MIND responds using a high-quality local TTS engine.

### 2. Mobile-to-Desktop Bridge
1.  **Remote Command**: User speaks/types into the MIND Android app.
2.  **Secure Transmission**: The request is sent via WebSocket to the desktop `mind_server.py`.
3.  **Execution**: The desktop system processes the command as if spoken locally.
4.  **Response**: The result is pushed back to the phone as a notification or voice response.

### 3. Agentic Task Execution
*   **Coding**: The Coding Agent can read local files, plan changes, and execute edits autonomously.
*   **OSINT**: The Security Agent creates a "target profile," scrapes data from specified sources, and cross-references it with local databases/face recognition models.


## Getting Started

### Prerequisites
*   Python 3.10+
*   Dependencies listed in `requirements.txt`
*   (Optional) External Model Pack (see `models/DOWNLOAD_INSTRUCTIONS.txt`)

### Installation
1.  Clone the repository.
2.  Install dependencies:
    ```bash
    pip install -r requirements.txt
    ```
3.  Run the main system:
    ```bash
    python run_mind.py
    ```

## Project Structure
*   `modules/`: Specialized agent implementations.
*   `models/`: Placeholders for large AI models (Download separately).
*   `assets/`: Visual assets and evidence of 3D capabilities.
*   `doc/`: Project documentation.
