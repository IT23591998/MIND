import os
import time
from litellm import completion
from dotenv import load_dotenv
from colorama import Fore
from modules.memory_agent import MemoryAgent
import requests
import psutil

# MONITORING CONSTANTS
VRAM_THRESHOLD = 85 # Unload if GPU VRAM > 85%

load_dotenv()
os.environ["TIKTOKEN_CACHE_DIR"] = r"D:\MIND_Project\cache"

load_dotenv()

class DynamicModelLoader:
    """Manages VRAM usage by unloading Ollama models."""
    @staticmethod
    def check_gpu_pressure():
        # TODO: Use nvml for real GPU stats. For now, use RAM as proxy or heuristic.
        # If RAM > 90%, assume high pressure
        mem = psutil.virtual_memory().percent
        return mem > VRAM_THRESHOLD

    @staticmethod
    def unload_model(model_name):
        """Forces Ollama to unload a model from VRAM."""
        try:
            # Ollama API: Generate with keep_alive=0 unloads it
            requests.post("http://localhost:11434/api/generate", json={
                "model": model_name,
                "keep_alive": 0
            })
            print(f"{Fore.YELLOW}📉 [BRAIN] Unloaded {model_name} to free VRAM.")
        except:
            pass

from modules.meta_reasoning import MetaLogEntry
import json
import re

class MindBrain:
    def __init__(self):
        self.loader = DynamicModelLoader()
        # Initialize Memory
        self.memory = MemoryAgent()
        self.locked_role = None # Locked Persona State
        
        # Load Long-Term Context (Last 10 messages from DB)
        self.history = self.memory.get_recent_context(limit=10)
        self.max_history = 10 
        
        # Load GLM Config
        self.glm_token = None
        try:
            import json
            with open(r"D:\MIND_Project\glm_config.json", "r") as f:
                self.glm_token = json.load(f).get("access_token")
            print(f"{Fore.GREEN}🧠 [BRAIN] GLM-4.7 Token Loaded.")
        except:
            print(f"{Fore.YELLOW}⚠️ [BRAIN] GLM-4.7 Token not found.")

        print(f"{Fore.GREEN}🧠 [BRAIN] Restored {len(self.history)} memories.")
        
        # --- THE 6 BRAINS OF MIND ---
        self.brains = {
            "THEORIST": {
                "name": "THEORIST (Ollama Local)",
                "model": "ollama/llama3", 
                "api_key": "local", 
                "desc": "Study, Theories, Deep Explanations (No Internet)"
            },
            "MINISTRAL": {
                "name": "MINISTRAL (Ollama Local)",
                "model": "ollama/ministral",
                "api_key": "local",
                "desc": "Efficient, Fast Reasoning, French/English"
            },
            "CODER": {
                "name": "CODER (GitHub GPT-4o)",
                "model": "github/gpt-4o",
                "api_key": os.getenv("GITHUB_AD_TOKEN"),
                "desc": "Complex Code, Debugging, Architecture"
            },
            "MANAGER": {
                "name": "MANAGER (Groq Llama 3)",
                "model": "groq/llama-3.3-70b-versatile",
                "api_key": os.getenv("GROQ_API_KEY"),
                "desc": "Routing, Fast Chat, Decision Making"
            },
            "ANALYST": {
                "name": "ANALYST (Gemini Flash)",
                "model": "gemini/gemini-1.5-flash",
                "api_key": os.getenv("GEMINI_API_KEY"),
                "desc": "Data Analysis, Math, Logic"
            },
            "SECURITY": {
                "name": "SECURITY (GPT-4o Secure)",
                "model": "github/gpt-4o",
                "api_key": os.getenv("GITHUB_AD_TOKEN"),
                "desc": "OSINT, Safety, Vulnerability Checks"
            },
            "CREATIVE": {
                "name": "CREATIVE (Groq Llama 3)",
                "model": "groq/llama-3.3-70b-versatile",
                "api_key": os.getenv("GROQ_API_KEY"),
                "desc": "Creativity, writing, brainstorming"
            },
            "GLM": {
                "name": "GLM (SiliconFlow 4.7)",
                "model": "openai/zai-org/GLM-4.7",
                "api_key": os.getenv("SILICONFLOW_API_KEY"),
                "api_base": "https://api.siliconflow.cn/v1",
                "desc": "Advanced AGI, Complex Reasoning"
            },
            "DEEPSEEK": {
                "name": "DEEPSEEK (DeepSeek-R1)",
                "model": "openai/deepseek-ai/DeepSeek-R1",
                "api_key": os.getenv("SILICONFLOW_API_KEY"),
                "api_base": "https://api.siliconflow.cn/v1",
                "desc": "Reasoning, Code, Math"
            },
            "CEREBRAS": {
                "name": "SPEED (Cerebras Llama 3.3)",
                "model": "cerebras/llama-3.3-70b",
                "api_key": os.getenv("CEREBRAS_API_KEY"),
                "desc": "Ultra-Fast Inference"
            },
            "OSS_LLM": {
                "name": "GPT-OSS (120B Model)",
                "model": "openai/gpt-oss-120b",
                "api_key": os.getenv("SILICONFLOW_API_KEY"),
                "api_base": "https://api.siliconflow.cn/v1",
                "desc": "Massive Open-Source Knowledge Base"
            }
        }
        
        self.log_brain_status() # List brains on init

    def log_brain_status(self):
        print(f"\n{Fore.CYAN}--- ACTIVE NEURAL CENTERS (BRAINS) ---")
        print(f"{Fore.CYAN}{'ID':<12} | {'MODEL':<30} | {'ROLE'}")
        print(f"{Fore.CYAN}{'-'*70}")
        for key, info in self.brains.items():
            print(f"{Fore.CYAN}{key:<12} | {info['name'][:30]:<30} | {info['desc']}")
        print(f"{Fore.CYAN}{'-'*70}\n")

    def add_to_history(self, role, content):
        # 1. Save to DB (Persistent)
        self.memory.save_message(role, content)
        
        # 2. Update RAM (Short-Term)
        self.history.append({"role": role, "content": content})
        if len(self.history) > self.max_history:
            self.history.pop(0)

    def _determine_brain(self, text):
        """Routes the input to the correct brain."""
        text = text.lower()
        
        # 0. Direct Triggers - Specific Models First
        if "ministral" in text or "mistral" in text:
            return "MINISTRAL"
            
        if "glm" in text or "mind 4.7" in text or "advanced" in text or "conflict" in text or "mediate" in text or "dispute" in text:
            return "GLM"
        
        if "deepseek" in text or "r1" in text or "reason" in text or "solve" in text or "problem" in text or "logic" in text or "puzzle" in text or "why" in text or "how" in text:
            return "DEEPSEEK"
            
        if "fast" in text or "speed" in text or "cerebras" in text or "quick" in text:
            return "CEREBRAS"
            
        if "oss" in text or "open source" in text or "120b" in text:
            return "OSS_LLM"

        # 0.5. Ministral Triggers (Phrases)
        if any(w in text for w in ["quick check", "fast logic"]):
            return "MINISTRAL"

        # 1. THEORIST (Study / Theory)
        if any(w in text for w in ["theory", "study", "explain concept", "what is the meaning of", "academic", "thesis"]):
            return "THEORIST"
            
        # 2. CODER (Dev) - High Priority
        if any(w in text for w in ["code", "python", "script", "debug", "function", "class", "error", "exception", "java", "kotlin"]):
            return "CODER"
            
        # 3. SECURITY (Hacking / OSINT)
        if any(w in text for w in ["hack", "hunt", "osint", "exploit", "vulnerab", "ip address", "trace", "security"]):
            return "SECURITY"
            
        # 4. ANALYST (Data / Math)
        if any(w in text for w in ["analyze", "data", "plot", "graph", "chart", "calculate", "math", "average", "stats"]):
            return "ANALYST"
            
        # 5. CREATIVE (Writing)
        if any(w in text for w in ["write a story", "poem", "joke", "creative", "brainstorm"]):
            return "CREATIVE"
            
        # Default -> MANAGER for speed
        return "MANAGER"

    def think(self, user_input, system_role="You are MIND, a loyal and efficient AI. Always address the user as 'Sir'.", temperature=0.7):
        """Wrapped to return just the text for backward compatibility."""
        meta_log = self.think_with_meta(user_input, system_role, temperature)
        return meta_log.final_response

    def think_with_meta(self, user_input, system_role="You are MIND.", temperature=0.7):
        """
        Executes the thinking process and returns a MetaLogEntry with traceable confidence.
        """
        # 1. Update Memory
        self.add_to_history("user", user_input)
        
        # 2. Determine Persona / Routing
        from modules.personas import get_role_from_input, MIND_ROLES
        
        # Initialize Log
        log_entry = MetaLogEntry(task="General Query", persona="Unknown", input_text=user_input)

        # A. Check for Locking/Overrides
        brain_key = "MANAGER" # Default
        if "stay in" in user_input.lower() and "mode" in user_input.lower():
            scored_roles = get_role_from_input(user_input)
            if scored_roles and scored_roles[0][1] > 0.4:
                self.locked_role = scored_roles[0][0]
                log_entry.final_response = f"🔒 Persona Locked: {self.locked_role}."
                return log_entry

        if "reset role" in user_input.lower():
            self.locked_role = None
            log_entry.final_response = "🔓 Persona Unlocked."
            return log_entry

        # B. Resolve Active Role
        active_role = None
        if self.locked_role:
            active_role = self.locked_role
        else:
            scored_roles = get_role_from_input(user_input)
            if scored_roles and scored_roles[0][1] >= 0.7:
                active_role = scored_roles[0][0]

        # C. Apply Persona & Routing
        if active_role:
            data = MIND_ROLES[active_role]
            system_role = f"{data['prompt']}\n\nTONE: {data.get('tone','Professional')}"
            brain_key = data['brain']
            log_entry.persona = active_role
        else:
            brain_key = self._determine_brain(user_input)
            log_entry.persona = brain_key

        selected_brain = self.brains[brain_key]
        print(Fore.CYAN + f"🧠 [ROUTING] {brain_key} | {selected_brain['name']}")
        
        # D. Execute with Meta-Prompting
        # We ask the model to output a specific format if it's a capable model
        # For simplicity in this v1 implementation, we append a request for confidence if it's a 'smart' model
        
        is_smart = brain_key in ["MANAGER", "ANALYST", "THEORIST", "SECURITY", "GLM", "DEEPSEEK"]
        
        original_system_role = system_role
        
        # --- Memory Retrieval (RAG) for Reasoning ---
        # If we are in deep thought mode, check if we've solved similar things before.
        if brain_key in ["DEEPSEEK", "THEORIST", "SECURITY"]:
             memories = self.memory.search_memory(user_input, limit=2)
             if memories:
                 print(f"{Fore.MAGENTA}🧠 [MEMORY] Recalled {len(memories)} past items.")
                 memory_context = "\n\n[RELEVANT PAST MEMORIES]\n" + "\n".join(memories) + "\n[END MEMORIES]"
                 system_role += memory_context

        if is_smart and "json" not in user_input.lower(): # Don't break user JSON requests
            system_role += "\n\nIMPORTANT: At the end of your response, strictly output your confidence level (0.0 to 1.0) on a new line like: 'CONFIDENCE: 0.95'"

        messages = [{"role": "system", "content": system_role}] + self.history

        try:
            # Check Keys
            if selected_brain['api_key'] != "local" and not selected_brain['api_key']:
                 print(f"{Fore.YELLOW}⚠️ [BRAIN] Key missing for {brain_key}. Falling back to MANAGER.")
                 selected_brain = self.brains["MANAGER"] # Fallback
            
            # 2nd Fallback: If MANAGER key is also missing, use THEORIST (Local)
            if selected_brain['api_key'] != "local" and not selected_brain['api_key']:
                 print(f"{Fore.YELLOW}⚠️ [BRAIN] MANAGER key also missing. Falling back to THEORIST (Local).")
                 selected_brain = self.brains["THEORIST"]

            # Call API
            base_url = "http://localhost:11434" if "ollama" in selected_brain["model"] else selected_brain.get("api_base")
            
            try:
                response = completion(
                    model=selected_brain["model"],
                    messages=messages,
                    api_key=selected_brain["api_key"] if selected_brain["api_key"] != "local" else None,
                    temperature=temperature,
                    api_base=base_url
                )
            except Exception as lite_error:
                print(Fore.RED + f"⚠️ [BRAIN] LiteLLM Error: {lite_error}")
                # Fallback response for connection errors
                log_entry.add_step(f"Error: {lite_error}", 0.0)
                log_entry.final_response = "I encountered a neural network connection error, Sir. Please check my internet access."
                return log_entry
            
            reply = response.choices[0].message.content
            
            # E. Parse Meta-Data (Confidence)
            confidence_match = re.search(r"CONFIDENCE:\s*([0-9]*\.?[0-9]+)", reply)
            extracted_conf = 0.85 # Default
            
            final_text = reply
            if confidence_match:
                extracted_conf = float(confidence_match.group(1))
                # Remove the meta-line from the spoken output to keep it clean
                final_text = reply.replace(confidence_match.group(0), "").strip()
            
            # Log the step
            log_entry.add_step(f"{brain_key} Response", extracted_conf, sources=[selected_brain['model']])
            log_entry.compute_overall_confidence()
            log_entry.final_response = final_text
            
            self.add_to_history("assistant", final_text)
            
            # Print Meta-Log Status
            print(Fore.MAGENTA + f"📊 [META] Confidence: {log_entry.overall_confidence:.2f}")
            
            return log_entry

        except Exception as e:
            print(Fore.RED + f"⚠️ Brain Error: {e}")
            log_entry.add_step(f"Error: {e}", 0.0)
            log_entry.final_response = "I encountered a neural error, Sir."
            return log_entry