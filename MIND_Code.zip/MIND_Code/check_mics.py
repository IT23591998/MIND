import speech_recognition as sr

print("\n--- SEARCHING FOR EARS ---")
mics = sr.Microphone.list_microphone_names()

for i, mic_name in enumerate(mics):
    print(f"ID {i}: {mic_name}")

print("--------------------------")
print("Look for your headset or webcam in the list above.")
print("Remember the ID number next to it!")