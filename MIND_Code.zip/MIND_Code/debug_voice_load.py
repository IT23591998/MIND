from TTS.api import TTS
import os
import time

print("--- DEBUGGING VOICE ---")
try:
    print("1. Initializing TTS...")
    # Run synchronously to see errors
    model_name = "tts_models/multilingual/multi-dataset/your_tts"
    device = "cpu" # Force CPU for safety check first
    
    print(f"2. Loading {model_name} on {device}...")
    tts = TTS(model_name).to(device)
    print("✅ Model Loaded Successfully!")
    
    print("3. Testing Inference...")
    wav_path = r"d:\MIND_Project\assets\system_core.wav"
    if os.path.exists(wav_path):
        print(f"   Reference Audio Found: {os.path.getsize(wav_path)} bytes")
        tts.tts_to_file(text="Voice test.", speaker_wav=wav_path, language="en", file_path="test_voice.wav")
        print("✅ Inference Successful!")
    else:
        print("❌ system_core.wav NOT FOUND")

except Exception as e:
    print(f"\n❌ FATAL ERROR:\n{e}")
