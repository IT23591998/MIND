import sys
import os
import traceback

sys.path.append(os.getcwd())

print("Starting import tests...")

try:
    print("Importing modules.mcp...")
    from modules.mcp import MasterControlProgram
    print("✅ modules.mcp imported")
except Exception:
    print("❌ Failed to import modules.mcp")
    traceback.print_exc()

try:
    print("Importing modules.scheduler_agent...")
    from modules.scheduler_agent import SchedulerAgent
    print("✅ modules.scheduler_agent imported")
except Exception:
    print("❌ Failed to import modules.scheduler_agent")
    traceback.print_exc()

try:
    print("Importing modules.innovation_engine...")
    from modules.innovation_engine import InnovationEngine
    print("✅ modules.innovation_engine imported")
except Exception:
    print("❌ Failed to import modules.innovation_engine")
    traceback.print_exc()

try:
    print("Importing modules.music_agent...")
    from modules.music_agent import MusicAgent
    print("✅ modules.music_agent imported")
except Exception:
    print("❌ Failed to import modules.music_agent")
    traceback.print_exc()

try:
    print("Importing modules.face_hunter...")
    from modules.face_hunter import FaceHunter
    print("✅ modules.face_hunter imported")
except Exception:
    print("❌ Failed to import modules.face_hunter")
    traceback.print_exc()

print("Import test complete.")
