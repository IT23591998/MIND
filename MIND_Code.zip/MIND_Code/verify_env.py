
import sys
import os
from dotenv import load_dotenv

def check_env():
    load_dotenv(r"d:\MIND_Project\.env")
    print(f"Python Executable: {sys.executable}")
    
    dependencies = ["face_recognition", "deepface", "openwakeword", "tensorflow", "keras"]
    missing = []
    
    print("\n--- Checking Dependencies ---")
    for dep in dependencies:
        try:
            __import__(dep)
            print(f"[OK] {dep}")
        except ImportError as e:
            print(f"[FAIL] {dep}: {e}")
            missing.append(dep)
        except Exception as e:
            print(f"[ERROR] {dep}: {e}")

    print("\n--- Checking API Keys ---")
    key = os.getenv("SILICONFLOW_API_KEY")
    if key:
        print(f"[OK] SILICONFLOW_API_KEY found (Length: {len(key)})")
    else:
        print("[FAIL] SILICONFLOW_API_KEY is MISSING from environment variables")
        
    print("\n--- Summary ---")
    if not missing and key:
        print("SUCCESS: Environment is ready.")
    else:
        print("FAILURE: Issues detected.")

if __name__ == "__main__":
    check_env()
