import sounddevice as sd

print("\n--- SOUNDDEVICE AUDIO DEVICES ---")
print(sd.query_devices())
print("\n--- DEFAULTS ---")
print(f"Input: {sd.default.device[0]}")
print(f"Output: {sd.default.device[1]}")
