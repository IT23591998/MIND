import sounddevice as sd
import numpy as np
from scipy.io.wavfile import write
from faster_whisper import WhisperModel
import datetime
import os
import pygame

# 1. Setup
ASSETS_DIR = "D:/MIND_Project/assets"
pygame.mixer.init()

# Initialize Whisper on your RTX 2050
model_path = "D:/MIND_Project/models"
model = WhisperModel("tiny", device="cuda", compute_type="float16", download_root=model_path)

def play_sound(filename):
    file_path = os.path.join(ASSETS_DIR, f"{filename}.mp3")
    if os.path.exists(file_path):
        print(f"🔊 Playing: {filename}.mp3")
        pygame.mixer.music.load(file_path)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)
    else:
        print(f"⚠️ Error: {filename}.mp3 not found.")

def get_time_greeting_file():
    hour = datetime.datetime.now().hour
    if 5 <= hour < 12: return "good_morning"
    elif 12 <= hour < 18: return "good_afternoon"
    elif 18 <= hour < 22: return "good_evening"
    else: return "good_night"

def listen_for_wake_word():
    fs = 16000
    duration = 5 
    sd.default.device = 2 
    
    # Keyword Lists for "Fuzzy Matching"
    OFFLINE_KEYS = ["offline", "fly", "light", "goodbye", "shut down", "exit", "terminate"]
    INTRO_KEYS = ["introduce", "who are you", "identify", "produce", "introduction"]
    WAKE_KEYS = ["wake up", "hello", "hi", "hey", "online", "morning", "evening"]
    GPU_KEYS = ["gpu", "temp", "hardware", "performance", "check"]

    print("\n[MIND STATUS: ONLINE AND LISTENING]")
    
    while True:
        recording = sd.rec(int(duration * fs), samplerate=fs, channels=1)
        sd.wait()
        
        if np.max(np.abs(recording)) > 0:
            recording = recording / np.max(np.abs(recording))
            
        write("temp_wake.wav", fs, recording)
        
        segments, _ = model.transcribe("temp_wake.wav")
        for segment in segments:
            text = segment.text.lower()
            print(f"Heard: {text}")
            
            if "mind" in text:
                
                # --- COMMAND: GO OFFLINE ---
                if any(key in text for key in OFFLINE_KEYS):
                    play_sound("sys_offline")
                    print("\n[MIND STATUS: OFFLINE - SESSION TERMINATED]")
                    os.system('cls' if os.name == 'nt' else 'clear') # Clears terminal for a clean ending
                    os._exit(0) 

                # --- COMMAND: INTRODUCTION ---
                elif any(key in text for key in INTRO_KEYS):
                    play_sound("conf_acknowledge")
                    play_sound("intro_full")
                    play_sound("sys_ready")
                
                # --- COMMAND: WAKE UP / HELLO ---
                elif any(key in text for key in WAKE_KEYS):
                    play_sound("sys_wakeup")
                    play_sound(get_time_greeting_file())
                    play_sound("greet_name")
                    play_sound("sys_ready")

                # --- COMMAND: GPU CHECK ---
                elif any(key in text for key in GPU_KEYS):
                    play_sound("gpu_check")
                    play_sound("sys_ready")

if __name__ == "__main__":
    play_sound("sys_online")
    listen_for_wake_word()