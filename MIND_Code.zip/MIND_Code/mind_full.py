import sys
import time
import threading
import queue 
import pygame 
import tkinter as tk
import torch 
import whisper 
from TTS.api import TTS
import speech_recognition as sr
from colorama import Fore, init
import json
import os

# --- 1. CONFIGURATION & BRAIN ---
import config  
from mind_brain import MindBrain 

# --- 2. IMPORT MODULES ---
from modules.SystemNavigator import SystemNavigator
from modules.IntelligenceAgent import IntelligenceAgent
from modules.SecurityAgent import SecurityAgent
from modules.BlenderAutomator import BlenderAutomator
from modules.automation_agent import AutomationAgent # JARVIS capabilities
from modules.datacore_agent import DataCoreAgent # Data Intelligence Agent

# 👇 IMPORTS FOR ANDROID
from modules.android_agent import AndroidAutomator       # <--- The Creator (Types Code)
from modules.HeadlessAutomator import HeadlessAndroid    # <--- The Builder (Fixes Bugs)
from modules.web_agent import WebAutomator               # <--- The Web Developer
from modules.downloader_agent import DownloaderAgent     # <--- The Retriever
from modules.geo_agent import GeoAgent                   # <--- The Scout

# --- 3. SYSTEM PROMPTS & FUNCTIONS ---

MIND_CONTROLLER_PROMPT = """
You are MIND, a system automation engine.
You are NOT a chatbot. Do NOT provide explanations.
Your output must be strictly executable JSON.

COMMAND LIST:
1. Create App:     {"action": "create", "name": "AppName", "type": "android"}
2. Create Website: {"action": "create_web", "name": "SiteName", "stack": "react/next/html"}
3. Download:       {"action": "download", "identifier": "clipboard"} 
4. Hunt Target:    {"action": "hunt", "target": "domain.com"}
5. Scan Target:    {"action": "scan", "target": "IP/Domain"}
6. Track Target:   {"action": "track", "target": "IP/Domain"}
7. OSINT User:     {"action": "osint", "target": "Username"}
8. Open App:       {"action": "open", "target": "App Name"}
9. Status Report:  {"action": "status"}
10. Media Control: {"action": "media", "command": "vol_up/vol_down/mute/unmute"}
11. Weather:       {"action": "weather", "city": "City Name"}
12. Web Search:    {"action": "search", "query": "Your Query"}
13. Read Page:     {"action": "read", "target": "clipboard"}
14. Create Vault:  {"action": "vault_create", "name": "SecretFolder"}
15. Open Vault:    {"action": "vault_open", "name": "SecretFolder"}
16. Lock System:   {"action": "lock"}
17. Surveillance:  {"action": "camera"}
18. Energy Mode:   {"action": "energy", "mode": "high/balanced"}
19. Play Music:    {"action": "music", "query": "Song Name"}
20. Chat:          {"action": "chat", "response": "Your short reply here."}
21. Analyze Data:  {"action": "analyze", "source": "path/to/file.csv", "mode": "diagnostic/predictive", "target_col": "optional_column"}
22. Scan Drives:   {"action": "scan_storage"}
23. Element Data:  {"action": "element_lookup", "target": "Element Name/Symbol"}
24. New Element:   {"action": "create_element", "name": "Name", "symbol": "Sym", "number": 120, "weight": 300.5}
25. Test Reaction: {"action": "test_reaction", "reactants": ["Na", "Cl"]}
26. Develop Game:  {"action": "develop_game", "concept": "Brief description of the game"}
27. Engineering:   {"action": "consult_engineer", "query": "Question about robotics, EVs, or parts"}
28. Find Store:    {"action": "find_store", "item": "Component Name (e.g. Arduino)"}
29. Online Deal:   {"action": "find_deal", "item": "Product Name (e.g. Drone Battery)"}

If the user speaks casually, reply with {"action": "chat", "response": "..."}.
"""

def create_android_app(app_name, package_name="com.example"):
    """
    Ghost Developer: Creates Android Project files instantly in background.
    """
    base_path = f"D:/MyProjects/{app_name}" 
    
    folders = [
        f"{base_path}/app/src/main/java/{package_name.replace('.', '/')}/{app_name.lower()}",
        f"{base_path}/app/src/main/res/layout",
        f"{base_path}/app/src/main/res/values"
    ]

    for folder in folders:
        os.makedirs(folder, exist_ok=True)

    # Create MainActivity.kt
    kotlin_code = f"package {package_name}.{app_name.lower()}\n\nimport androidx.appcompat.app.AppCompatActivity\nimport android.os.Bundle\n\nclass MainActivity : AppCompatActivity() {{\n    override fun onCreate(savedInstanceState: Bundle?) {{\n        super.onCreate(savedInstanceState)\n        setContentView(R.layout.activity_main)\n    }}\n}}"
    with open(f"{folders[0]}/MainActivity.kt", "w") as f:
        f.write(kotlin_code)

    # Create Layout
    xml_code = '<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="match_parent"><TextView android:text="Hello MIND" android:layout_width="wrap_content" android:layout_height="wrap_content"/></LinearLayout>'
    with open(f"{folders[1]}/activity_main.xml", "w") as f:
        f.write(xml_code)

    print(f"{Fore.GREEN}✅ [SUCCESS] App '{app_name}' generated at {base_path}")
    return f"Project {app_name} created successfully."

# --- 4. WORKER THREADS ---

# --- SMART SPEAKER (PIPELINED TTS) ---
class SmartSpeaker:
    def __init__(self, tts_model, voice_file):
        self.tts = tts_model
        self.voice_file = voice_file
        self.gen_queue = queue.Queue()
        self.play_queue = queue.Queue()
        self.is_active = True
        
        # Start Threads
        threading.Thread(target=self.processor_loop, daemon=True).start()
        threading.Thread(target=self.generator_loop, daemon=True).start()
        threading.Thread(target=self.player_loop, daemon=True).start()

    def split_sentences(self, text):
        """Splits text into sentences for fluid streaming."""
        import re
        # Split by . ! ? but keep the punctuation
        parts = re.split(r'([.!?]+)', text)
        sentences = []
        # Re-attach punctuation
        for i in range(0, len(parts)-1, 2):
            sentences.append(parts[i] + parts[i+1])
        # Add remaining part if any
        if len(parts) % 2 == 1 and parts[-1]:
            sentences.append(parts[-1])
        return sentences

    def processor_loop(self):
        """Consumes the global speech_queue and splits into sentences."""
        while self.is_active:
            try:
                # 1. Get big text chunk
                text = config.speech_queue.get(timeout=0.5)
                
                # Update HUD
                config.is_speaking.set()
                config.last_spoken_phrase = text.lower().strip()[:100]
                config.hud_queue.put("SPEAKING...")

                # 2. Split and queue for generation
                # If short, just send it all
                if len(text) < 50:
                    self.gen_queue.put(text)
                else:
                    sentences = self.split_sentences(text)
                    if not sentences: sentences = [text] # Fallback
                    for sent in sentences:
                        if sent.strip():
                            self.gen_queue.put(sent)
                
                # 3. Add End-Of-Transmission signal for this batch if needed, 
                # but for now we just rely on the queue being empty eventually.
                
            except queue.Empty:
                if self.gen_queue.empty() and self.play_queue.empty() and not pygame.mixer.music.get_busy():
                    config.is_speaking.clear()
                    config.hud_queue.put("READY")
                continue
            except Exception as e:
                print(f"[PROCESSOR ERROR] {e}")

    def generator_loop(self):
        """Consumes sentences -> Generates Audio -> Queues File Path"""
        import uuid
        while self.is_active:
            try:
                text = self.gen_queue.get(timeout=0.5)
                if not text: continue

                # Create unique temp file
                filename = f"temp_tts_{uuid.uuid4().hex}.wav"
                filepath = os.path.join(config.ASSETS_DIR, filename)

                # Generate
                # print(f"[DEBUG] Generating: {text[:20]}...")
                if torch.cuda.is_available(): torch.cuda.empty_cache()

                try:
                    self.tts.tts_to_file(text=text, speaker_wav=self.voice_file, language="en", file_path=filepath)
                    self.play_queue.put(filepath)
                except Exception as e:
                    print(f"[TTS GEN ERROR] {e}")
                    # Try CPU fallback if GPU fails
                    try:
                        self.tts.to("cpu")
                        self.tts.tts_to_file(text=text, speaker_wav=self.voice_file, language="en", file_path=filepath)
                        self.play_queue.put(filepath)
                        self.tts.to("cuda") # Try to go back
                    except:
                        pass

            except queue.Empty:
                continue

    def player_loop(self):
        """Consumes Audio Files -> Plays -> Deletes"""
        while self.is_active:
            try:
                filepath = self.play_queue.get(timeout=0.5)
                
                # Init mixer if needed
                if pygame.mixer.get_init() is None: pygame.mixer.init()
                
                # Wait if previous is still playing
                while pygame.mixer.music.get_busy(): 
                    time.sleep(0.05)
                
                # Play
                pygame.mixer.music.load(filepath)
                pygame.mixer.music.play()
                
                # Wait for finish to delete (we wait here or rely on checking busy in loop)
                # To ensure smooth gapless, we might want to start loading next? 
                # Pygame music queue is tricky. Let's just block-wait for simplicity first, 
                # latency between sentences is minimal with local file.
                while pygame.mixer.music.get_busy():
                    time.sleep(0.05)
                
                pygame.mixer.music.unload()
                
                # Delete
                try:
                    os.remove(filepath)
                except:
                    pass

            except queue.Empty:
                continue
            except Exception as e:
                print(f"[PLAYER ERROR] {e}")

def listen():
    if config.is_speaking.is_set() or not config.speech_queue.empty(): return None

    r = sr.Recognizer()
    r.dynamic_energy_threshold = True  
    r.energy_threshold = 300 
    r.pause_threshold = 0.8   
    
    try:
        with sr.Microphone(device_index=1) as source:
            r.adjust_for_ambient_noise(source, duration=0.5)
            config.hud_queue.put("LISTENING...")
            audio = r.listen(source, timeout=5, phrase_time_limit=8)
            
            if config.is_speaking.is_set(): return None

            config.hud_queue.put("THINKING...")
            with open(config.TEMP_INPUT_AUDIO, "wb") as f: f.write(audio.get_wav_data())
            
            result = stt_model.transcribe(config.TEMP_INPUT_AUDIO, fp16=False)
            text = result['text'].lower().strip()
            
            for char in [",", "!", "?", "'", "."]: text = text.replace(char, "")
            
            if len(text) < 2: return None
            if "mind" not in text: return None 
            
            config.hud_queue.put(f"GOT: {text}")
            return text
            
    except sr.WaitTimeoutError: return None 
    except Exception: return None

def overlay_thread():
    root = tk.Tk(); root.overrideredirect(True); root.geometry("300x80+20+20")
    root.attributes("-topmost", True, "-alpha", 0.8); root.configure(bg='black')
    lbl = tk.Label(root, text="MIND v14.0", fg="#00FF00", bg="black", font=("Consolas", 10, "bold"))
    lbl.pack(expand=True)
    def update():
        try: lbl.config(text=config.hud_queue.get_nowait())
        except: pass
        if not config.exit_event.is_set(): root.after(100, update)
        else: root.destroy()
    root.after(100, update); root.mainloop()

# --- 5. MAIN LOOP ---

if __name__ == "__main__":
    init(autoreset=True)
    print(f"{Fore.CYAN} [INIT] MIND v14.0 (Modular) Booting...")
    
    # Init Hardware
    stt_model = whisper.load_model("base") 
    tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to("cuda" if torch.cuda.is_available() else "cpu")
    pygame.mixer.init()

    # --- INIT AGENTS ---
    main_brain = MindBrain() 
    navigator = SystemNavigator()
    intel = IntelligenceAgent()
    security = SecurityAgent()
    
    # The Creator (Types Code)
    android_bot = AndroidAutomator()      
    # The Builder (Compiles Code)
    headless_bot = HeadlessAndroid()      
    geo_bot = GeoAgent()      
    web_bot = WebAutomator() # <--- Init Web Agent
    downloader_bot = DownloaderAgent() # <--- Init Downloader
    automation_bot = AutomationAgent() # <--- Init Automation Agent
    datacore_bot = DataCoreAgent()     # <--- Init Data Core
    
    blender_bot = BlenderAutomator()

    # Start Workers
    # threading.Thread(target=speaker_worker, daemon=True).start() # REPLACED BY SMART SPEAKER
    smart_speaker = SmartSpeaker(tts, config.CORE_VOICE_FILE)
    threading.Thread(target=overlay_thread, daemon=True).start()

    config.speech_queue.put("Online. Modular systems active.")
    time.sleep(2)

    try:
        while not config.exit_event.is_set():
            if config.is_speaking.is_set(): 
                time.sleep(0.5)
                continue
                
            cmd = listen()
            if not cmd: continue
            
            user_text = cmd.replace("mind", "").strip()
            print(f"{Fore.YELLOW}USER: {user_text}")

            # --- PRIORITY HARDCODED COMMANDS ---
            if "shutdown" in user_text:
                config.speech_queue.put("Disengaging systems.")
                config.exit_event.set()
                break
                
            elif "scan" in user_text and "network" in user_text:
                threading.Thread(target=security.recon_scan, args=("192.168.1.1",)).start()
                
            elif "fix code" in user_text or "debug" in user_text or "fix error" in user_text:
                print(f"{Fore.MAGENTA}🔧 [MIND] Debugging from Clipboard...")
                threading.Thread(target=android_bot.fix_code_from_clipboard).start()

            # --- AI ROUTING (THE NEW BRAIN) ---
            else:
                # 1. Ask the Brain (Force JSON Mode)
                # We use a lower temperature for commands to ensure JSON compliance
                ai_response = main_brain.think(
                    user_text, 
                    system_role=MIND_CONTROLLER_PROMPT, 
                    temperature=0.1
                )

                # 2. Parse the JSON
                try:
                    # Clean markdown if AI adds it
                    clean_json = ai_response.replace("```json", "").replace("```", "").strip()
                    command_data = json.loads(clean_json)
                    
                    action = command_data.get("action")

                    # 3. Execute Action
                    if action == "create":
                        app_name = command_data.get("name")
                        print(f"{Fore.CYAN}⚙️ [MIND] Auto-Generating App: {app_name}")
                        
                        # Use the "Ghost Developer" function
                        print(f"{Fore.CYAN}⚙️ [MIND] Handing off to Android Agent...")
                        threading.Thread(target=android_bot.step_3_to_7_generate_and_code, args=(app_name,)).start()
                        # result_msg = create_android_app(app_name) # DEPRECATED
                        # config.speech_queue.put(result_msg)

                    elif action == "create_web":
                        app_name = command_data.get("name")
                        stack = command_data.get("stack", "html") # Default to HTML
                        print(f"{Fore.CYAN}🌐 [MIND] Initializing Web Protocol: {app_name} ({stack})")
                        
                        threading.Thread(target=web_bot.create_website, args=(app_name, stack)).start()

                    elif action == "download":
                        target = command_data.get("identifier", "clipboard")
                        print(f"{Fore.CYAN}📥 [MIND] Download Protocol: {target}")
                        threading.Thread(target=downloader_bot.download, args=(target,)).start()

                    # --- SECURITY MODULE ---
                    elif action == "hunt":
                        target = command_data.get("target")
                        threading.Thread(target=security.bounty_hunt, args=(target,)).start()

                    elif action == "scan":
                        target = command_data.get("target")
                        threading.Thread(target=security.recon_scan, args=(target,)).start()
                        
                    elif action == "track":
                        target = command_data.get("target")
                        threading.Thread(target=security.geoip_track, args=(target,)).start()
                        
                    elif action == "osint":
                        target = command_data.get("target")
                        threading.Thread(target=security.osint_scan, args=(target,)).start()

                    # --- AUTOMATION / JARVIS MODULE ---
                    elif action == "status":
                        threading.Thread(target=automation_bot.get_system_status).start()
                        
                    elif action == "media":
                        cmd = command_data.get("command")
                        threading.Thread(target=automation_bot.control_media, args=(cmd,)).start()
                        
                    elif action == "weather":
                        city = command_data.get("city")
                        threading.Thread(target=automation_bot.get_weather, args=(city,)).start()
                        
                    elif action == "search":
                        query = command_data.get("query")
                        threading.Thread(target=automation_bot.web_search, args=(query,)).start()
                        
                    elif action == "read":
                        target_url = command_data.get("target", "clipboard")
                        threading.Thread(target=automation_bot.read_page, args=(target_url,)).start()

                    elif action == "vault_create":
                        name = command_data.get("name")
                        threading.Thread(target=automation_bot.create_vault, args=(name,)).start()
                        
                    elif action == "vault_open":
                        name = command_data.get("name")
                        threading.Thread(target=automation_bot.open_vault, args=(name,)).start()

                    # --- JARVIS V2 ---
                    elif action == "lock":
                        threading.Thread(target=automation_bot.lock_system).start()
                        
                    elif action == "camera":
                        threading.Thread(target=automation_bot.camera_snapshot).start()
                        
                    elif action == "energy":
                        mode = command_data.get("mode", "high")
                        threading.Thread(target=automation_bot.set_power_mode, args=(mode,)).start()
                        
                    elif action == "music":
                        query = command_data.get("query")
                        threading.Thread(target=automation_bot.play_music, args=(query,)).start()

                    elif action == "analyze":
                        source = command_data.get("source")
                        mode = command_data.get("mode", "diagnostic")
                        target_col = command_data.get("target_col", None)
                        
                        if mode == "predictive" and target_col:
                            threading.Thread(target=datacore_bot.analyze_predictive, args=(source, target_col)).start()
                        else:
                            threading.Thread(target=datacore_bot.analyze_diagnostic, args=(source,)).start()

                    elif action == "scan_storage":
                        threading.Thread(target=datacore_bot.scan_system_drives).start()

                    elif action == "element_lookup":
                        target = command_data.get("target")
                        threading.Thread(target=datacore_bot.get_element_info, args=(target,)).start()

                    elif action == "create_element":
                        name = command_data.get("name")
                        symbol = command_data.get("symbol")
                        number = command_data.get("number")
                        weight = command_data.get("weight")
                        threading.Thread(target=datacore_bot.synthesize_element, args=(name, symbol, number, weight)).start()

                    elif action == "test_reaction":
                        reactants = command_data.get("reactants", [])
                        if len(reactants) >= 2:
                             threading.Thread(target=datacore_bot.calculate_bonding, args=(reactants[0], reactants[1])).start()

                    elif action == "develop_game":
                        concept = command_data.get("concept")
                        print(f"{Fore.MAGENTA}🎮 [GAME ARCHITECT] Analyzing concept: {concept}")
                        config.speech_queue.put(f"Designing game based on concept: {concept}")
                        
                        # 1. RAG Search for Mechanics
                        context = knowledge_bot.ask(f"Game mechanics for {concept}")
                        if "I don't know" in context:
                             context = "Standard AI creativity (No specific mechanics found)."
                        
                        # 2. Generate Design Proposal
                        design = f"""
                        🎮 GAME DESIGN PROPOSAL: {concept.upper()}
                        ======================================
                        
                        Suggested Mechanics (from Mechadex):
                        {context}
                        
                        AI Analysis:
                        Integrating these mechanics would create a compelling loop.
                        Recommendation: Prototype the core mechanic first.
                        """
                        print(Fore.CYAN + design)
                        # In a real scenario, we might use the LLM to synthesize a full GDD here using the context.
                        # For now, we return the RAG result which lists the matched mechanics.

                    elif action == "consult_engineer":
                        query = command_data.get("query")
                        print(f"{Fore.MAGENTA}🔧 [ENGINEERING] Consulting knowledge base: {query}")
                        config.speech_queue.put(f"Checking engineering resources for {query}")
                        
                        context = knowledge_bot.ask(f"engineering resources {query}")
                        
                        report = f"""
                        🔧 ENGINEERING CONSULTATION
                        ===========================
                        Query: {query}
                        
                        Relevant Resources Found:
                        {context}
                        
                        Recommendation:
                        Check specific APIs (Octopart) for live data or NIST/Kaggle for datasets.
                        """
                        print(Fore.CYAN + report)

                    elif action == "find_store":
                        item = command_data.get("item")
                        print(f"{Fore.MAGENTA}🌍 [GEO] Locating supplier for: {item}")
                        config.speech_queue.put(f"Checking Google Maps for {item}")
                        
                        response = geo_bot.find_nearby_stores(item)
                        print(Fore.CYAN + response)

                    elif action == "find_deal":
                        item = command_data.get("item")
                        print(f"{Fore.MAGENTA}🛒 [COMMERCE] Hunting deals for: {item}")
                        config.speech_queue.put(f"Searching online markets for {item}")
                        
                        response = geo_bot.find_online_products(item)
                        print(Fore.CYAN + response)

                    elif action == "open":
                        target = command_data.get("target")
                        print(f"{Fore.CYAN}⚙️ [MIND] Open Request: {target}")
                        
                        # 1. Try DataCore File Search (Deep Retrieval)
                        # We spawn a thread but wait briefly or handle result? 
                        # Actually, since this is "open", we should try to find it first.
                        # Since we are in the main thinking loop, let's just check the index quickly.
                        # The search is fast (in-memory list).
                        
                        found_file = datacore_bot.search_file(target)
                        
                        if found_file:
                            print(f"{Fore.GREEN} [MIND] Opening Local File: {found_file}")
                            config.speech_queue.put(f"Opening {os.path.basename(found_file)}.")
                            try:
                                os.startfile(found_file) # Windows Native Open
                            except Exception as e:
                                print(f"[ERROR] Could not open file: {e}")
                        else:
                            # 2. Fallback to System/Web Navigator
                            navigator.execute(target)

                    elif action == "chat":
                        reply = command_data.get("response")
                        config.speech_queue.put(reply)

                    else:
                        print(f"[WARN] Unknown Action: {action}")

                except json.JSONDecodeError:
                    # Fallback: If AI fails to give JSON, just speak the raw text
                    print(f"[ROUTER] JSON Failed. Speaking raw output.")
                    config.speech_queue.put(ai_response)

    except KeyboardInterrupt:
        config.exit_event.set()
        print("\n[STOP] Force Quit.")