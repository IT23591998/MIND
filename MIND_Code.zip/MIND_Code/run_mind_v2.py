import sys
import os
import time
from colorama import init, Fore, Style

# Append path
sys.path.append(os.getcwd())

from modules.mcp import MasterControlProgram
from modules.shopping_agent import ShoppingAgent
from modules.scheduler_agent import SchedulerAgent
from modules.innovation_engine import InnovationEngine
from modules.music_agent import MusicAgent
from modules.face_hunter import FaceHunter

def print_header():
    print(Fore.CYAN + Style.BRIGHT + """
    ╔══════════════════════════════════════════════════════╗
    ║                 MIND EXPANSION V2.3                  ║
    ║        Master Control Program (MCP) Online           ║
    ╚══════════════════════════════════════════════════════╝
    """)
    print(Fore.WHITE + "    Capabilities Loaded:")
    print(Fore.GREEN + "    [+] Meta-Reasoning & Confidence Tracker")
    print(Fore.GREEN + "    [+] Multi-Domain Simulation (Energy + Engineering)")
    print(Fore.GREEN + "    [+] Innovation Engine & Scheduler")
    print(Fore.GREEN + "    [+] Autonomous Cloning & Mobile Dev")
    print(Fore.CYAN + "\n    Type 'exit' to quit.\n")

def main():
    init(autoreset=True)
    print_header()
    
    print(Fore.YELLOW + "⚡ Initializing MCP...")
    mcp = MasterControlProgram()
    scheduler = SchedulerAgent()
    innovator = InnovationEngine(mcp.brain)
    music_player = MusicAgent()
    face_hunter = FaceHunter()
    
    # Initialize separate agents if needed for direct access, 
    # but primarily we use MCP routing.
    
    print(Fore.GREEN + "✅ System Ready.")
    
    while True:
        try:
            # 1. Scheduler Check
            due_tasks = scheduler.check_pending()
            for task in due_tasks:
                if task['type'] == 'reminder':
                    print(Fore.CYAN + f"\n🔔 [REMINDER] {task['message']}\a") # \a bell sound
            
            # Non-blocking input check is hard in pure python without curses/threads
            # We stick to blocking input for V1 CLI simplicity, meaning reminders show up AFTER Enter press
            # or we rely on the loop wrapping around quickly.
            
            user_input = input(Fore.WHITE + Style.BRIGHT + "\nUSER > " + Fore.RESET)
            if user_input.lower() in ['exit', 'quit']:
                print(Fore.CYAN + "Shutting down MIND V2.")
                break
            
            if not user_input.strip():
                continue
                
            # Direct routing hints based on text/keywords for the demo
            domain = "General"
            
            # --- ROUTING LOGIC ---
            if "simulate" in user_input.lower():
                domain = "Simulation"
            elif "update knowledge" in user_input.lower():
                domain = "Knowledge"
                
            elif "innovate" in user_input.lower() or "brainstorm" in user_input.lower():
                print(Fore.MAGENTA + "💡 Routing to Innovation Engine...")
                print(innovator.brainstorm(user_input))
                continue
                
            elif "predict" in user_input.lower() and "future" in user_input.lower():
                print(Fore.MAGENTA + "🔮 Routing to Prediction Engine...")
                print(innovator.predict_future(user_input))
                continue
                
            elif "remind me" in user_input.lower():
                # Naive parsing: "remind me to X in Y seconds"
                try:
                    parts = user_input.split(" in ")
                    msg = parts[0].replace("remind me to", "").strip()
                    sec = int(parts[1].split()[0])
                    scheduler.set_reminder(msg, sec)
                except:
                    print(Fore.RED + "⚠️  Format: 'Remind me to [Task] in [N] seconds'")
                continue

            elif "find" in user_input.lower() and ("price" in user_input.lower() or "cost" in user_input.lower()):
                     mcp.brain.shopping_bot.search_product(user_input)
                     continue # Skip MCP execution as ShoppingAgent handles UI
            elif "consensus" in user_input.lower() or "verify" in user_input.lower():
                print(Fore.MAGENTA + "⚖️  [CONSENSUS] Routing to Multi-Brain Protocol...")
                mcp.submit_consensus_task(user_input)
                continue

            # --- MUSIC COMMANDS ---
            elif user_input.lower().startswith("play "):
                song = user_input[5:].strip()
                music_player.play(song)
                continue

            elif "stop music" in user_input.lower():
                music_player.stop()
                continue
                
            elif "pause music" in user_input.lower():
                music_player.pause()
                continue
                
            elif "resume music" in user_input.lower():
                music_player.resume()
                continue
                
            elif "volume" in user_input.lower():
                try:
                    vol = int(user_input.split()[-1])
                    music_player.set_volume(vol)
                except:
                    print(Fore.RED + "⚠️  Usage: 'volume [0-100]'")
                continue

            # --- FACE HUNTER COMMANDS ---
            elif "hunt face" in user_input.lower():
                # Usage: "hunt face [username] using [path/to/image]"
                try:
                    parts = user_input.split(" using ")
                    username = parts[0].replace("hunt face", "").strip()
                    img_path = parts[1].strip()
                    
                    if face_hunter.load_target_face(img_path):
                        face_hunter.hunt(username)
                except IndexError:
                    print(Fore.RED + "⚠️  Usage: 'hunt face [username] using [path/to/image.jpg]'")
                continue
            elif "argus scan" in user_input.lower():
                # Direct Argus Usage
                target = user_input.replace("argus scan", "").strip()
                mcp.brain.security_bot.run_argus_scan(target)
                continue
            
            # Submit to MCP
            start_time = time.time()
            result = mcp.submit_task(user_input, domain=domain)
            end_time = time.time()
            
            # Display Output
            print("-" * 50)
            if result.status == "flagged_for_review":
                 print(Fore.RED + Style.BRIGHT + "⚠️  [LOW CONFIDENCE] " + result.output)
            else:
                 print(Fore.WHITE + result.output)
            
            print("-" * 50)
            print(Fore.CYAN + f"⏱️  Reflex Time: {round(end_time - start_time, 2)}s | 📊 Confidence: {result.overall_confidence}")
            
        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(Fore.RED + f"Error: {e}")

if __name__ == "__main__":
    main()
